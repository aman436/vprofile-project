from modules.tenant_vault.main.TenantVaultTemplater import TenantVaultTemplater
import unittest
import logging
import os

from templater.main.JinjaTemplate import JinjaTemplate


class TestTenantVaultTemplater(unittest.TestCase):
    def __init__(self, *args, **kwargs) -> None:
        super(TestTenantVaultTemplater, self).__init__(*args, **kwargs)
        logging.basicConfig(level=logging.DEBUG)
        self.maxDiff = None

    def test_create_configs_values(self) -> None:
        test_base_config: dict = {
            "module_source": "../modules/k8s_deploy/main",
            "template_path": "platform/modules/tenant_vault/main/k8s/templates",
            "cluster_name": "vault",
            "cluster_location_type": "regional",
            "bastion_name": "bastion-vault",
            "zone": "europe-west1-b",
            "region": "europe-west1",
            "tenant_list": [
                {"name": "tenant_a", "dhk_suffix": "-abcd"},
                {"name": "tenant_b"},
            ],
            "project_name": "test_project",
        }
        test_full_config_list: list = [
            {
                "config": {
                    "terraform_resource_name": "tenant_vault_tenant_a",
                    "base_path": os.getcwd(),
                    "terraform_module_name": "k8s_deploy",
                },
                "variables": {
                    "module_source": "../modules/k8s_deploy/main",
                    "template_path": "platform/modules/tenant_vault/main/k8s/templates",
                    "cluster_name": "vault",
                    "cluster_location_type": "regional",
                    "bastion_name": "bastion-vault",
                    "zone": "europe-west1-b",
                    "project_name": "test_project",
                    "config_values": {
                        "TF_TENANT_PREFIX": "vault-tenant_a",
                        "TF_KMS_PROJECT_NAME": "vf-tenant_a-dhk-abcd",
                        "TF_KMS_REGION": "europe-west1",
                        "TF_VAULT_BUCKET_NAME": "vftenant_a-dh-vault-secrets",
                        "TF_KMS_KEY_RING": "keyring-vf-tenant_a-dhk-abcd-europe-west1",
                        "TF_KMS_CRYPTO_KEY": "cmek-HSM-vf-tenant_a-gcs-europe-west1-agf",
                        "TF_VAULT_CRT_BASE64": '${base64encode("${module.vault_core.vault_crt_base64_vault}\\n${module.vault_core.vault_crt_base64_vault_ca}")}',
                        "TF_VAULT_KEY_BASE64": '${base64encode("${module.vault_core.vault_key_base64}")}',
                    },
                },
            },
            {
                "config": {
                    "terraform_resource_name": "tenant_vault_tenant_b",
                    "base_path": os.getcwd(),
                    "terraform_module_name": "k8s_deploy",
                },
                "variables": {
                    "module_source": "../modules/k8s_deploy/main",
                    "template_path": "platform/modules/tenant_vault/main/k8s/templates",
                    "cluster_name": "vault",
                    "cluster_location_type": "regional",
                    "bastion_name": "bastion-vault",
                    "zone": "europe-west1-b",
                    "project_name": "test_project",
                    "config_values": {
                        "TF_TENANT_PREFIX": "vault-tenant_b",
                        "TF_KMS_PROJECT_NAME": "vf-tenant_b-dhk",
                        "TF_KMS_REGION": "europe-west1",
                        "TF_VAULT_BUCKET_NAME": "vftenant_b-dh-vault-secrets",
                        "TF_KMS_KEY_RING": "keyring-vf-tenant_b-dhk-europe-west1",
                        "TF_KMS_CRYPTO_KEY": "cmek-HSM-vf-tenant_b-gcs-europe-west1-agf",
                        "TF_VAULT_CRT_BASE64": '${base64encode("${module.vault_core.vault_crt_base64_vault}\\n${module.vault_core.vault_crt_base64_vault_ca}")}',
                        "TF_VAULT_KEY_BASE64": '${base64encode("${module.vault_core.vault_key_base64}")}',
                    },
                },
            },
        ]
        result = TenantVaultTemplater(
            JinjaTemplate("resources/templates")
        )._create_configs_values(test_base_config)

        self.assertListEqual(result, test_full_config_list)


if __name__ == "__main__":
    unittest.main()
