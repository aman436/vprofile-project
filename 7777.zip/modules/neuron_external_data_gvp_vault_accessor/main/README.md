# Neuron EDS vault accessor module

This module creates all the necessary resources to access vault service from a Neuron External Data Source project.
This module creates:
  DNS records
  Firewall rules
  IAM Permissions for vault SA and Composer SA.

https://confluence.sp.vodafone.com/pages/viewpage.action?pageId=202648914

## Resources created by this module
1. google_dns_managed_zone
2. google_dns_record_set: an A record for vault ip
3. google_compute_firewall: allows egrees on port 443
4. google_service_account_iam_member: Assignes serviceAccount Token creater role to neds composer SA. 
5. google_project_iam_member: Provides Vault SA with custome role 'VaultGCPAuthRole' on the project level.

## How to use this module?

<br>

```yaml
modules:
  - name: neuron_external_data_gvp_vault_accessor
    network_self_link: "${module.neuron_external_data_core.neds_core_vpc_address}"
    accessor_service_account_email: "${module.neuron_external_data.composer_sa_email}"
    accessor_service_account_name: "${module.neuron_external_data.composer_sa_name}"
```

## Who should use this module?
 This module is dedicated for EDS projects, as these projects do not use 'tenant_dmaap_restricted_vpc_tf12' which has many additional resources and firewall rules attached to it and are not required in a EDS Project.  
 This module is different as it creates additional IAM roles for neds SA and adds Vault SA to allow access to vault service.

 ## PR 
 https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-gcp-platform/pull/1360
