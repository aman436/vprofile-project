# frozen_string_literal: true

['dns_zone'].each do |lib|
    require_relative "#{Dir.pwd}/target/tests/libraries/#{lib}.rb"
  end

def run_private_dns_zone(params)
    
    project_id = params['config']['project_id']
    dns_zone_name = params['variables']['dns_zone_name']
    dns_name = params['variables']['dns_name']

    control "#{project_id} : #{params['module_name']} " do
      validate_dns_zone(project_id, dns_zone_name, dns_name)
    end
  end
  