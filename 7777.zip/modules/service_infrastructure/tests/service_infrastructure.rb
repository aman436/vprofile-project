# frozen_string_literal: true

def run_service_infrastructure(params)
  project_id = params['config']['project_id']
  control "#{project_id} : service_infrastructure : " do
    title 'service_infrastructure setup correctly'
    impact 0.4
  end
end
