# frozen_string_literal: true

%w[service_account iam subnet composer bucket web_services].each do |lib|
  require_relative "#{Dir.pwd}/target/tests/libraries/#{lib}.rb"
end

def run_tenant_environment_tf12(params)
  project_id = params['config']['project_id']
  control "#{project_id} : #{params['config']['module_name']} " do
    title 'tenant_environment setup correctly'
    impact 0.4

    subnet_name = "#{params['variables']['tenant_sub_stage']}-restricted-zone"

    vpc_suffix = if params['variables']['stage'] == 'nonlive'
                   'non-live'
                 else
                   params['variables']['stage']
                 end

    # Subnet Tests
    subnet_tests(project_id, subnet_name, vpc_suffix, params)

    p_vars = params['variables'] 
    sa_dp = "#{p_vars['organisation']}-#{p_vars['tenant']}-" \
            "#{p_vars['program']}-#{p_vars['tenant_sub_stage']}-dp-" \
            "#{p_vars['persona_dp']}-sa@#{project_id}" \
            '.iam.gserviceaccount.com'
    dp_roles = ['dataproc.worker', 'bigquery.user', 'bigquery.dataEditor']

    sa_df = "#{p_vars['organisation']}-#{p_vars['tenant']}-" \
            "#{p_vars['program']}-#{p_vars['tenant_sub_stage']}-df-" \
            "#{p_vars['persona_df']}-sa@#{project_id}" \
            '.iam.gserviceaccount.com'
    df_roles = ['dataflow.developer', 'dataflow.worker', 'storage.admin',
                'datastore.user', 'bigquery.admin' ]

    service_accounts = {
      'dp' => { sa_dp => dp_roles },
      'df' => { sa_df => df_roles }
    }

    service_accounts.each_value do |sa|
      sa.each do |sa_email, roles|
        # Check if service account exist in the GCP Project
        sa_exists(sa_email, project_id)

        # Check if service account has required IAM roles.
        roles.each do |role|
          sa_iam_role_exists(sa_email, project_id, role)
        end
      end
    end

    # GCS bucket tests
    bucket_name = "vf-#{params['variables']['tenant']}-" \
      "#{params['variables']['program']}-#{params['variables']['stage']}-" \
      "#{params['variables']['tenant_sub_stage']}"
    bucket_exists(bucket_name)
    bucket_storage_class(
      bucket_name,
      params['tests']['bucket_storage_class'].upcase
    )
    bucket_location(
      bucket_name,
      params['variables']['region'].upcase
    )

    composer_tests(project_id, params)
  end
end

def subnet_tests(project_id, subnet_name, vpc_suffix, params)
  subnet_exists_in_project(
    project_id,
    params['variables']['region'],
    subnet_name
  )
  subnet_cidr_range(
    project_id,
    params['variables']['region'],
    subnet_name,
    params['variables']['subnet_cidr']
  )
  subnet_in_vpc_network(
    project_id,
    params['variables']['region'],
    subnet_name,
    "vpc-#{params['variables']['tenant']}-#{vpc_suffix}-vpc"
  )
  subnet_vm_private_ip_access(
    project_id,
    params['variables']['region'],
    subnet_name,
    params['tests']['subnet_private_ip_access']
  )
  subnet_flowlog_on(
    project_id,
    subnet_name,
    params['variables']['region'],
    params['tests']['subnet_flowlog_on']
  )
end

def composer_tests(project_id, params)
  if params['variables']['require_composer'] == '1'

    composer_sa = "vf-#{params['variables']['tenant']}-" \
      "#{params['variables']['program']}-#{params['variables']['tenant_sub_stage']}" \
      "-comp-sa@#{project_id}.iam.gserviceaccount.com"

    sa_exists(composer_sa, project_id)

  else
    puts("No composer for module: #{params['config']['module_name']}")
  end
end
