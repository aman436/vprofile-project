Build from the project root (platform repository):

1. Get the latest semantic tag from GCR by visting [GCP Console](https://console.cloud.google.com/gcr/images/vf-grp-neuronenabler-nonlive/EU/gocd-agent-docker-dind?project=vf-grp-neuronenabler-nonlive&gcrImageListsize=30) or running below command.
```
gcloud container images list-tags eu.gcr.io/vf-grp-neuronenabler-nonlive/gocd-agent-docker-dind --format="value(tags)" | head -n 1 | cut -d '-' -f2
```

2. Based on the change, update the semantic version and export in the `VERSION` variable and build docker image.
```
VERSION=v1.1.8              # Example value when output of previous command was v1.1.7
docker build -t eu.gcr.io/vf-grp-neuronenabler-nonlive/gocd-agent-docker-dind:v20.3.0-${VERSION} -f modules/gocd/main/k8s/agent/Dockerfile .
```

3. test if new docker image is working as expected
```
docker run -it eu.gcr.io/vf-grp-neuronenabler-nonlive/gocd-agent-docker-dind:v20.3.0-${VERSION} bash
```

3. Push new docker image
```
docker push -t eu.gcr.io/vf-grp-neuronenabler-nonlive/gocd-agent-docker-dind:v20.3.0-${VERSION}
```

4. Update new docker image
```
# keep for rollback
OLD_IMAGE=$(kubectl get deployment gocd-agent -n gocd -o=json|jq '.spec.template.spec.containers[0].image')

kubectl patch deployment gocd-agent -n gocd --type='json' -p='[{"op": "replace", "path": "/spec/template/spec/containers/0/image", "value":"eu.gcr.io/vf-grp-neuronenabler-nonlive/gocd-agent-docker-dind:v20.3.0-${VERSION}"}]'
```