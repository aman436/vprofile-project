#!/bin/bash

kubectl get namespace gocd  || kubectl create namespace gocd
config_dir="platform/modules/gocd/main/helm"
helm upgrade --install -f ${config_dir}/values.gocd.yaml gocd stable/gocd --namespace gocd --post-renderer  ${config_dir}/customize.sh
