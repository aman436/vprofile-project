#!/bin/bash

cat <&0 | /usr/bin/env envsubst "$(/usr/bin/printf '${%s} ' ${!TF_*} ${!GO_*})"
cat platform/modules/gocd/main/helm/gocd-init-script.yml |  /usr/bin/env envsubst "$(/usr/bin/printf '${%s} ' ${!TF_*} ${!GO_*})"
cat platform/modules/gocd/main/helm/gocd-backend-config.yml
