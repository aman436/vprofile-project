# GoCD relese requirements

## Load docker images for agent, server and squid


      export TF_PROJECT_NAME=vf-grp-neuronenabler-live
      docker tag gocd-server:v20.3.0 eu.gcr.io/${TF_PROJECT_NAME}/gocd-server:v20.3.0-vf
      docker push eu.gcr.io/${TF_PROJECT_NAME}/gocd-server:v20.3.0-vf

      cd platform/modules/gocd/main/k8s/agent
      docker build -t eu.gcr.io/${TF_PROJECT_NAME}/gocd-agent-docker-dind:v20.3.0-vf .
      docker push eu.gcr.io/${TF_PROJECT_NAME}/gocd-agent-docker-dind:v20.3.0-vf

      docker push eu.gcr.io/$TF_PROJECT_NAME/squid-image	


## configure github oAuth app

        app name: ne-gocd
        homepage: https://zeta-ne-gocd.neuron.bdp.vodafone.com
        descript: neuronenabler live gocd
        callback: https://zeta-ne-gocd.neuron.bdp.vodafone.com/go/plugin/cd.go.authorization.github/authenticate

## Obtain new gcp-jenkins-ghe-funcuser personal token 

## Import SSL keys
  

      gcloud compute ssl-certificates create neuron-signed-gocd-cert --certificate=cert_zeta-ne-gocd.neuron.bdp.vodafone.com.pem  --private-key=zeta-ne-gocd-keystore.pem --global --project vf-grp-neuronenabler-live

      kubectl create secret tls zeta-ne-gocd-tls  --key certs/zeta-ne-gocd-keystore.pem --cert certs/cert_zeta-ne-gocd.neuron.bdp.vodafone.com.pem -n goc

## make sure to configure proxy domain: TF_OUTBOUND_PROXY_DOMAIN

## Enable IAP 
     
      kubectl create secret generic trusted-zone-inbound-proxy-oauth --from-literal=client_id=<iap-client-id>\
      --from-literal=client_secret=<iap-secret>
