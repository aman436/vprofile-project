#!/bin/bash

#sudo journalctl -u google-startup-scripts.service
#sudo google_metadata_script_runner startup
#sudo fuser -k 10500/tcp

######## Install Vodafone Root certificate
apt-get install -y ca-certificates
printf "%s" "${cert}" > voda.crt
cp voda.crt /usr/local/share/ca-certificates
update-ca-certificates

sudo useradd atscale -m
sudo usermod --shell /bin/bash atscale
sudo -iu root
mkdir -p download
cd download && wget https://s3-us-west-1.amazonaws.com/files.atscale.com/installer/package/atscale-2022.2.0.4819-ubuntu18.04_amd64.deb 
dpkg -i atscale-2022.2.0.4819-ubuntu18.04_amd64.deb


#apt-get update &&  apt -y install apache2
#echo '<!doctype html><html><body><h1>Hello! Welcome to my Apache website hosted on GCP </h1></body></html>' |  tee /var/www/html/index.html

#/etc/apache2/ports.conf - edit to listening port
#sudo service apache2 restart
#sudo vi /etc/apache2/designcenter.conf
#sudo vi /etc/apache2/engine.conf
#Include ports_designcenter.conf
#Include ports_engine.conf

# if mkdir -p /home/webserver/designcenter; then
#     echo "Hello world designcenter" >> /home/webserver/designcenter/index.html
# fi

# if mkdir -p /home/webserver/engine; then
#     echo "Hello world engine" >> /home/webserver/engine/index.html
# fi

# cd /home/webserver/designcenter;
# python3 -m http.server 10500 &

# cd /home/webserver/engine;
# python3 -m http.server 10502 &
