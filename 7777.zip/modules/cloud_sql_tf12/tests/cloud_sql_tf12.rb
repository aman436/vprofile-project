# frozen_string_literal: true

def run_cloud_sql_tf12(params)

  config     = params['config']
  variables  = params['variables']

  control "google_sql_database_instance::#{variables['db_instance_name']}" do
    title "correctly configured"
    impact 1.0
    describe google_sql_database_instance({:project=>"#{config['project_id']}", :database=>"#{variables['db_instance_name']}"}) do
      it { should exist }
      its("name") { should cmp "#{variables['db_instance_name']}" }
      its('state') { should eq 'RUNNABLE' }
      its("connection_name") { should cmp "#{config['project_id']}:#{variables['region']}:#{variables['db_instance_name']}" }
      its("ip_addresses.first.type") { should cmp "PRIVATE" }
      its("master_instance_name") { should be_nil.or cmp "" }
      its("region") { should include "#{variables['region']}" }
      its("settings.tier") { should cmp "db-f1-micro"}
      its("settings.ip_configuration.ipv4_enabled") { should cmp false }
    end
  end
  
  control "google_sql_user::admin//#{variables['db_instance_name']}" do
    title "correctly configured"
    impact 1.0
    describe google_sql_user({:project=>"#{config['project_id']}", :database=>"#{variables['db_instance_name']}", :name=>"admin", :host=>""}) do
      it { should exist }
      its("host") { should be_nil.or cmp "" }
      its("instance") { should cmp "#{variables['db_instance_name']}" }
      its("name") { should cmp "admin" }
    end
  end

  control "google_sql_user::cs_readonly//#{variables['db_instance_name']}" do
    title "correctly configured"
    impact 1.0
    only_if { variables['required_cs_readonly_user'] === 1 }
    describe google_sql_user({:project=>"#{config['project_id']}", :database=>"#{variables['db_instance_name']}", :name=>"cs_readonly", :host=>"" }) do
      it { should exist }
      its("host") { should be_nil.or cmp "" }
      its("instance") { should cmp "#{variables['db_instance_name']}" }
      its("name") { should cmp "cs_readonly" }
    end
  end
end
