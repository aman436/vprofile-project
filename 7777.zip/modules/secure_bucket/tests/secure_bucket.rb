# frozen_string_literal: true

def run_secure_bucket(params)
  project_id = params['config']['project_id']
  control "#{project_id} : secure_bucket : " do
    title 'secure_bucket setup correctly'
    impact 0.4

    bucket_name = "#{params['variables']['project_name']}-secure"
    bucket_exists(bucket_name)
    bucket_storage_class(bucket_name, params['variables']['storage_class'])
    bucket_location(bucket_name, params['variables']['region'])
  end
end
