# frozen_string_literal: true

# def run_cloud_sql_tf12(params)

  # config     = params['config']
  # variables  = params['variables']


control "google_sql_database_instance::input('db_instance_name')" do  
  title "Tosca Cloud SQL DB instance"
    describe google_sql_database_instance ({:project=>input('project_name'), :database=>input('db_instance_name')}) do
      it { should exist }
      its("name") { should cmp input('db_instance_name')}
      its('state') { should eq 'RUNNABLE' }
      its("database_version") { should cmp "SQLSERVER_2017_STANDARD" }
      its("connection_name") { should cmp input('db_connection_name')}
      its("ip_addresses.first.type") { should cmp "PRIVATE" }
      its("master_instance_name") { should be_nil.or cmp "" }
      its("region") { should include input('region') }
      its("settings.tier") { should cmp "db-custom-2-3840"}
      its("settings.ip_configuration.ipv4_enabled") { should cmp false }
    end
  end

  
  
control "google_sql_user:: User account" do
  title "User account creation check"
    describe google_sql_user(:project=>input('project_name'), :database=>input('db_instance_name'),:name=>"admin", :host=>"") do 
      it { should exist }
      its("host") { should be_nil.or cmp "" } 
      its("instance") { should cmp input ('db_instance_name')}
      its("name") { should cmp "admin" }
    end
  end


control "google_sql_user::User account" do
  title "User account creation check"
  describe google_sql_user(:project=>input('project_name'), :database=>input('db_instance_name'),:name=>"cs_readonly", :host=>"") do 
      it { should exist }
      its("host") { should be_nil.or cmp "" }
      its("instance") { should cmp input('db_instance_name')}
      its("name") { should cmp "cs_readonly" }
    end
  end




