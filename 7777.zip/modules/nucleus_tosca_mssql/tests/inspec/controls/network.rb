control "google_compute_router:: Router and NAT " do
    title "google_compute_router:: NAT for trusted zone"
    desc "google_compute_router:: Testing router and NAT for trusted zone"
      impact 1.0
      describe google_compute_router({:project=>input('project_name'), :region=>input('region'), :name=>(input('router_name'))}) do
        it { should exist }
        its("name") { should cmp (input('router_name'))}
      end
      describe google_compute_router_nat({:project=>input('project_name'), :region=>input('region'), :router=>input('router_name'), :name=>input('nat_name')}) do
        it { should exist }
        its('nat_ip_allocate_option') { should cmp 'MANUAL_ONLY' }
        its("name") { should cmp input('nat_name')}
        its("source_subnetwork_ip_ranges_to_nat") { should cmp 'ALL_SUBNETWORKS_ALL_IP_RANGES' }
      end
end

control "google_compute_network::global/networks/vpc" do
  title "google_compute_network::global/networks/vpc"
  desc " Control to check VPC"
    impact 1.0
    describe google_compute_network({:project=>input('project_name'), :name=>(input('network_name') )}) do
      it { should exist }
      its("name") { should cmp (input('network_name'))}
    end
end

control "google_compute_subnetwork:: Tosca subnetworks" do
  title "Tosca subnetworks"
  desc  "Validate Tosca subnetworks setup"
  impact 1.0
  describe google_compute_subnetwork(:project=>input('project_name'), :region=>input('region'), :name=>input('dmz_zone_name')) do
    it { should exist }
    its('ip_cidr_range') { should eq input('dmz_zone_cidr_range') }
  end
end



