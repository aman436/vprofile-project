
  
control "google_kms_key_ring::keyRings" do
    title "KMS Key Ring"
    desc  "google_kms_key_ring::KeyRings"
    impact 1.0
    describe google_kms_key_ring({:project=>input('project_name'), :location=>input('region'), :name=>(input('common_resource_id') +"-"+input('keyring_name'))}) do
      it { should exist }
  end
end

control "google_kms_crypto_key::keyRings" do
  title "KMS Crypto key Ring"
  desc  "google_kms_crypto_key::keyRings"
  impact 1.0
  describe google_kms_crypto_key({:project=>input('project_name'), :location=>input('region'), :key_ring_name=>(input('common_resource_id')+"-"+input('keyring_name')),:name=>(input('cryptokey_name'))}) do
    it { should exist }
    its("purpose") { should cmp "ENCRYPT_DECRYPT" }
    its("rotation_period") { should cmp "7776000s" }
  end 
end

