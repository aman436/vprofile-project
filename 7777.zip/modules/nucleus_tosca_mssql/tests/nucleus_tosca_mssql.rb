# frozen_string_literal: true

def run_pipeline_test_frameworks_tf12(params)
  project_id = params['config']['project_id']
  control "#{project_id} : nucleus_tosca_mssql : " do
    title 'nucleus_tosca_mssql setup correctly'
    impact 0.4
  end
end
