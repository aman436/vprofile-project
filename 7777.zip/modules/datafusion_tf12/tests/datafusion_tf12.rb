# frozen_string_literal: true

%w[service_account].each do |lib|
  require_relative "#{Dir.pwd}/target/tests/libraries/#{lib}.rb"
end

def run_datafusion_tf12(params)
  project_id = params['config']['project_id']
  variables  = params['variables']

  control "#{project_id} : #{params['config']['module_name']}" do
    title 'Ensure Data Fusion is correctly configured'
    
    # Check firewall exists
    describe google_compute_firewall(project: project_id.to_s, name: 'datafusion-firewall') do
      it { should exist }
      its('allowed_ssh?')  { should be true }
      its('source_ranges') { should_not eq ['0.0.0.0/0'] }
      its('direction')     { should eq 'INGRESS' }
      it { should allow_target_tags_only ['allow-ssh-to-datafusion'] }
    end

    # Check service account exists
    sa_email = "#{variables['datafusion_sa_email']}"
    sa_exists(sa_email, project_id)

    # Check service account has required roles
    variables['datafusion_sa_iam_roles'].each do |role|
      describe GcpState.google_project_iam_binding(self, project: project_id, role: role) do
        its('members') { should include "serviceAccount:#{sa_email}" }
      end
    end

    # Check private IP exists
    instance_name = variables['instance_name'] == "" ? "datafusion-" + variables['tenant_sub_stage'] : variables['instance_name']
    describe google_compute_global_address(project: project_id.to_s, name: 'private-ip-df-' + instance_name) do
      it { should exist }
      its('prefix_length') { should eq 22 }
      its('purpose')       { should eq 'VPC_PEERING' }
      its('address_type')  { should eq 'INTERNAL' }
    end
  end
end
