import googleapiclient
from googleapiclient.discovery import build
import google.auth
import sys
import json
import logging
import requests
import time
import datafusion_profile_parser as parser
from google.auth.transport.requests import Request


def create_profile(cdap_url, access_token, data, profile_name, namespace):
    headers = {
        "Authorization": "Bearer " + access_token,
        "Content-Type": "application/json",
        "Accepts": "application/json",
    }
    cdap_url = cdap_url + f"/v3/namespaces/{namespace}/profiles/{profile_name}"

    response = requests.put(cdap_url, json=data, headers=headers)

    if response.status_code != 200:
        logging.log(
            logging.ERROR, f"Error while creating profile {response.status_code}"
        )
        sys.exit(1)


def create_key_in_namespace(
    project,
    service_account_email,
    namespace,
    api_endpoint,
    auth_token,
    accountKey_name,
    service_account_key,
):

    headers = {
        "Authorization": "Bearer " + auth_token,
        "Content-Type": "application/json",
    }
    data = {
        "description": "Neuron Secure Key",
        "data": str(service_account_key).replace("'", '"'),
    }
    cdap_url = api_endpoint + f"/v3/namespaces/{namespace}/securekeys/{accountKey_name}"
    response = requests.put(cdap_url, headers=headers, json=data)
    if response.status_code == 200:
        return True
    else:
        return False


def check_if_profile_exists(auth_token, api_endpoint, profile_name):
    headers = {
        "Authorization": "Bearer " + auth_token,
        "Content-Type": "application/json",
        "Accepts": "application/json",
    }

    cdap_url = api_endpoint + f"/v3/profiles/{profile_name}"
    response = requests.get(cdap_url, headers=headers)

    if response.status_code == 404:
        return False
    else:
        return True


def generate_service_with_app_def_creds():
    credentials, _ = google.auth.default()
    return build("compute", "v1", credentials=credentials)


def generate_cdap_service_with_app_def_creds():
    credentials, _ = google.auth.default()
    return build("datafusion", "v1beta1", credentials=credentials)


def create_namespace(auth_token, apiendpoint, namespace_name):
    headers = {
        "Authorization": "Bearer " + auth_token,
        "Content-Type": "application/json",
        "Accepts": "application/json",
    }
    cdap_url = apiendpoint + f"/v3/namespaces/{namespace_name}"
    response = requests.put(cdap_url, json={}, headers=headers)
    if response.status_code == 200:
        return True
    else:
        return False


def disable_default_profile(apiendpoint, auth_token, profile_name):
    headers = {
        "Authorization": "Bearer " + auth_token,
        "Content-Type": "application/json",
    }
    cdap_disable_url = apiendpoint + f"/v3/profiles/{profile_name}/disable"
    response = requests.post(cdap_disable_url, headers=headers)
    if response.status_code == 200:
        return True
    else:
        return False


def delete_preference(apiendpoint, auth_token):
    headers = {
        "Authorization": "Bearer " + auth_token,
        "Content-Type": "application/json",
    }
    cdap_delete_preference_url = apiendpoint + "/v3/preferences/"
    response = requests.delete(cdap_delete_preference_url, headers=headers)
    if response.status_code == 200:
        return True
    else:
        return False


def set_default_profile_namespace(apiendpoint, auth_token, namespace, profile_new_name):
    headers = {
        "Authorization": "Bearer " + auth_token,
        "Content-Type": "application/json",
    }
    data = {
        "system.profile.name": f"USER:{profile_new_name}"
    }
    cdap_pref_update_url = apiendpoint + f"/v3/namespaces/{namespace}/preferences"
    response = requests.put(cdap_pref_update_url, headers=headers, json=data)
    if response.status_code == 200:
        return True
    else:
        return False


def delete_default_profile(apiendpoint, auth_token, profile_name):
    headers = {
        "Authorization": "Bearer " + auth_token,
        "Content-Type": "application/json",
    }
    cdap_delete_url = apiendpoint + f"/v3/profiles/{profile_name}"
    response = requests.delete(cdap_delete_url, headers=headers)
    if response.status_code == 200:
        return True
    else:
        return False


def get_dataproc_SA(serviceaccount, project, subnet, local_market, environment):
    sa_suffix = serviceaccount.split("@")[1]
    program = project.split("-")[2]
    sa_prefix = "vf-" + local_market + "-" + program
    return (sa_prefix + "-" + environment + "-dp-sa@" + sa_suffix)


def generate_auth_token_with_creds():
    credentials, _ = google.auth.default()
    credentials.refresh(Request())
    return credentials.token


def get_datafusion_apiendpoint(project, region, instance_id):
    service_cdap = generate_cdap_service_with_app_def_creds()
    parent = f"projects/{project}/locations/{region}"
    full_instance_path = f"{parent}/instances/{instance_id}"
    get_response = (
        service_cdap.projects()
        .locations()
        .instances()
        .get(name=full_instance_path)
        .execute()
    )
    return get_response["apiEndpoint"]


def main(
    project,
    region,
    instance_id,
    network,
    accountKey,
    serviceaccount,
    template_path,
    environment,
    local_markets_list
):
    auth_token = generate_auth_token_with_creds()
    profile_list = ["Low", "Medium", "High"]
    apiendpoint = get_datafusion_apiendpoint(project, region, instance_id)
    service_subnet = generate_service_with_app_def_creds()
    for local_market in local_markets_list:
        if local_market.lower() == "uk":
            region = "europe-west2"
        elif local_market.lower() == "de":
            region = "europe-west3"
        else:
            region = "europe-west1"
        networkTags = "allow-ssh-to-datafusion"
        networkTags = networkTags + "," + "allow-internal-dataproc-" + local_market

        # subnet = local_market.lower() + "-restricted-zone"
        subnet = project + "-subnet-" + local_market.lower()
        namespace = local_market
        profile_name = f"{namespace}_profile"
        accountKey_name = local_market.lower() + "-neuron-key"
        if create_namespace(auth_token, apiendpoint, namespace):
            if create_key_in_namespace(
                project,
                serviceaccount,
                namespace,
                apiendpoint,
                auth_token,
                accountKey_name,
                accountKey,
            ):
                dataproc_serviceaccount = get_dataproc_SA(serviceaccount, project, subnet, local_market, environment)
                for profile in profile_list:
                    profile_new_name = f"{profile}_{profile_name}"
                    data = parser.main(
                        accountKey_name,
                        region,
                        network,
                        subnet,
                        dataproc_serviceaccount,
                        profile_new_name,
                        template_path,
                        networkTags,
                    )
                    if not check_if_profile_exists(
                        auth_token, apiendpoint, profile_new_name
                    ):
                        create_profile(apiendpoint, auth_token, data, profile_new_name, namespace)
                        if profile == "Low":
                            set_default_profile_namespace(apiendpoint, auth_token, namespace, profile_new_name)
                if check_if_profile_exists(auth_token, apiendpoint, "dataproc"):
                    if disable_default_profile(apiendpoint, auth_token, "dataproc"):
                        if delete_preference(apiendpoint, auth_token):
                            delete_default_profile(apiendpoint, auth_token, "dataproc")

    sys.exit(0)


if __name__ == "__main__":
    project = sys.argv[1]
    region = sys.argv[2]
    instance_id = sys.argv[3]
    network = sys.argv[4]
    serviceAccount = sys.argv[5]
    template_path = sys.argv[6]
    local_markets = sys.argv[7]
    environment = sys.argv[8]
    local_markets_list = local_markets.split(",")
    with open(f"{template_path}/scripts/multitenant_script/key.json") as key:
        accountKey = json.load(key)
    main(
        project,
        region,
        instance_id,
        network,
        accountKey,
        serviceAccount,
        template_path,
        environment,
        local_markets_list
    )
