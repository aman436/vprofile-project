#!/usr/bin/env bash

set -e

project_name=$1
region=$2
instance_id=$3 
network_name=$4
datafusion_serviceaccount=$5
template_path=$6
local_markets=$7 # lm3
programs=$8  # ca

if [ -z ${programs} ]
then
    programs=`echo $project_name | cut -d - -f 3`
fi
cd platform
gcloud iam service-accounts keys create $template_path/scripts/key.json --iam-account $datafusion_serviceaccount
poetry run python $template_path/scripts/multitenant_commercial_script/create_datafusion_profile.py $project_name $region $instance_id $network_name $datafusion_serviceaccount $template_path $local_markets $programs
rm -rf $template_path/scripts/key.json