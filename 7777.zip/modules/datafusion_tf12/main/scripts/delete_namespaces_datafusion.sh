#!/usr/bin/env  bash

export AUTH_TOKEN=$(gcloud auth print-access-token)
export TARGET_PROJECT=$1 # project-id
export INSTANCE_ID=$2 # datafusion-id
export REGION=$3  # example europe-west1
export NAMESPACE=$4 # namespace_name
export CDAP_ENDPOINT=$(gcloud beta data-fusion instances describe --project ${TARGET_PROJECT} --location=${REGION} --format="value(apiEndpoint)" ${INSTANCE_ID})
sleep 2;
curl -H "Authorization: Bearer ${AUTH_TOKEN}"  -H "Content-Type: application/json" https://datafusion.googleapis.com/v1/projects/${TARGET_PROJECT}/locations/${REGION}/instances/${INSTANCE_ID} -X PATCH -d '{"options":{"enable.unrecoverable.reset":"true"}}'
profiles_prefix=("High_" "Medium_" "Low_")
echo $CDAP_ENDPOINT/v3/export/apps
echo ${CDAP_ENDPOINT}/v3/unrecoverable/namespaces/${NAMESPACE}
# disable compute profile for the namespace
for profile_prefix in ${profiles_prefix[*]}; do
echo "$(tput setaf 3)diable compute profile: "${profile_prefix}${NAMESPACE}_profile
tput setaf 7
curl -X POST  -H "Authorization: Bearer ${AUTH_TOKEN}"  -H "Content-Type: application/json" ${CDAP_ENDPOINT}/v3/namespaces/${NAMESPACE}/profiles/${profile_prefix}${NAMESPACE}_profile/disable
sleep 2;
done
sleep 2;
# before this you need to disable the compute profiles manually POST /v3/namespaces/<namespace-id>/profiles/<profile-name>/disable
curl -X DELETE  -H "Authorization: Bearer ${AUTH_TOKEN}"  -H "Content-Type: application/json" ${CDAP_ENDPOINT}/v3/unrecoverable/namespaces/${NAMESPACE}
echo "$(tput setaf 2) deleting namespace: " ${NAMESPACE} " done"

sleep 5;
curl -H "Authorization: Bearer ${AUTH_TOKEN}"  -H "Content-Type: application/json" https://datafusion.googleapis.com/v1/projects/${TARGET_PROJECT}/locations/${REGION}/instances/${INSTANCE_ID} -X PATCH -d '{"options":{"enable.unrecoverable.reset":"null"}}'

