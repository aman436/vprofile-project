import googleapiclient
from googleapiclient.discovery import build
import google.auth
import sys
import json
import logging
import requests
import time
import datafusion_profile_parser as parser
from google.auth.transport.requests import Request


def create_profile(cdap_url, access_token, data, profile_name, namespace):
    headers = {
        "Authorization": "Bearer " + access_token,
        "Content-Type": "application/json",
        "Accepts": "application/json",
    }
    cdap_url = cdap_url + f"/v3/namespaces/{namespace}/profiles/{profile_name}"

    response = requests.put(cdap_url, json=data, headers=headers)

    if response.status_code != 200:
        logging.log(
            logging.ERROR, f"Error while creating profile {response.status_code}"
        )
        sys.exit(1)


def create_key_in_namespace(
    project,
    service_account_email,
    namespace,
    api_endpoint,
    auth_token,
    accountKey_name,
    service_account_key,
):

    headers = {
        "Authorization": "Bearer " + auth_token,
        "Content-Type": "application/json",
    }
    data = {
        "description": "Neuron Secure Key",
        "data": str(service_account_key).replace("'", '"'),
    }
    cdap_url = api_endpoint + f"/v3/namespaces/{namespace}/securekeys/{accountKey_name}"
    response = requests.put(cdap_url, headers=headers, json=data)
    if response.status_code == 200:
        return True
    else:
        return False


def check_if_profile_exists(auth_token, api_endpoint, profile_name):
    headers = {
        "Authorization": "Bearer " + auth_token,
        "Content-Type": "application/json",
        "Accepts": "application/json",
    }

    cdap_url = api_endpoint + f"/v3/profiles/{profile_name}"
    response = requests.get(cdap_url, headers=headers)

    if response.status_code == 404:
        return False
    else:
        return True


def generate_service_with_app_def_creds():
    credentials, _ = google.auth.default()
    return build("compute", "v1", credentials=credentials)


def generate_cdap_service_with_app_def_creds():
    credentials, _ = google.auth.default()
    return build("datafusion", "v1beta1", credentials=credentials)


def create_namespace(auth_token, apiendpoint, namespace_name):
    headers = {
        "Authorization": "Bearer " + auth_token,
        "Content-Type": "application/json",
        "Accepts": "application/json",
    }
    cdap_url = apiendpoint + f"/v3/namespaces/{namespace_name}"
    response = requests.put(cdap_url, json={}, headers=headers)
    if response.status_code == 200:
        return True
    else:
        return False


def disable_default_profile(apiendpoint, auth_token, profile_name):
    headers = {
        "Authorization": "Bearer " + auth_token,
        "Content-Type": "application/json",
    }
    cdap_disable_url = apiendpoint + f"/v3/profiles/{profile_name}/disable"
    response = requests.post(cdap_disable_url, headers=headers)
    if response.status_code == 200:
        return True
    else:
        return False


def delete_preference(apiendpoint, auth_token):
    headers = {
        "Authorization": "Bearer " + auth_token,
        "Content-Type": "application/json",
    }
    cdap_delete_preference_url = apiendpoint + "/v3/preferences/"
    response = requests.delete(cdap_delete_preference_url, headers=headers)
    if response.status_code == 200:
        return True
    else:
        return False


def set_default_profile_namespace(apiendpoint, auth_token, namespace, profile_new_name):
    headers = {
        "Authorization": "Bearer " + auth_token,
        "Content-Type": "application/json",
    }
    data = {
        "system.profile.name": f"USER:{profile_new_name}"
    }
    cdap_pref_update_url = apiendpoint + f"/v3/namespaces/{namespace}/preferences"
    response = requests.put(cdap_pref_update_url, headers=headers, json=data)
    if response.status_code == 200:
        return True
    else:
        return False


def delete_default_profile(apiendpoint, auth_token, profile_name):
    headers = {
        "Authorization": "Bearer " + auth_token,
        "Content-Type": "application/json",
    }
    cdap_delete_url = apiendpoint + f"/v3/profiles/{profile_name}"
    response = requests.delete(cdap_delete_url, headers=headers)
    if response.status_code == 200:
        return True
    else:
        return False


def get_dataproc_SA(serviceaccount, project, subnet, local_market, program):
    sa_suffix = serviceaccount.split("@")[1]
    subnet_append = subnet.split("-")[0]
    #program = project.split("-")[2] + "-"
    #if "vf-grp-mc2compute" in project:
    #    program = "mc2cmp-"
    # sa_prefix = project.rsplit("-", 1)[:1][0] + "-"
    sa_prefix = "vf-" + local_market + "-" + program + "-"

    if subnet_append == "prepro3" or subnet_append == "prepro2":
        subnet_append = "preprod"
    elif subnet_append == "proda3" or subnet_append == "proda2":
        subnet_append = "proda"
    elif subnet_append == "proda3" or subnet_append == "proda2":
        subnet_append = "prodb"
    elif subnet_append == "dev3" or subnet_append == "dev2":
        subnet_append = "dev"
    elif subnet_append == "qa3" or subnet_append == "qa2":
        subnet_append = "qa"
    
    if subnet_append in ["preprod", "proda", "prodb"]:
        return (sa_prefix + subnet_append + "-dp-ops-sa@" + sa_suffix)
    else:
        return (sa_prefix + subnet_append + "-dp-ds-sa@" + sa_suffix)


def generate_auth_token_with_creds():
    credentials, _ = google.auth.default()
    credentials.refresh(Request())
    return credentials.token


def get_datafusion_apiendpoint(project, region, instance_id):
    service_cdap = generate_cdap_service_with_app_def_creds()
    parent = f"projects/{project}/locations/{region}"
    full_instance_path = f"{parent}/instances/{instance_id}"
    get_response = (
        service_cdap.projects()
        .locations()
        .instances()
        .get(name=full_instance_path)
        .execute()
    )
    return get_response["apiEndpoint"]


def main(
    project,
    region,
    instance_id,
    network,
    accountKey,
    serviceaccount,
    template_path,
    local_markets_list,
    programs_list
):
    auth_token = generate_auth_token_with_creds()
    profile_list = ["Low", "Medium", "High"]
    apiendpoint = get_datafusion_apiendpoint(project, region, instance_id)
    service_subnet = generate_service_with_app_def_creds()
    for local_market in local_markets_list:
        if local_market.lower() == "uk":
            region = "europe-west2"
        elif local_market.lower() == "de":
            region = "europe-west3"
        else:
            region = "europe-west1"
        request = service_subnet.subnetworks().list(project=project, region=region)
        response = request.execute()
        networkTags = "allow-ssh-to-datafusion,allow-egress-to-hpe"
        for subnetwork in response["items"]:
            networkTags = networkTags + "," + "allow-internal-dataproc-" + subnetwork["name"].split("-")[0]
        for subnetwork in response["items"]:
            subnet = subnetwork["name"]
            network = subnetwork["network"].rsplit("/", 1)[1]
            for program in programs_list: 
                namespace = local_market + "_" + program + "_" + subnet.replace("-", "_")
                profile_name = f"{namespace}_profile"
                accountKey_name = subnet.split("-")[0] + "-neuron-key"
                if subnet not in ["management-zone", "trusted-zone"]:
                    if create_namespace(auth_token, apiendpoint, namespace):
                        if create_key_in_namespace(
                            project,
                            serviceaccount,
                            namespace,
                            apiendpoint,
                            auth_token,
                            accountKey_name,
                            accountKey,
                        ):
                            dataproc_serviceaccount = get_dataproc_SA(serviceaccount, project, subnet, local_market, program)
                            for profile in profile_list:
                                profile_new_name = f"{profile}_{profile_name}"
                                data = parser.main(
                                    accountKey_name,
                                    region,
                                    network,
                                    subnet,
                                    dataproc_serviceaccount,
                                    profile_new_name,
                                    template_path,
                                    networkTags,
                                )
                                if not check_if_profile_exists(
                                    auth_token, apiendpoint, profile_new_name
                                ):
                                    create_profile(apiendpoint, auth_token, data, profile_new_name, namespace)
                                    if profile == "Low":
                                        set_default_profile_namespace(apiendpoint, auth_token, namespace, profile_new_name)
                            if check_if_profile_exists(auth_token, apiendpoint, "dataproc"):
                                if disable_default_profile(apiendpoint, auth_token, "dataproc"):
                                    if delete_preference(apiendpoint, auth_token):
                                        delete_default_profile(apiendpoint, auth_token, "dataproc")

    sys.exit(0)


if __name__ == "__main__":
    project = sys.argv[1]
    region = sys.argv[2]
    instance_id = sys.argv[3]
    network = sys.argv[4]
    serviceAccount = sys.argv[5]
    template_path = sys.argv[6]
    local_markets = sys.argv[7]
    local_markets_list = local_markets.split(",")
    programs = sys.argv[8]
    programs_list = programs.split(",")
    with open(f"{template_path}/scripts/key.json") as key:
        accountKey = json.load(key)
    main(
        project,
        region,
        instance_id,
        network,
        accountKey,
        serviceAccount,
        template_path,
        local_markets_list,
        programs_list
    )
