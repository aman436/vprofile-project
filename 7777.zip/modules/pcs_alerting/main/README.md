This Module is a port of 'fix_7_sha_monitoring finding' provided by PCS to address the SHA findings. 
listed out Here: https://confluence.sp.vodafone.com/pages/viewpage.action?spaceKey=GPCS&title=Security+Health+Analytics+Rulesets#SecurityHealthAnalyticsRulesets-LOGGINGANDMONITORINGPOLICIES 
 
This terraform Module creates log based metrics and its associated alerts.
This module will help keep neuron/nucleus projects consistent with the security related warning that are being reported from time to time.

**** Important Prerequisite: Make you have a workspace for your project ******
Before running this module, make sure to create a workspace, if it's not already created, as it can only be created via the console,
Kindly follow this link to create the workspace: "https://cloud.google.com/monitoring/workspaces/create#single-project-workspace"

**** The findings that will be remdiated by using this module
1) OWNER_NOT_MONITORED 
2) CUSTOM_ROLE_NOT_MONITORED 
3) FIREWALL_NOT_MONITORED 
4) NETWORK_NOT_MONITORED 
5) ROUTE_NOT_MONITORED 
6) BUCKET_IAM_NOT_MONITORED 
7) SQL_INSTANCE_NOT_MONITORED

Module call examples from project configuration:
  - name: pcs_alerting
    email_list: [ "John@vodafone.com", "Ankit@vodafone.com" ] (Optional*)

Recommendation: Use predefined Groups for DE/DS/PE/Owners/Ops created via PCS code base for your project.
https://github.vodafone.com/VFGroup-GDC-PCS/pcs-gcp-customer-yaml-config/tree/master/groups_mgmt 

