# Nucleus testing framework module

This modules makes it easy to set up a new [Nucleus testing framework](https://confluence.sp.vodafone.com/pages/viewpage.action?spaceKey=NB&title=Testing+Framework+-+Architecture%2C+Plan+and+Environment).

It supports creating:

- A Google Virtual Private Network (VPC)
- Four subnets within the VPC
- Service accounts with associated roles
- User groups policy
- Windows servers for Tosca software and bits server
- NAT instance associated with tosca commander server
- IAP to tosca servers
- Privet DNS records for private.googleapis.com and gcr.io

## Compatibility

This module is meant for use with Terraform 0.12.

## Usage

1. If you use VF windows laptop [Setup Neuron dev vm](https://confluence.sp.vodafone.com/pages/viewpage.action?spaceKey=BDPL&title=%5BDesign%5D+Neuron+Development+environment+in+GCP) or use your local Mac setup.
2. Clone [Neuron GCP project configs](https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-gcp-project-configs)
3. Check default variables for [Nucleus test framework](https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-gcp-platform/blob/master/resources/pipeline_test_frameworks_tf12.yml)
4. Follow [Development Process](https://confluence.sp.vodafone.com/display/BDPL/Versioning+v2+-+platform+engineering+releases)

## Naming convention used in this project

We used the following convention to name resources like service accounts, vm, nat...

```hcl
organisation-tenant-program-stage-name-resource
```

for example...  
service account: vf-hu-ngbi-poc-toscabits-sa  
vm: vf-hu-ngbi-poc-toscabits-vm

## Inputs

| Name                       | Description                                                      |  Type  |                    Default                     | Required |
| -------------------------- | ---------------------------------------------------------------- | :----: | :--------------------------------------------: | :------: |
| project_name               | The ID of the project where this framework will be created       | string |                      n/a                       |   yes    |
| region                     | Region to build infrastructure                                   | string |                  europe-west1                  |   yes    |
| zone                       | Zone to build infrastructure                                     | string |                 europe-west1-b                 |   yes    |
| vpc_name                   | Name of the VPC                                                  | string |                      ntf                       |   yes    |
| vpc_prefix                 | Prefix which would be added to all vpc                           | string |                    vf-group                    |   yes    |
| vpc_suffix                 | Suffix which would be added to all vpc                           | string |                      vpc                       |   yes    |
| organisation               | The organisation used to create names                            | string |                       vf                       |   yes    |
| tenant                     | The tenant used to create names                                  | string |                      n/a                       |   yes    |
| program                    | The program used to create names                                 | string |                      ngbi                      |   yes    |
| stage                      | The stage used to create names                                   | string |                      n/a                       |   yes    |
| tosca_commander_grp        | The google cloud group to limit access to tosca commander server | string |                      n/a                       |   yes    |
| tosca_agent_grp            | The google cloud group to limit access to tosca agent server     | string |                      n/a                       |   yes    |
| tosca_bits_grp             | The google cloud group to limit access to tosca bits server      | string |                      n/a                       |   yes    |
| restricted_zone_cidr_range | The restricted zone CIDR range                                   | string |                 172.20.23.0/24                 |   yes    |
| restricted_zone_name       | The restricted zone name                                         | string |                restricted-zone                 |   yes    |
| dmz_zone_cidr_range        | The DMZ zone CIDR range                                          | string |                 172.20.24.0/24                 |   yes    |
| dmz_zone_name              | The dmz zone name                                                | string |                    dmz-zone                    |   yes    |
| trusted_zone_cidr_range    | The trusted zone CIDR range                                      | string |                 172.20.22.0/24                 |   yes    |
| trusted_zone_name          | The trusted zone name                                            | string |                  trusted-zone                  |   yes    |
| management_zone_cidr_range | The management zone CIDR range                                   | string |                 172.20.21.0/28                 |   yes    |
| management_zone_name       | The management zone name                                         | string |                management-zone                 |   yes    |
| machine_type               | Tosca commander and agent machine type                           | string |                 n1-standard-2                  |   yes    |
| windows_image              | Windows image used by tosca commander and agent                  | string |        windows-server-2019-dc-v20200609        |   yes    |
| linux_image                | Linux image used by tosca tosca bits                             | string | vf-pcs-gcp-dev-ubuntu1804-2020-07-02t16-57-06z |   yes    |
| linux_size                 | Disk size for bits server                                        | number |                       50                       |   yes    |
| windows_size               | Disk size for tosca servers                                      | number |                      200                       |   yes    |

## Outputs

| Name                     | Description                                                                              |
| ------------------------ | ---------------------------------------------------------------------------------------- |
| tosca_commander_sa_email | Tosca commander service account email address. Used in BigQuery and Data Fusion projects |
| tosca_agent_sa_email     | Tosca agent service account email address. Used in BigQuery and Data Fusion projects     |
| tosca_bits_sa_email      | Tosca bits service account email address. Used in BigQuery and Data Fusion projects      |

## Requirements

### Installed Software

- [Terraform](https://www.terraform.io/downloads.html) ~> 0.12.6
- [Terraform Provider for GCP](https://github.com/terraform-providers/terraform-provider-google) ~> 2.0
- [Terraform Provider for GCP Beta](https://github.com/terraform-providers/terraform-provider-google-beta) ~>
  2.1
- [Vodafone Neuron platform](https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-gcp-platform/releases) ~> 1.4.17
