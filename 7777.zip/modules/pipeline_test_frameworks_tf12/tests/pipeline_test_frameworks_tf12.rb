# frozen_string_literal: true

def run_pipeline_test_frameworks_tf12(params)
  project_id = params['config']['project_id']
  control "#{project_id} : pipeline_test_frameworks_tf12 : " do
    title 'pipeline_test_frameworks_tf12 setup correctly'
    impact 0.4
  end
end
