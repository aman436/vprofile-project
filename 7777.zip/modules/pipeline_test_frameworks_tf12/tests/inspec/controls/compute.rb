control "google_compute_instance:: Tosca commander " do
  title "Tosca commander compute instance"
  desc  "Validate Tosca commander setup"
  impact 1.0
  describe google_compute_instance(:project=>input('project_name'),  :zone=>input('zone'), :name=>input('commander_server')) do
    its('status') { should eq 'RUNNING' }
    its('zone') {should include input('zone') }
    its('machine_type') { should include input('machine_type') }
    its('network_interfaces_count'){should eq 1}
  end
end

control "google_compute_instance:: Tosca agent " do
  title "Tosca agent compute instance"
  desc  "Validate Tosca agent setup"
  impact 1.0
  describe google_compute_instance(:project=>input('project_name'),  :zone=>input('zone'), :name=>input('agent_server')) do
    its('status') { should eq 'RUNNING' }
    its('zone') {should include input('zone') }
    its('machine_type') { should include input('machine_type') }
    its('network_interfaces_count'){should eq 1}
  end
end

control "google_compute_instance:: BITS " do
  title "BITS compute instance"
  desc  "Validate BITS setup"
  impact 1.0
  describe google_compute_instance(:project=>input('project_name'),  :zone=>input('zone'), :name=>input('bits_server')) do
    its('status') { should eq 'RUNNING' }
    its('zone') {should include input('zone') }
    its('machine_type') { should include input('machine_type') }
    its('network_interfaces_count'){should eq 1}
  end
end