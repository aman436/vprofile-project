control "google_project_iam_binding:: Tosca commander roles" do
  title "google_project_iam_binding::Tosca commander roles"
  desc "Test tosca commmander roles"
    impact 1.0
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/bigquery.dataViewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('commander_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/bigquery.jobUser") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('commander_sa')}
    end
end

control "google_project_iam_binding:: Tosca agent roles" do
  title "google_project_iam_binding::Tosca agent roles"
  desc "Test tosca agent roles"
    impact 1.0
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/bigquery.dataViewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('agent_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/bigquery.jobUser") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('agent_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/bigquery.user") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('agent_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/datafusion.viewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('agent_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/storage.objectViewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('agent_sa')}
    end
end

control "google_project_iam_binding:: Tosca commander users group roles" do
  title "google_project_iam_binding:: Tosca commander users group roles"
  desc "Test tosca commmander users group"
    impact 1.0
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/compute.viewer") do
      it { should exist }
      its('members') { should include 'group:'+input('commander_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/iap.tunnelResourceAccessor") do
      it { should exist }
      its('members') { should include 'group:'+input('commander_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/compute.osLogin") do
      it { should exist }
      its('members') { should include 'group:'+input('commander_group')}
    end
end

control "google_project_iam_binding:: Tosca agent users group roles" do
  title "google_project_iam_binding:: Tosca agent users group roles"
  desc "Test tosca agent users group"
    impact 1.0
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/compute.viewer") do
      it { should exist }
      its('members') { should include 'group:'+input('agent_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/iap.tunnelResourceAccessor") do
      it { should exist }
      its('members') { should include 'group:'+input('agent_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/compute.osLogin") do
      it { should exist }
      its('members') { should include 'group:'+input('agent_group')}
    end
end

control "google_project_iam_binding:: BITS users group roles" do
  title "google_project_iam_binding:: BITS users group roles"
  desc "Test BITS users group"
    impact 1.0
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/compute.viewer") do
      it { should exist }
      its('members') { should include 'group:'+input('bits_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/iap.tunnelResourceAccessor") do
      it { should exist }
      its('members') { should include 'group:'+input('bits_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/compute.osLogin") do
      it { should exist }
      its('members') { should include 'group:'+input('bits_group')}
    end
end

control "google_project_iam_binding:: BITS roles" do
  title "google_project_iam_binding:: BITS roles"
  desc "Test BITS roles"
    impact 1.0
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/bigquery.dataViewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('bits_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/bigquery.jobUser") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('bits_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/bigquery.user") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('bits_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/datafusion.viewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('bits_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/storage.objectViewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('bits_sa')}
    end
end