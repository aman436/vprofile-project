control "google_compute_firewall::Ingress" do
  title "google_compute_firewall::Allow IAP ingress traffic"
  desc "google_compute_firewall:: Firewall Rule to allow IAP ingress traffic"
    impact 1.0
    describe google_compute_firewall({:project=>input('project_name'), name: 'ssh-iap-tunnel'}) do
      it { should exist }
      its("direction") { should cmp "INGRESS" }
      its("source_ranges") { should cmp ["35.235.240.0/20"] }
      its("network") { should include input('network_name') }
    end
    describe google_compute_firewall({:project=>input('project_name'), name: 'rdp-iap-tunnel'}) do
      it { should exist }
      its("direction") { should cmp "INGRESS" }
      its("source_ranges") { should cmp ["35.235.240.0/20"] }
      its("network") { should include input('network_name') }
    end
end

