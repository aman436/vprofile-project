import json
import time


def update_compute_profile_main(base_compute_profile, main_name, value):
    if main_name in base_compute_profile:
        base_compute_profile[main_name] = value
    else:
        update_compute_profile_properties(base_compute_profile, main_name, value)


def update_compute_profile_properties(base_compute_profile, property_name, value):
    properties = base_compute_profile["provisioner"]["properties"]
    property_matched = next(
        filter(lambda prop: prop["name"] == property_name, properties)
    )
    property_matched["value"] = value


def compute_profile_main(base_compute_profile, profile_update):
    update_items = profile_update.items()
    for update in update_items:
        update_key = update[0]
        update_value = update[1]
        update_compute_profile_main(base_compute_profile, update_key, update_value)


def main(
    accountKey, region, network, subnet, serviceaccount, profile_name, template_path
):
    with open(f"{template_path}/scripts/base_profile.json") as profile:
        base_compute_profile = json.load(profile)
        account_key_to_update = "${secure(" + accountKey + ")}"
    profile_update = {
        "accountKey": account_key_to_update,
        "region": region,
        "network": network,
        "subnet": subnet,
        "serviceAccount": serviceaccount,
        "label": profile_name,
    }
    compute_profile_main(base_compute_profile, profile_update)
    return base_compute_profile
