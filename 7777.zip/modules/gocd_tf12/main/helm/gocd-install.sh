#!/bin/bash

kubectl get namespace gocd  || kubectl create namespace gocd
config_dir="platform/modules/gocd_tf12/main/helm"
helm upgrade --install -f ${config_dir}/values.gocd.yaml gocd vf-stable/gocd --namespace gocd --post-renderer  ${config_dir}/customize.sh
