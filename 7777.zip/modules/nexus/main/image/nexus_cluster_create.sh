#!/bin/bash
# maintainer: Biju Rayappan 
# purpose: Create BDP_shared_services Nexus cluster on GKE

#  CHANGE Values as needed !

readonly PROJECT='bdp-shared-services'
readonly CLUSTER='nexus-cluster-v1'
readonly REGION='europe-west1'

# Build a 3-node, single-region, multi-zone GKE cluster
time gcloud beta container \
  --project $PROJECT clusters create $CLUSTER \
  --region $REGION \
  --username "admin" \
  --cluster-version "1.11.8-gke.6" \
  --machine-type "n1-standard-2" \
  --image-type "COS" \
  --disk-type "pd-standard" \
  --disk-size "100" \
  --scopes "https://www.googleapis.com/auth/devstorage.read_write","https://www.googleapis.com/auth/logging.write","https://www.googleapis.com/auth/monitoring","https://www.googleapis.com/auth/servicecontrol","https://www.googleapis.com/auth/service.management.readonly","https://www.googleapis.com/auth/trace.append" \
  --num-nodes "1" \
  --enable-cloud-logging \
  --enable-cloud-monitoring \
  --enable-stackdriver-kubernetes \
  --no-enable-ip-alias \
  --network "projects/bdp-shared-services/global/networks/sharedservicevpc" \
  --subnetwork "projects/bdp-shared-services/regions/europe-west1/subnetworks/sharedservicecoresubnet" \
  --addons HorizontalPodAutoscaling,HttpLoadBalancing \
  --enable-autoupgrade \
  --enable-autorepair

# Get cluster creds
gcloud container clusters get-credentials $CLUSTER \
  --region $REGION --project $PROJECT

kubectl config current-context

echo "Waiting for Kubernetes cluster to become ready..."
until kubectl get pods --all-namespaces; do sleep 1; done

