    #!/bin/bash
# maintainer: Biju Rayappan
# purpose: check Nexus applicaion status on GKE

#  CHANGE ME!

readonly PROJECT='bdp-shared-services'
readonly CLUSTER='nexus-cluster-v1'
readonly REGION='europe-west1'
readonly NAMESPACE='nexusv1'

# Get cluster creds
gcloud container clusters get-credentials $CLUSTER \
  --region $REGION --project $PROJECT

kubectl config current-context

echo "getting the pod details..."
pod="$(kubectl get pod -n nexusv1 --output=name |cut -d '/' -f 2)"
echo " current pod name : $pod "
kubectl exec -it $pod -n nexusv1 -- nexus3 repo create proxy pypi pypi-proxy https://pypi.org/ --blob=default
kubectl exec -it $pod -n nexusv1 -- nexus3 repo create proxy maven geotools http://download.osgeo.org/webdav/geotools/ --blob=default
kubectl exec -it $pod -n nexusv1 -- nexus3 repo create proxy maven jboss-releases-proxy https://repository.jboss.org/nexus/content/repositories/releases --blob=default
kubectl exec -it $pod -n nexusv1 -- nexus3 repo create proxy maven paho-releases-proxy https://repo.eclipse.org/content/repositories/paho-releases --blob=default
kubectl exec -it $pod -n nexusv1 -- nexus3 repo create proxy maven spark-packages https://dl.bintray.com/spark-packages/maven/ --blob=default
kubectl exec -it $pod -n nexusv1 -- nexus3 repo create proxy maven spring-io-libs-proxy https://repo.spring.io/libs-release --blob=default
kubectl exec -it $pod -n nexusv1 -- nexus3 repo create proxy maven twttr-proxy http://maven.twttr.com --blob=default

