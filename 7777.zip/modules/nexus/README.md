# Getting started

## Introduction

This deployment sets up a Nexus instance complete with backup in GCS bucket. 

## Pre-Requisites
1. Kubernetes cluster with scope Cloud Storage read-write permissions enabled
  (https://www.googleapis.com/auth/devstorage.read_write scope)
2. GCS bucket for nexus-backup ( Lifecycle policy set or permission to set Lifecycle policy)
   Dev GCS backup location : gs://vf-tmp-nexus-backup-storage
3. default credentials used in the secret and needs to be changed for Production Release
4. Vodafone Internal SSL certificate used for https 
5. Create a new Load balancer / Ingress service for Production 


## Backup and Retention 
Nexus has a built-in backup task which can be used to backup configuration and metadata. But it doesn't include blob store only the DB. 
In this implementation there is an additional container included with the configuration called nexus-backup, It is a dummy  container which creates the backups of  blob store and uploads them the  confiured GCS bucket along with the other backup files. These backups are triggered by another Nexus task job 


## Nexus Installation 
After creating the K8s cluster running the below YAML files create the required resources to run Nexus on K8s, 
 ** ( Please make sure the Namespace are updated if changing )


1. kubectl apply -f ns.yaml 
2. kubectl apply -f nexus_pvc.yaml
3. kubectl apply -f nexus_backup_pvc.yaml
4. kubectl apply -f nexus-secret.yaml
5. kubectl apply -f deployment.yaml
6. kubectl apply -f service.yaml


## Post Installation 
Running the script ./nexus-update.sh will create the required Proxy Repository for Nexus 
  ( Need namespace / clustername variables updated ) 
  

## Backup Task Configuration 
The limitation of CLI / API clients on nexus means we are unable to create tasks on commandline, so we will have to configure them manually for the first time. 
2 backup jobs needs to be configured and details cane found here : https://confluence.sp.vodafone.com/display/BDPL/GCP+-+Nexus+OSS 
