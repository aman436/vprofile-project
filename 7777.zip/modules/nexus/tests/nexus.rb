# frozen_string_literal: true

def run_nexus(params)
  project_id = params['config']['project_id']
  control "#{project_id} : nexus : " do
    title 'nexus zone page setup correctly'
    impact 0.6
  end
end
