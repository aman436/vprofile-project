## How to build the squid image

1) To build the Docker image, run the following Docker command from the directory containing the image's files:

```sh
marius_palimariu@cloudshell:~/neuron-gcp-platform/shared-services/squid$ docker build -t squid-image .

Sending build context to Docker daemon  9.728kB
Step 1/11 : FROM ubuntu:bionic-20181204
bionic-20181204: Pulling from library/ubuntu
84ed7d2f608f: Pull complete
be2bf1c4a48d: Pull complete
a5bdc6303093: Pull complete
e9055237d68d: Pull complete
Digest: sha256:868fd30a0e47b8d8ac485df174795b5e2fe8a6c8f056cc707b232d65b8a1ab68
Status: Downloaded newer image for ubuntu:bionic-20181204
 ---> 1d9c17228a9e
Step 2/11 : ENV SQUID_VERSION=3.5.27     SQUID_CACHE_DIR=/var/spool/squid     SQUID_LOG_DIR=/var/log/squid     SQUID_USER=proxy
 ---> Running in a0a01140c48a
```

2) Tag the docker image by using the container registry within your project `ex: vf-grp-shared-services-nonlive` 
 
```sh
marius_palimariu@cloudshell:~/neuron-gcp-platform/shared-services/squid $ docker tag squid-image eu.gcr.io/vf-grp-shared-services-nonlive/squid-image:latest
```

3) Push the docker image by using the container registry within your project `ex: vf-grp-shared-services-nonlive`

```sh
marius_palimariu@cloudshell:~/neuron-gcp-platform/shared-services/squid $ docker push eu.gcr.io/vf-grp-shared-services-nonlive/squid-image:latest

The push refers to repository [eu.gcr.io/vf-grp-shared-services-nonlive/squid-image]
3a8898dc1b34: Pushed
747b62b1cade: Pushed
fc5d6666267a: Pushed
549f3228a25d: Pushed
3245db0501b4: Pushed
d7a39ec58df2: Pushed
683c27d4b91d: Pushed
2c77720cf318: Layer already exists
1f6b6c7dc482: Layer already exists
c8dbbe73b68c: Layer already exists
2fb7bfc6145d: Layer already exists
latest: digest: sha256:d7a91bc3ad8a20eb75b6fb19228a0d7330b2a9957a946fae31f2a2061faa8bbb size: 2604
```

4) Update the squid.yml deployment file with the squid-image repository

```sh
spec:
      containers:
      - name: squid
        image: eu.gcr.io/vf-grp-shared-services-nonlive/squid-image
        ports:
        - containerPort: 3128
```

5)  Create squid-deployment by running : kubectl create -f squid.yaml
