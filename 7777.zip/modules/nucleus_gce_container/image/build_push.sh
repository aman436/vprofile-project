# source build_push.sh  vf-grp-tosca-lab-01 tosca-v1.36
docker build . -t eu.gcr.io/$1/squid-image:$2
docker push eu.gcr.io/$1/squid-image:$2