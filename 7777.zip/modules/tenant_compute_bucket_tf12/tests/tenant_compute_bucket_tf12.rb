# frozen_string_literal: true

def run_tenant_compute_bucket_tf12(params)
  project_id = params['config']['project_id']
  control "#{project_id} : #{params['config']['module_name']}" do
    title 'run_tenant_compute_bucket_tf12 setup correctly'
    impact 0.4
    params["variables"]["buckets"].each do |bucket|
      describe google_storage_bucket(name: bucket["name"]) do
        it { should exist }
        if bucket["key_id"] == nil && params["variables"]["key_id"] != nil
          its('encryption.default_kms_key_name'){ should eq params["variables"]["key_id"] }
        elsif bucket["key_id"] != nil && !(bucket["key_id"].include? "${")
          its('encryption.default_kms_key_name'){ should eq bucket["key_id"] }
        end
        if bucket["location"] == nil
          location = params["variables"]["location"].upcase
          its('location'){ should eq location }
        elsif bucket["location"] != nil && !(bucket["location"].include? "${")
          its('location'){ should eq bucket["location"].upcase! }
        end
        if bucket["storage_class"] != nil
          its('storage_class'){ should eq bucket["storage_class"] }
        else
          its('storage_class'){ should eq 'REGIONAL' }
        end
        its('labels'){ should eq bucket["labels"] }
        if bucket["versioning"] != nil
          its('versioning.enabled') { should eq bucket["versioning"] }
        else
          its('versioning.enabled') { should eq true }
        end
#         TODO: Tests for lifecycle
      end
    end
  end
end
