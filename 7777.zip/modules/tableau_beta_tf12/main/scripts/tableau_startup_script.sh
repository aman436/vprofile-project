#!/usr/bin/env bash

# This script has been developped with VSCode remote SSH extension.
# I connected directly to tableau compute nodes and executed the script there.
# If any chages to this scripts are required, please test a full cluster setup procedure.

set -e # exit on non zero status commands (failed)
set -a # export all functions to subshells
set -x # debug mode

function main() {
    log "Starting the Tableau cluster init script"

    # globals
    initial_user="mai.elmorsy@vodafone.com"
    metadata_url="http://metadata.google.internal/computeMetadata/v1/instance"
    proxy="http://outbound-proxy.neuron.tableau.vf.local:3128/"
    no_proxy="tableau-node1.c.vf-grp-tableau-nonlive.internal,tableau-node1,localhost,127.0.0.1,tableau-node2.c.vf-grp-tableau-nonlive.internal,tableau-node2,tableau-node3.c.vf-grp-tableau-nonlive.internal,tableau-node3,172.20.23.10,172.20.23.11,172.20.23.12"

    machine_id=$(curl -s "$metadata_url/id" -H "Metadata-Flavor: Google")
    log "Machine ID: $machine_id"

    node_role="$(get_instance_attribute 'tableau_node_role')"
    binaries_bucket="gs://$(get_instance_attribute 'binaries_bucket')"
    config_bucket="gs://$(get_instance_attribute 'config_bucket')"
    admin_password="$(get_secret 'encrypted_admin_password')"

    worker_lock_name="$config_bucket/worker_lock.txt"

    run_step "Preparing the machine" step_prepare_machine
    run_step "Installing Tableau binaries" wait_for_success step_install_tableau_binaries
    run_step "Create tabadmin linux user account" step_create_tabadmin

    if [ "$node_role" == "master" ]; then
        initialize_tableau_master
    fi
    if [ "$node_role" == "worker" ]; then
        initialize_tableau_worker
    fi
}

function initialize_tableau_master() {
    log "=== Master node "

    # master globals
    tableau_server_license="$(get_secret 'encrypted_tableau_license')"

    run_step "Initializing TSM" step_initialize_tsm

    su -c initialize_tableau_master_as_tabadmin -s /bin/bash tabadmin

    run_step "Apply mapsconfig fix" step_fix_mapsconfig
    run_step "Setup crontab" step_setup_crontab
}

function initialize_tableau_master_as_tabadmin() {
    set -e # exit on non zero status commands (failed)
    set -a # export all functions to subshells
    set -x # debug mode

    log "=== Tabadmin initialization"
    cd ~

    run_step "Apply Tableau Server license" step_apply_license
    run_step "Apply Tableau configuration" step_tsm_apply_config
    run_step "Start Tableau master server" step_initialize_server
    run_step "Generate bootstrap file" step_generate_node_bootstrap_file
    # Wait is required here to allow the workers to fully connect
    run_step "Setting cluster controller nodes" step_set_clustercontrollers
    run_step "Activate HA Coordination Service" step_activate_coordination_service
    run_step "Cleanup old Coordination Service" step_cleanup_activate_coordination_service
    run_step "Activate Cluster HA services" step_activate_cluster_ha_services

    run_step "Import parametrized settings" step_import_parametrized_settings
    run_step "Setup backup scripts" step_setup_backup_scripts

    log "=== finish Tabadmin"
}

function initialize_tableau_worker() {
    log "Tableau worker: Waiting for bootstrap.json..."
    wait_for_success gcs_file_exists "$config_bucket/tableau_bootstrap.json"

    log "Acquiring worker setup lock..."
    wait_for_success gcs_file_put "$worker_lock_name"
    trap worker_cleanup INT TERM EXIT

    log "Initializing tableau worker node"

    run_step "Initialize tsm worker" wait_for_success step_initialize_tsm_worker
    run_step "Appply mapsconfig fix" step_fix_mapsconfig

    wait_for_success gcs_release_lock "$worker_lock_name"
}

### Steps implementation

function step_prepare_machine() {
    mkfs.ext4 -m 0 -F -E lazy_itable_init=0,lazy_journal_init=0,discard /dev/sdb
    mkdir -p /opt/tableau
    mount -o discard,defaults /dev/sdb /opt/tableau
    chmod a+w /opt/tableau
    cp /etc/fstab /etc/fstab.backup
    echo UUID="$(blkid -s UUID -o value /dev/sdb)" /opt/tableau ext4 discard,defaults,nofail 2 |
        tee -a /etc/fstab
}

function step_install_tableau_binaries() {
    gsutil cp "$binaries_bucket/tableau-server-2019-3-0.x86_64.rpm" .
    yum install tableau-server-2019-3-0.x86_64.rpm -y

    gsutil cp "$binaries_bucket/tableau-postgresql-odbc-09.06.0500-1.x86_64.rpm" .
    yum install ./tableau-postgresql-odbc-09.06.0500-1.x86_64.rpm -y
}

function step_create_tabadmin() {
    useradd tabadmin \
        --shell=/bin/bash

    echo "tabadmin:$admin_password" | chpasswd
}

function step_apply_license() {
    tsm licenses activate --license-key "$tableau_server_license" --trust-admin-controller-cert
}

function step_tsm_apply_config() {
    gsutil cp "$config_bucket/tableau_reg_file.json" .
    tsm register --file tableau_reg_file.json

    gsutil cp "$config_bucket/identity.json" .
    tsm settings import -f identity.json

    wait_for_success tsm pending-changes apply --ignore-warnings --ignore-prompt
}

function step_initialize_server() {
    tsm initialize \
        --start-server \
        --request-timeout 1800

    tabcmd initialuser \
        --server 'localhost:80' \
        --username "$initial_user" \
        --password "$admin_password"
}

function step_generate_node_bootstrap_file() {
    tsm topology nodes get-bootstrap-file -f ./bootstrap.json

    gsutil cp ./bootstrap.json "$config_bucket/tableau_bootstrap.json"
}

function step_initialize_tsm() {
    /opt/tableau/tableau_server/packages/scripts.20193.19.0913.2225/initialize-tsm \
        --accepteula \
        -a tabadmin \
        -d /opt/tableau/tableau_server_data/ \
        --http_proxy=$proxy \
        --https_proxy=$proxy \
        --no_proxy=$no_proxy \
        -f # skips locale issue

    source /etc/profile.d/tableau_server.sh
}

function step_initialize_tsm_worker() {
    gsutil cp "$config_bucket/tableau_bootstrap.json" ./bootstrap.json

    /opt/tableau/tableau_server/packages/scripts.20193.19.0913.2225/initialize-tsm \
        -b ./bootstrap.json \
        --accepteula \
        -d /opt/tableau/tableau_server_data/ \
        --http_proxy=$proxy \
        --https_proxy=$proxy \
        --no_proxy=$no_proxy \
        -a tabadmin \
        -u tabadmin \
        -p "$admin_password" \
        -f || return $?
}

function step_fix_mapsconfig() {
    local file
    file="/opt/tableau/tableau_server/packages/vizqlserver.20193.19.0913.2225/Mapsources/Tableau.tms"
    sed -i 's/mapsconfig.tableau.com/mapsconfig.tableau.com:443/g' $file
}

function step_set_clustercontrollers() {
    wait_for_success tsm topology set-process -n node2 -pr clustercontroller -c 1
    wait_for_success tsm topology set-process -n node3 -pr clustercontroller -c 1
    wait_for_success tsm pending-changes apply --ignore-warnings --ignore-prompt
}

function step_activate_coordination_service() {
    tsm stop
    wait_for_success tsm topology deploy-coordination-service -n node1,node2,node3
}

function step_cleanup_activate_coordination_service() {
    wait_for_success tsm topology cleanup-coordination-service
    tsm start
}

function step_activate_cluster_ha_services() {
    wait_for_success tsm topology set-process -n node2 -pr gateway -c 1
    tsm topology set-process -n node2 -pr vizqlserver -c 2
    tsm topology set-process -n node2 -pr vizportal -c 2
    tsm topology set-process -n node2 -pr backgrounder -c 2
    tsm topology set-process -n node2 -pr cacheserver -c 2
    tsm topology set-process -n node2 -pr searchserver -c 1
    tsm topology set-process -n node2 -pr dataserver -c 2
    tsm topology set-process -n node2 -pr filestore -c 1
    tsm topology set-process -n node2 -pr pgsql -c 1
    wait_for_success tsm pending-changes apply --ignore-warnings --ignore-prompt
    tsm topology set-process -n node3 -pr gateway -c 1
    tsm topology set-process -n node3 -pr vizqlserver -c 2
    tsm topology set-process -n node3 -pr vizportal -c 2
    tsm topology set-process -n node3 -pr backgrounder -c 2
    tsm topology set-process -n node3 -pr cacheserver -c 2
    tsm topology set-process -n node3 -pr searchserver -c 1
    tsm topology set-process -n node3 -pr dataserver -c 2
    tsm topology set-process -n node3 -pr filestore -c 1
    wait_for_success tsm pending-changes apply --ignore-warnings --ignore-prompt
}

function step_import_parametrized_settings() {
    wait_for_success gsutil cp "$config_bucket/settings.json" ./settings.json
    tsm settings import -f ./settings.json
    wait_for_success tsm pending-changes apply --ignore-warnings --ignore-prompt
}

function step_setup_backup_scripts() {
    wait_for_success gsutil cp "$config_bucket/tableau_cron_backup_script.sh" ./tableau_cron_backup_script.sh
    chmod +x ./tableau_cron_backup_script.sh

    wait_for_success gsutil cp "$config_bucket/tableau_cron_log_cleanup.sh" ./tableau_cron_log_cleanup.sh
    chmod +x ./tableau_cron_log_cleanup.sh
}

function step_setup_crontab() {
    crontab -u tabadmin - <<EOS
00 00 * * * /home/tabadmin/tableau_cron_backup_script.sh
00 01 * * * /home/tabadmin/tableau_cron_log_cleanup.sh
EOS
}

### Utility functions

function log() {
    echo "[vf_tableau_init_script] $1"
}

function get_instance_attribute() {
    local attribute=$1
    local attributes_url
    attributes_url="$metadata_url/attributes"
    curl -s "$attributes_url/$attribute" -H "Metadata-Flavor: Google"
}

function worker_cleanup() {
    exit_code=$?
    gcs_release_lock "$worker_lock_name"
    exit $exit_code
}

function get_secret() {
    # Use this to encrypt secrets
    # echo -n my-secret-password | gcloud kms encrypt \
    #     --project $project \
    #     --location $key_location \
    #     --keyring tableau_keyring \
    #     --key tableau_key \
    #     --plaintext-file - \
    #     --ciphertext-file - \
    #     | base64

    local secret_name=$1

    local encrypted_secret
    encrypted_secret="$(get_instance_attribute "$secret_name")"

    local region
    region="$(get_instance_attribute region)"

    if [ -z "$encrypted_secret" ]; then
        echo "Secret not provided in instance metadata: $secret_name" >/dev/stderr
        exit 1
    fi

    echo -n "$encrypted_secret" | base64 -d | gcloud kms decrypt \
        --location "$region" \
        --keyring "tableau_keyrings" \
        --key "tableau_keys" \
        --plaintext-file - \
        --ciphertext-file -

}

function gcs_release_lock() {
    local lock_name=$1
    gsutil -q rm "$lock_name" || return $?
}

function gcs_file_exists() {
    local file_name=$1
    gsutil -q stat "$file_name" >/dev/null 2>&1
}

function gcs_file_put() {
    local file_name=$1
    # this will fail if the file exists or is being created
    echo "content" | gsutil -q -h "x-goog-if-generation-match:0" cp - "$file_name"
}

function wait_for_success() {
    log "Waiting for command to succeed: '$*'"

    while true; do # retry untill success
        lock_command_status=0
        "$@" || lock_command_status=$? # exec all params here and catch errors

        if [ "$lock_command_status" == "0" ]; then
            break # stop retrying after first success
        fi

        sleep 5
    done
}

function run_step() {
    local description=$1
    shift # remove description from $@

    local step_lock_file
    step_lock_file="$config_bucket/$machine_id/$(echo -e "$@" | tr -d '[:space:]')"
    exit_status=0

    gcs_file_exists "$step_lock_file" || exit_status=$?
    if [ "$exit_status" -eq "0" ]; then
        log "Skipping: $description"
        return 0 # do not repeat steps
    fi

    log "Running: $description"

    "$@" # run the remaining arguments

    gcs_file_put "$step_lock_file"
    log "Finished: $description"
}

time main # Run main function
