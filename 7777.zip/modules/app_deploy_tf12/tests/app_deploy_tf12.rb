# frozen_string_literal: true

def run_app_deploy_tf12(params)

  config     = params['config']
  variables  = params['variables']

  control "google_service_account::projects/#{config['project_id']}/serviceAccounts/app-deploy@#{config['project_id']}.iam.gserviceaccount.com" do
    title "correctly configured"
    impact 1.0
    describe google_service_account({:project=> "#{config['project_id']}", :name=>"app-deploy@#{config['project_id']}.iam.gserviceaccount.com"}) do
      it { should exist }
      its("display_name") { should cmp "APP DEPLOY SA" }
      its("email") { should cmp "app-deploy@#{config['project_id']}.iam.gserviceaccount.com" }
      its("name") { should cmp "projects/#{config['project_id']}/serviceAccounts/app-deploy@#{config['project_id']}.iam.gserviceaccount.com" }
    end
  end
end
