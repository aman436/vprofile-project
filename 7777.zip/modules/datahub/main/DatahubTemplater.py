# mypy: ignore-errors

from templater.main.ModulePythonTemplater import ModulePythonTemplater
from typing import Type, Tuple
import itertools
import logging
import yaml


def shared_services_reverse_lookup(project_name):
    org, tenant, *rest = project_name.split("-")
    mapping = {
        "eng": "eng",
        "eng2": "eng",
        "dev": "lab",
        "poc": "lab",
        "poc2": "lab",
        "sit": "sit",
        "uat": "sit",
        "lm1": "nonlive",
        "lm2": "nonlive",
        "lm3": "nonlive",
        "tst": "nonlive",
    }
    ss_suffix = mapping[tenant] if tenant in mapping.keys() else "live"
    return f"vf-grp-shared-services-{ss_suffix}"


class DatahubTemplater(ModulePythonTemplater):
    def _merge_dicts(self, dict_1: dict, dict_2: dict) -> dict:
        comp_dict: dict = dict_1.copy()
        for key in list(set(dict_1.keys()) & set(dict_2.keys())):
            comp_dict[key] += dict_2[key]
        for key in list(set(dict_2.keys()) - set(comp_dict.keys())):
            comp_dict[key] = dict_2[key]
        return comp_dict

    def _flatten_and_merge(self, base_dict: dict, dict_list: list) -> dict:
        comp_dict: dict = base_dict.copy()
        for _dict in dict_list:
            comp_dict = self._merge_dicts(comp_dict.copy(), _dict.copy())
        return comp_dict

    def _create_bucket_iam_details_dict(self, datahub_config: dict) -> dict:
        bucket_list: list = [
            bucket_key.replace("_bucket_list", "")
            for bucket_key in datahub_config.keys()
            if "_bucket_list" in bucket_key
        ]
        return {
            name: {
                "iam_role_list": (
                    datahub_config[f"iam_role_list_{name}"]
                    if f"iam_role_list_{name}" in datahub_config.keys()
                    else []
                ),
                "kms_role_list": (
                    datahub_config[f"kms_role_list_{name}"]
                    if f"kms_role_list_{name}" in datahub_config.keys()
                    else []
                ),
                "bucket_list": datahub_config[f"{name}_bucket_list"],
                "member_list": datahub_config.get(f"{name}_members", []),
            }
            for name in bucket_list
        }

    def add_service_accounts(self, datahub_config: dict) -> str:
        # Add service accounts
        service_account_code_str: str = "# Adding Service Accounts \n"
        if "service_account_list" in datahub_config.keys():
            for sa_dict in datahub_config["service_account_list"]:
                service_account_code_str += self.Jinja.run_template(
                    template_name="terraform_service_account",
                    params={
                        "project_id": datahub_config["project_id"],
                        "program": sa_dict["program"],
                        "persona": sa_dict["sa_sub_str"],
                        "project_tenant": datahub_config["tenant"],
                        "service_account_desc": f"{sa_dict['sa_desc']} Service Account",
                    },
                )
        return f"{service_account_code_str}\n"

    def add_buckets(self, config: dict, comp_bucket_list: list) -> str:
        # Add buckets
        terraform_bucket_str: str = ""

        for bucket_dict in comp_bucket_list:
            if bucket_dict["name"] not in terraform_bucket_str:
                terraform_bucket_str += self.Jinja.run_template(
                    template_name="terraform_bucket",
                    params={
                        "tenant": config["tenant"],
                        "project_id": config["project_id"],
                        "bucket_dict": bucket_dict,
                        "location": config["location"],
                        "storage_class": config["storage_class"],
                        "project_initials": "dh",
                        "CMEK_key_type": "agf"
                        if bucket_dict["name"]
                        in ["export-clear", "rawingested", "vault-secrets"]
                        else "base",
                    },
                )
            else:
                # This duplication isn't usually an issue due to being needed to specify
                # different programs i.r.t service account IAM on the buckets
                logging.info(f"Attempting to duplicate bucket {bucket_dict['name']}")
        return f"{terraform_bucket_str}\n"

    def pull_sub_role_dict_details(
        self, sub_role_dict: dict, datahub_config: dict
    ) -> Tuple[str, str, str]:
        tenant: str = (
            sub_role_dict["tenant"]
            if "tenant" in sub_role_dict.keys()
            else datahub_config["tenant"]
        )
        if sub_role_dict["stage"] == "datahub":
            sa_project: str = (
                f"vf-{tenant}-{sub_role_dict['stage']}-{datahub_config['project_suffix']}"
                if "project_suffix" in datahub_config.keys()
                else f"vf-{tenant}-{sub_role_dict['stage']}"
            )
        elif sub_role_dict["stage"] == "shared-services":
            sa_project: str = shared_services_reverse_lookup(
                datahub_config["project_name"]
            )
        else:
            sa_project: str = (
                f"vf-{tenant}-{sub_role_dict['program']}-{sub_role_dict['stage']}"
            )
        sa_name: str = (
            f"vf-{tenant}-{sub_role_dict['program']}-{sub_role_dict['sa_sub_str']}-sa"
            if "sa_name" not in sub_role_dict.keys()
            else sub_role_dict["sa_name"]
        )
        return tenant, sa_project, sa_name

    def add_iam_roles(self, datahub_config: dict, iam_role_dict: dict) -> str:
        terraform_iam_str: str = ""
        for bucket_type in iam_role_dict.keys():
            terraform_iam_str += f"# Adding IAM SA Roles for {bucket_type}\n"
            for bucket_dict in iam_role_dict[bucket_type]["bucket_list"]:
                # Add IAM roles
                bucket_name: str = bucket_dict["name"]
                terraform_iam_str += f"# Creating IAM Roles for bucket: {bucket_name}\n"
                for sub_role_dict in iam_role_dict[bucket_type]["iam_role_list"]:
                    tenant, sa_project, sa_name = self.pull_sub_role_dict_details(
                        sub_role_dict, datahub_config
                    )
                    for role in sub_role_dict["roles"]:
                        resource_name: str = (
                            f"{bucket_name}_{sa_name}_{role}_{sa_project}".replace(
                                "-", "_"
                            )
                            .replace(" ", "")
                            .replace(".", "_")
                            .lower()
                        )

                        if resource_name not in terraform_iam_str:
                            terraform_iam_str += self.Jinja.run_template(
                                template_name="terraform_iam_roles",
                                params={
                                    "bucket_base_name": bucket_name,
                                    "tenant": tenant,
                                    "project_tenant": datahub_config["tenant"],
                                    "role": role,
                                    "service_account_name": sa_name,
                                    "service_account_project": sa_project,
                                    "resource_name": resource_name,
                                },
                            )
                for sub_role_dict in iam_role_dict[bucket_type]["kms_role_list"]:
                    # Add KMS roles
                    tenant, sa_project, sa_name = self.pull_sub_role_dict_details(
                        sub_role_dict, datahub_config
                    )

                    resource_name: str = (
                        f"kms_{bucket_name}_{sa_name}_{sub_role_dict['roles'][0]}".replace(
                            "-", "_"
                        )
                        .replace(" ", "")
                        .replace(".", "_")
                        .lower()
                    )

                    if resource_name not in terraform_iam_str:
                        terraform_iam_str += self.Jinja.run_template(
                            template_name="terraform_kms_iam_roles",
                            params={
                                "tenant": tenant,
                                "role": sub_role_dict["roles"][0],
                                "service_account_name": sa_name,
                                "service_account_project": sa_project,
                                "resource_name": resource_name,
                                "CMEK_key_type": sub_role_dict["key_name"],
                            },
                        )
            terraform_iam_str += "\n"
        return terraform_iam_str

    def _make_accesses(
        self, config: dict, bucket_dict: dict, iam_role_dict: dict, bucket_type: str
    ) -> list:
        iam_roles = iam_role_dict[bucket_type]["iam_role_list"]

        accesses = []
        for iam_entry in iam_roles:
            tenant, sa_project, sa_name = self.pull_sub_role_dict_details(
                iam_entry, config
            )

            role = "WRITER" if len(iam_entry["roles"]) > 2 else "READER"

            if "sa_sub_str" not in iam_entry:
                raise Exception(f"iam entry fucked up: {iam_entry}")

            access = {
                "user": f"{ sa_name }@{ sa_project }.iam.gserviceaccount.com",
                "role": role,
            }

            accesses.append(access)

        return accesses

    def add_bigquery_datasets(
        self, config: dict, comp_bucket_list: list, iam_role_dict: dict
    ) -> str:
        # What this does:
        # 1. spins through the datahub bucket config list
        # 2. creates a dataset per bucket with a naming convention, additionally replacing dash with underscore (bq limitation)
        # 3. adds explicit access to the dataset
        # 4. adds CMEK on the dataset
        #
        # What this does not do:
        # 1. Add any tables (and therefore no views) assume BIF will do this
        # 2. permission any tables or views

        bigquery_datasets_str: str = ""
        logging.info(f"heRE Attempting to duplicate dataset")

        for bucket_type in iam_role_dict.keys():
            for bucket_dict in iam_role_dict[bucket_type]["bucket_list"]:
                if (
                    "processed" not in bucket_dict["name"]
                    and "rawprepared" not in bucket_dict["name"]
                    and "error" not in bucket_dict["name"]
                ):
                    continue

                str1: str = bucket_dict["name"]
                resource_name: str = (f"{str1}".replace("-", "_"))

                logging.info(f"Attempting to do dataset {resource_name}")

                #            if bucket_dict["name"] not in bigquery_datasets_str:

                if resource_name not in bigquery_datasets_str:

                    accesses = self._make_accesses(
                        config, bucket_dict, iam_role_dict, bucket_type
                    )

                    for member in iam_role_dict[bucket_type]["member_list"]:
                        access = {"user": "", "group": False, "role": "READER"}

                        if "group:" in member:
                            access["group"] = True
                            access["user"] = member.split(":")[1]

                        if "-ops-" in member:
                            access["role"] = "OWNER"

                        accesses.append(access)

                    location = config.get("location", "EU")
                    if "europe-west1" in location.lower():
                        location = "EU"

                    bigquery_datasets_str += self.Jinja.run_template(
                        template_name="terraform_bigquery",
                        params={
                            "tenant": config["tenant"],
                            "project_id": config["project_id"],
                            "bucket_dict": bucket_dict,
                            "bucket_name": resource_name,
                            "location": location,
                            "accesses": accesses,
                            "CMEK_key_type": "bq"
                            if bucket_dict["name"]
                            in ["export-clear", "rawingested", "vault-secrets"]
                            else "base",
                        },
                    )
                else:
                    # This duplication isn't usually an issue due to being needed to specify
                    # different programs i.r.t service account IAM on the buckets
                    logging.info(
                        f"Attempting to duplicate dataset {bucket_dict['name']}"
                    )
        return f"{bigquery_datasets_str}\n"

    def run(self, config: dict) -> str:
        # Create datahub config
        datahub_config: dict = self._flatten_and_merge(
            base_dict=config,
            dict_list=[
                yaml.load(
                    open(
                        f"modules/datahub/main/service_configuration/{service_file}.yml"
                    ),
                    Loader=yaml.FullLoader,
                )
                for service_file in config["service_list"]
            ],
        )

        iam_role_dict: dict = self._create_bucket_iam_details_dict(datahub_config)
        bucket_list: list = list(
            itertools.chain(
                *[iam_role_dict[key]["bucket_list"] for key in iam_role_dict.keys()]
            )
        )
        datahub_terraform_str: str = ""
        # Add service accounts
        datahub_terraform_str += self.add_service_accounts(datahub_config)
        # Add buckets
        datahub_terraform_str += self.add_buckets(datahub_config, bucket_list)
        # Add IAM Roles
        datahub_terraform_str += self.add_iam_roles(datahub_config, iam_role_dict)

        # Add biq query
        datahub_terraform_str += (
            self.add_bigquery_datasets(datahub_config, bucket_list, iam_role_dict)
            if datahub_config.get("require_bigquery", True)
            else ""
        )

        return datahub_terraform_str
