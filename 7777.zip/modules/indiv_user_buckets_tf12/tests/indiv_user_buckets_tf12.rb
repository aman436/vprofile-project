# frozen_string_literal: true

def run_indiv_user_buckets_tf12(params)
  project_id = params['config']['project_id']
  control "#{project_id} : indiv_user_buckets : " do
    title 'Infrastructure for Spain individual nonlive buckets'
    impact 0.4
  end
end
