from templater.main.ModulePythonTemplater import ModulePythonTemplater
import logging


class IndivUserBuckets(ModulePythonTemplater):
    def _split_by_user(self, config: dict) -> dict:
        user_list: list = config.pop("user_list")
        logging.debug(f"IndivUserBuckets._split_by_user.user_list: {user_list}")
        config["config_user_list"] = [
            {"user_name": user, "bucket_name": user.replace(".", "-")}
            for user in user_list
        ]
        return config

    def run(self, config: dict) -> str:
        split_config = self._split_by_user(config)
        logging.debug(f"IndivUserBuckets.run.split_config: {split_config}")
        bucket_tf: str = self.Jinja.run_template(
            template_name="terraform_user_bucket_cmek_tf12", params=split_config
        )
        return bucket_tf
