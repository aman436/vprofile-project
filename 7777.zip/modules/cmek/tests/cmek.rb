# frozen_string_literal: true

['kms'].each do |lib|
  require_relative "#{Dir.pwd}/target/tests/libraries/#{lib}.rb"
end

# example key ring and key names
# keyring-vf-dev-dhk-6507-europe-west1
# cmek-HSM-vf-dev-gcs-europe-west1-agf

def run_cmek(params)
  project_id = params['config']['project_id']
  # FIXME: extract method body into smaller methods and remove disable
  # rubocop:disable Metrics/BlockLength
  control "#{project_id} : cmek : " do
    title 'CMEK configured correctly on storage'
    impact 0.6

    keyringname = "keyring-#{project_id}-#{params['variables']['region']}"
    keyname = "cmek-#{params['variables']['protection_level']}-vf-" \
      "#{params['variables']['tenant']}-#{params['variables']['service']}-" \
      "#{params['variables']['region']}"

    kms_key_ring_exists(
      project_id,
      params['variables']['region'],
      keyringname
    )

    # base key test cases
    kms_key_exists(
      project_id,
      params['variables']['region'],
      keyringname,
      keyname
    )

    kms_key_property(
      project_id,
      params['variables']['region'],
      keyringname,
      keyname,
      'purpose',
      params['variables']['key_purpose']
    )

    kms_key_property(
      project_id,
      params['variables']['region'],
      keyringname,
      keyname,
      'rotation_period',
      params['variables']['rotation_period']
    )

    # agf key test cases
    kms_key_exists(
      project_id,
      params['variables']['region'],
      keyringname,
      "#{keyname}-agf"
    )

    kms_key_property(
      project_id,
      params['variables']['region'],
      keyringname,
      "#{keyname}-agf",
      'purpose',
      params['variables']['key_purpose']
    )

    kms_key_property(
      project_id,
      params['variables']['region'],
      keyringname,
      "#{keyname}-agf",
      'rotation_period',
      params['variables']['rotation_period']
    )
  end
  # rubocop:enable Metrics/BlockLength
end
