# frozen_string_literal: true

def run_trusted_zone(params)
  project_id = params['config']['project_id']
  control "#{project_id} : trusted_zone : " do
    title 'trusted_zone setup correctly'
    impact 0.4
  end
end
