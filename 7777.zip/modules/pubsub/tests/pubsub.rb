# frozen_string_literal: true

%w[service_account iam].each do |lib|
  require_relative "#{Dir.pwd}/target/tests/libraries/#{lib}.rb"
end

# Tests if service account has role
def pubsub_sa_iam_role(sa_email, project, role)
  describe GcpState.google_project_iam_binding(self,
                                               project: project,
                                               role: "roles/#{role}") do
    its('members') { should include "serviceAccount:#{sa_email}" }
  end
end

def run_pubsub(params)
  project_id = params['config']['project_id']
  control "#{project_id} : #{params['module_name']} " do
    title 'pubsub setup correctly'
    impact 0.4

    # Check is Service Account email exist
    sa_email = "#{params['variables']['organisation']}-" \
      "#{params['variables']['tenant']}-ca-" \
      "#{params['variables']['stage']}-ps-" \
      "#{params['variables']['team']}-sa@#{project_id}" \
      ".iam.gserviceaccount.com"

      sa_exists(sa_email, project_id)

      # Check Service Account has specified roles
      iam_role_list = ["dataflow.developer", "dataflow.worker", "storage.admin", "pubsub.subscriber", "logging.admin"]
      iam_role_list.each do |role|
        sa_iam_role_exists(sa_email, project_id, role)
      end
  end
end
