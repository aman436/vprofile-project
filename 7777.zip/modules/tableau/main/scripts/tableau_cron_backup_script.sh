#!/bin/bash

backups_dir="/opt/tableau/tableau_server_data/data/tabsvc/files/backups"
timestamp=$(date +"%d-%m-%y_%H%M")

source /etc/profile.d/tableau_server.sh

tsm maintenance backup -f "ts_backup_$timestamp" >/tmp/backup.log
tsm settings export -f "$backups_dir/ts_settings_backup_${timestamp}.json" >/tmp/backup_settings.log
