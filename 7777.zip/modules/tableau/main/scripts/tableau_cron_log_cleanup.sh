#!/bin/bash

source /etc/profile.d/tableau_server.sh
tsm maintenance cleanup -a >/tmp/cleanup.log
