## Tableau Server on GCP for Neuron

Tableau Server is extremally unfit for Infrasturcture as a Code as it uses mainly imperative style of configuration and assumes manual procedures on every step. We managed to fit it to our standards by providing very advanced startup script that run on all nodes, transforming them into a fully functional tableau server cluster.

However this procedure is long (over 1h) and requires lots of prerequisites to be checked off before deployment.

Please read the [official documentation](https://confluence.sp.vodafone.com/display/BDPL/Tableau) for this setup before venturing forth.

Please see `resources/project_configuration/zeta/vf-de-tableau-live.yml` for a more detailed configuration for this module.