# frozen_string_literal: true

def run_secure_bucket_tf12(params)

  config     = params['config']
  variables  = params['variables']

  control "google_storage_bucket::#{config['project_id']}-secure" do
    title "correctly configured"
    impact 1.0
    describe google_storage_bucket({:name=>"#{config['project_id']}-secure"}) do
      it { should exist }
      its("name") { should cmp "#{config['project_id']}-secure" }
      its("location") { should cmp "#{variables['region']}" }
      its("logging.log_bucket") { should be_nil }
      its("storage_class") { should cmp "#{variables['storage_class']}" }
      its("versioning.enabled") { should be_nil }
      its("website.main_page_suffix") { should be_nil }
    end
  end
end
