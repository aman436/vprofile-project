# frozen_string_literal: true

def run_bastion_tf12(params)
  
  config     = params['config']
  variables  = params['variables']

  control "google_compute_firewall::projects/#{config['project_id']}/global/firewalls/iap-to-#{variables['bastion_sa']}" do
    title "correctly configured"
    impact 1.0
    describe google_compute_firewall({:project=>"#{config['project_id']}", :name=>"iap-to-#{variables['bastion_sa']}"}) do
      it { should exist }
      its("description") { should be_nil.or cmp "" }
      its("destination_ranges") { should be_nil }
      its("direction") { should cmp "INGRESS" }
      its('log_config.enable_logging') { should be true }
      its("name") { should cmp "iap-to-#{variables['bastion_sa']}" }
      its("priority") { should cmp 1000 }
      its("source_ranges") { should cmp ["35.235.240.0/20"] }
      its("target_service_accounts") { should cmp ["#{variables['bastion_sa']}@#{config['project_id']}.iam.gserviceaccount.com"] }
    end
  end

  control "google_compute_firewall::projects/#{config['project_id']}/global/firewalls/allow-ssh-from-management-zone" do
    title "correctly configured"
    impact 1.0
    only_if { variables['bastion_ssh_target_firewall_flag'] === 1 }
    describe google_compute_firewall({:project=>"#{config['project_id']}", :name=>"allow-ssh-from-management-zone"}) do
      it { should exist }
      its("description") { should be_nil.or cmp "" }
      its("destination_ranges") { should be_nil }
      its("direction") { should cmp "INGRESS" }
      its('log_config.enable_logging') { should be true }
      its("priority") { should cmp 1000 }
    end
  end 

  control "google_compute_instance::projects/#{config['project_id']}/zones/#{variables['zone']}/instances/#{variables['bastion_name']}" do
    title "correctly configured"
    impact 1.0
    describe google_compute_instance({:project=>"#{config['project_id']}", :zone=>"#{variables['zone']}", :name=>"#{variables['bastion_name']}"}) do
      it { should exist }
      its("name") { should cmp "#{variables['bastion_name']}" }
      its("hostname") { should be_nil.or cmp "" }
      its("status") { should cmp "RUNNING" }
      its('disk_count') {should eq 1 }
      its("cpu_platform") { should include "Intel" }
      its('machine_type') { should match "n1-standard-1" }
      its("scheduling.automatic_restart") { should cmp true }
      its("scheduling.on_host_maintenance") { should cmp "MIGRATE" }
      its("scheduling.preemptible") { should cmp false }
      its('network_interfaces_count') {should eq 1 }
      its('can_ip_forward') { should be false }
      its('service_account_scopes') { should cmp ["https://www.googleapis.com/auth/cloud-platform"] }
      its('zone') { should include "#{variables['zone']}" }      
    end
    describe google_compute_instance({:project=>"#{config['project_id']}", :zone=>"#{variables['zone']}", :name=>"#{variables['bastion_name']}"}).label_value_by_key('zone') do
      it { should cmp "management-zone" }
    end
    describe google_compute_instance({:project=>"#{config['project_id']}", :zone=>"#{variables['zone']}", :name=>"#{variables['bastion_name']}"}).metadata_value_by_key('enable-oslogin') do
      it { should cmp "TRUE" }
    end
    describe google_compute_disk({:project=>"#{config['project_id']}", :zone=>"#{variables['zone']}", :name=>"#{variables['bastion_name']}"}) do
      it { should exist }
      its('source_image') { should cmp "#{variables['bastion_image_id']}" }
    end
  end

  control "google_service_account::projects/#{config['project_id']}/serviceAccounts/#{variables['bastion_sa']}@#{config['project_id']}.iam.gserviceaccount.com" do
    title "correctly configured"
    impact 1.0
    describe google_service_account({:project=>"#{config['project_id']}", :name=>"#{variables['bastion_sa']}@#{config['project_id']}.iam.gserviceaccount.com"}) do
      it { should exist }
      its("name") { should cmp "projects/#{config['project_id']}/serviceAccounts/#{variables['bastion_sa']}@#{config['project_id']}.iam.gserviceaccount.com" }
      its("email") { should cmp "#{variables['bastion_sa']}@#{config['project_id']}.iam.gserviceaccount.com" }
    end
  end
end
