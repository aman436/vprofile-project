def get_latest_clamav_definitions(event, context):
    import os
    import requests
    import tempfile

    from google.cloud import storage

    CLAMAV_UPDATE_URL = "http://database.clamav.net"
    CLAMAV_CURRENT_VERSION_HOST = "current.cvd.clamav.net"
    CLAMAV_UPDATE_FILES = ["daily.cvd", "main.cvd", "bytecode.cvd"]
    DESTINATION_BUCKET = os.environ.get("DESTINATION_BUCKET")

    def download_file_to_temp(url):
        _, temp_file_name = tempfile.mkstemp()

        print(f"Downloading file: {url}")
        response = requests.get(url)
        response.raise_for_status()

        with open(temp_file_name, "wb") as file_to_save:
            file_to_save.write(response.content)

        file_size = os.path.getsize(temp_file_name)
        print(f"File downloaded to: {temp_file_name}, ({file_size} bytes)")

        return temp_file_name

    def upload_blob(source_file_name, destination_blob_name):
        storage_client = storage.Client()
        bucket = storage_client.bucket(DESTINATION_BUCKET)
        blob = bucket.blob(destination_blob_name)

        blob.upload_from_filename(source_file_name)

        print(f"File {source_file_name} uploaded to gs://{DESTINATION_BUCKET}/{destination_blob_name}.")

    # Main loop
    print("Starting ClamAV definitions update")
    for update_file in CLAMAV_UPDATE_FILES:
        url = f"{CLAMAV_UPDATE_URL}/{update_file}"

        downloaded_file = download_file_to_temp(url)
        upload_blob(downloaded_file, update_file)
        os.remove(downloaded_file)
    
    return "Done."
