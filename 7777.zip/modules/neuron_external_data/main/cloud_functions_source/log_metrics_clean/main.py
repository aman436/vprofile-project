#######################################################
# Cloud function to be triggered when a new file is   #
# in the inbound bucket. The subscription is push, so #
# so the Cloud Function will acknowledge the message  #


import base64
from google.cloud import bigquery
import json
import os

def vf_gned_eds_nonlive_subscription_log_clean(event, context):
    """Triggered from a message on a Cloud Pub/Sub topic.
    Args:
         event (dict): Event payload.
         context (google.cloud.functions.Context): Metadata for the event.
    """
    ignored_extensions = ["exe", "apk", "elf", "asp"]
    pubsub_message = base64.b64decode(event['data']).decode('utf-8')
    data = json.loads(pubsub_message)
    bucket_id = data["bucket"]
    object_id = data["name"]
    source_name = object_id.split("/")[0]
    size = data['size']
    updated = data['updated']
    status = bucket_id.split("-")[-1]

    row = {"SOURCE": source_name,"UPDATED": updated, "BUCKET":bucket_id, "OBJECT": object_id ,"SIZE": size,"STATUS": status}
    if object_id.split('.')[-1] not in ignored_extensions:
        # table_id = "vf-gned-eds-live.vfgned_eds_nwp_ops_processed_S.scanner_metrics"
        table_id = os.environ.get("table_id")
        bq_client = bigquery.Client()
        bq_client.insert_rows_json(table=table_id, json_rows=[row])
