// Requirements
const clamd = require('clamdjs');
const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const { Storage } = require('@google-cloud/storage');

// App config
const PORT = process.env.PORT || 8080;
const app = express();
let clamAvVersion = null;
clamd.version('127.0.0.1', 3310).then(version => {
  console.log(version)
  clamAvVersion = version;
}).catch(e => {
  console.error(e);
  process.exit(1);
});
const scanner = clamd.createScanner('127.0.0.1', 3310);
const storage = new Storage();

// Streaming config
const STREAM_TIMEOUT = 9999999;
const MAX_FILE_SIZE_BYTES = parseInt(process.env.MAX_FILE_SIZE_MB) * 1000000 || 3800 * 1000000;
const SCAN_OFFSET_BYTES = 50 * 1000000;

// Bucket config
const CLOUD_STORAGE_BUCKET = process.env.UNSCANNED_BUCKET;
const CLEAN_BUCKET = process.env.CLEAN_BUCKET;
const QUARANTINED_BUCKET = process.env.QUARANTINED_BUCKET;
let srcbucket = storage.bucket(CLOUD_STORAGE_BUCKET);

// Functions
function generateChunkList(fileSizeBytes) {
  let chunkList = [];

  if (fileSizeBytes > MAX_FILE_SIZE_BYTES) {
    // Needs splitting
    let chunkCount = Math.trunc(fileSizeBytes / MAX_FILE_SIZE_BYTES);
    console.log(`File will be split into ${chunkCount} chunks.`);

    chunkList.push({
      "start": 0,
      "end": MAX_FILE_SIZE_BYTES
    });

    for (i = 0; i < chunkCount; i++) {
      let chunk = {
        "start": chunkList[i].end - SCAN_OFFSET_BYTES,
        "end": null
      };

      if (chunkList[i].end + MAX_FILE_SIZE_BYTES >= fileSizeBytes) {
        chunk.end = fileSizeBytes
      } else {
        chunk.end = chunkList[i].end + MAX_FILE_SIZE_BYTES;
      };

      chunkList.push(chunk);
    }
  } else {
    // Does not need to be split
    console.log(`File does not need to be chunked.`);
    chunkList.push({
      "start": 0,
      "end": fileSizeBytes
    });
  }

  return chunkList;
}

// Start app
app.use(bodyParser.json());
const run = () => app.listen(PORT, () => {
  console.log(`Maximum scan chunk size: ${MAX_FILE_SIZE_BYTES / 1000000} MB`);
  console.log(`Scan offset size: ${SCAN_OFFSET_BYTES / 1000000} MB`);
  console.log(`Inbound bucket: ${CLOUD_STORAGE_BUCKET}`)
  console.log(`Clean bucket: ${CLEAN_BUCKET}`)
  console.log(`Quarantine bucket: ${QUARANTINED_BUCKET}`)
  console.log(`Server started on port ${PORT}.`);
});

/**
 * Route that is invoked by a Cloud Function when a malware scan is requested
 * for a document uploaded to GCS.
 *
 * @param {object} req The request payload
 * @param {object} res The HTTP response object
 */
app.post('/scan', async (req, res) => {
  console.log('Request body', req.body);
  let filename = req.body.filename;

  try {
    // Create file blob
    const fileBlob = storage
      .bucket(CLOUD_STORAGE_BUCKET)
      .file(filename);

    // Get file size
    let fileSizeBytes = null;
    const getFileSize = await fileBlob
      .getMetadata()
      .then(metadata_results => {
        const metadata = metadata_results[0];
        console.log(`${filename} is: ${metadata.size} bytes.`)
        fileSizeBytes = metadata.size;
      }).catch(metadata_err => {
        console.error(`Looking up size of ${filename} failed with error: ${metadata_err}.`);
      });

    // Create a list of chunks
    const chunkList = generateChunkList(fileSizeBytes);
    console.log(chunkList);

    // Respond to API client
    console.log("Returning response to client")
    res.json({
      "filename": filename,
      "fileSize": fileSizeBytes,
      "chunkSize": MAX_FILE_SIZE_BYTES,
      "chunkCount": chunkList.length,
      "clamAvVersion": clamAvVersion
    });

    // Loop through chunk list, stream file and scan with ClamAV
    let scanResult = null;
    let scanStatus = {};
    let chunkIndex = 1;

    // Keep a count of the total execution time
    let startExecTime = new Date();

    for (const chunk of chunkList) {
      // Catch the 0 byte file case
      if (fileSizeBytes == 0) {
        console.log("File is 0 bytes, so it will not be scanned and/or moved.");
        scanStatus = {
          "status": "EmptyFile",
          "message": "File is 0 bytes long, so it is not being scanned or moved.",
          "clamAvVersion": clamAvVersion
        };
        break;
      };

      console.log(`Downloading ${filename} chunk ${chunkIndex} of ${chunkList.length}...`);
      let startReadStreamTime = new Date();
      let readStream = await fileBlob
        .createReadStream(chunk)
        .on('error', function (err) {
          console.error(`Downloading file failed with error ${err}.`);
        })
        .on('response', function (response) {
          console.log("...stream opened...");
        })
        .on('end', function () {
          console.log("...stream complete.");
        });
      let stopReadStreamTime = (new Date() - startReadStreamTime) / 1000;
      console.log(`Stream download took ${stopReadStreamTime} seconds.`);

      console.log(`Scanning chunk ${chunkIndex}...`)
      let startScanTime = new Date();
      scanResult = await scanner.scanStream(readStream, STREAM_TIMEOUT);
      let stopScanTime = (new Date() - startScanTime) / 1000;
      console.log(`...scanner result for chunk ${chunkIndex}: ${scanResult}.`);
      console.log(`Scan took ${stopScanTime} seconds.`);

      if (scanResult.indexOf('OK') > -1) {
        // File is clean
        if (chunkIndex == chunkList.length) {
          // Is this the last chunk
          console.log(`Scan status for ${filename}: CLEAN.`);

          // Set response body
          scanStatus = {
            "status": "clean",
            "clamAvVersion": clamAvVersion
          };

          // Move document to the clean bucket
          await moveProcessedFile(filename, true, scanStatus);
        }
      } else {
        // Log scan outcome for document
        console.log(`Scan status for ${filename}: INFECTED.`);

        // Set response body
        scanStatus = {
          "status": "infected",
          "message": scanResult,
          "clamAvVersion": clamAvVersion
        };

        // Move document to the bucket that holds infected documents
        await moveProcessedFile(filename, false, scanStatus);

        // Quit the loop now we have a dodgy file
        break;
      }
      chunkIndex++;
    }

    let stopExecTime = (new Date() - startExecTime) / 1000;
    console.log(`Summary: scanned ${filename} in ${stopExecTime} seconds, (${fileSizeBytes} bytes).`);

  } catch (e) {
    console.error(`Error processing the file ${filename}`, e)
    res.status(500).json({
      message: e.toString(),
      status: 'error'
    });
  };
});

const moveProcessedFile = async (filename, isClean, fileMetadata) => {
  const srcfile = srcbucket.file(filename);
  const destinationBucketName = isClean ? `gs://${CLEAN_BUCKET}` : `gs://${QUARANTINED_BUCKET}`;
  const destinationBucket = storage.bucket(destinationBucketName);

  if (fileMetadata) {
    console.log('Adding metadata to tag:', fileMetadata);
    await srcfile.setMetadata({
      metadata: fileMetadata
    });
  };

  console.log(`Moving file to bucket ${destinationBucketName}/${filename}`);
  await srcfile.move(destinationBucket);
};

run();
