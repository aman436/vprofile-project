#!/bin/bash
sudo service clamav-freshclam stop && \
sudo freshclam && \
sudo service clamav-freshclam start && \
sudo service clamav-daemon force-reload && \
npm start