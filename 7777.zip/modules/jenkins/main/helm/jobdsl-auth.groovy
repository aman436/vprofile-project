// def jsonSlurper = new groovy.json.JsonSlurper()
// def config = jsonSlurper.parseText('''$CONFIGYAML''')

def auth(authRow, permissionName) {
    '''
    Credentials
        Create, Delete, ManageDomains, Update, View
    Job
        Build, Cancel, Configure, ConfigureVersions, Create, Delete, Discover, Move, Read, Workspace
    Run
        Delete, Replay, Update
    View
        Configure, Create, Delete, Read
    SCM
        Tag
    '''
    def namespaces = [credentials:'com.cloudbees.plugins.credentials.CredentialsProvider',
        job:'hudson.model.Item',
        run:'hudson.model.Run',
        view:'hudson.model.View',
        scm:'hudson.scm.SCM',]

    def (credentials, job, run, view, scm)=authRow.split(' ')*.trim()*.split('')
    def perm = [
        credentials:[['Create', 'Delete', 'ManageDomains', 'Update', 'View'], credentials].transpose(),
        job:[['Build', 'Cancel', 'Configure', 'ConfigureVersions', 'Create', 'Delete', 'Discover', 'Move', 'Read', 'Workspace'], job].transpose(),
        run:[['Delete', 'Replay', 'Update'], run].transpose(),
        view:[['Configure', 'Create', 'Delete', 'Read'], view].transpose(),
        scm:[['Tag'], scm].transpose()]

    return [ permissionName, perm.collect { key, permissions->
        permissions.findAll { it[1] == '✅' }.collect { namespaces[key] + '.' + it[0] }
    }.flatten(), ]
}

def build_cancel_read_job(identities) {
    identities.collect {
        // Credentials Job                    Run    View     Scm
        // C D M U V   B C C CV C D D M R W,  D R U  C C D R   T
        auth('❌❌❌❌❌ ✅✅❌❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', it )
    }
}
def read_job(identities) {
    identities.collect {
        // Credentials Job                    Run    View     Scm
        // C D M U V   B C C CV C D D M R W,  D R U  C C D R   T
        auth('❌❌❌❌❌ ❌❌❌❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', it )
    }
}

def build_read_job__read_view(identities) {
    identities.collect {
        // Credentials Job                    Run    View     Scm
        // C D M U V   B C C CV C D D M R W,  D R U  C C D R   T
        auth('❌❌❌❌❌ ✅❌❌❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌✅ ❌', it)
    }
}

def standard_tenant_auth(tenant) {
    [
       // Credentials Job                    Run    View     Scm
       // C D M U V   B C C CV C D D M R W,  D R U  C C D R   T
       auth('❌❌❌❌❌ ✅✅❌❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-' + tenant + '-jenkins-admin'),
       auth('❌❌❌❌❌ ✅❌❌❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-' + tenant + '-jenkins-user'),
       auth('❌❌❌❌❌ ❌❌❌❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-' + tenant + '-jenkins-viewer'),
    ]
}
def standard_org_folder_auth(market) {
    [
       // Credentials Job                    Run    View     Scm
       // C D M U V   B C C CV C D D M R W,  D R U  C C D R   T
       auth('❌❌❌❌❌ ✅✅✅❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-grp-jenkins-admin'),
       auth('❌❌❌❌❌ ✅✅✅❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-grp-jenkins-user'),
    ] + standard_tenant_auth(market)
}

def no_viewer_tenant_auth(tenant) {
    [
       // Credentials Job                    Run    View     Scm
       // C D M U V   B C C CV C D D M R W,  D R U  C C D R   T
       auth('❌❌❌❌❌ ✅✅❌❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-' + tenant + '-jenkins-admin'),
       auth('❌❌❌❌❌ ✅❌❌❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-' + tenant + '-jenkins-user'),
    ]
}

def dag_deploy_auth(market) {
    standard_tenant_auth(market) +
    build_cancel_read_job(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
}

def tenant_pipeline_auth(market) {
    build_cancel_read_job([
        'gcp-vf-' + market + '-jenkins-admin',
        'gcp-vf-' + market + '-jenkins-user',
    ]) +
    read_job([
        'gcp-vf-' + market + '-jenkins-viewer'
    ])
}

def img_promote_auth(market) {
    tenant_pipeline_auth(market) +
    build_cancel_read_job(['gcp-vf-grp-jenkins-user'])
}

def img_promote_short_auth(market) {
    build_cancel_read_job(['gcp-vf-' + market + '-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
}

def cmrbdai_auth() {
    build_cancel_read_job([
        'gcp-vf-grp-cmrbdai-de-user',
        'gcp-vf-grp-cmrbdai-ds-user',
        'gcp-vf-grp-cmrbdai-ops',
        'gcp-vf-grp-cmrbdai-platformengineers',
        'gcp-vf-grp-jenkins-user',
    ])
}

def tenant_read_job_auth(market) {
    read_job([
        'gcp-vf-' + market + '-jenkins-admin',
        'gcp-vf-' + market + '-jenkins-user',
        'gcp-vf-' + market + '-jenkins-viewer',
    ])
}
