mkdir -p /usr/share/jenkins/ref/secrets/;
# Prevent Setup Wizard when JCasC is enabled
echo $JENKINS_VERSION > /var/jenkins_home/jenkins.install.UpgradeWizard.state
echo $JENKINS_VERSION > /var/jenkins_home/jenkins.install.InstallUtil.lastExecVersion
# Install missing plugins
cp /var/jenkins_config/plugins.txt /var/jenkins_home;
rm -rf /usr/share/jenkins/ref/plugins/*.lock
# prepare jenkins plugin cache:
mkdir -p /usr/share/jenkins/ref/plugins
cp /var/jenkins_plugins/*jpi /usr/share/jenkins/ref/plugins
# dont use default jenkins script. Use our patched one that respects versions.
/bin/bash -f /var/jenkins_config/install-plugins.sh `echo $(cat /var/jenkins_home/plugins.txt)`;
# Copy plugins to shared volume
yes n | cp -i /usr/share/jenkins/ref/plugins/* /var/jenkins_plugins/;
