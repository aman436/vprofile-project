#!/bin/sh

CRON_JOB_NAME="${0}"
LOG=""
errcho(){ >&2 echo $@; }
log() {
  LOG="${LOG}\n$1"
}
try_catch() {
  exit_code=$?
  if [ "$exit_code" -ne "0" ]; then
    errcho "[${CRON_JOB_NAME}] Failed. Trace: $LOG"
  fi
  exit $exit_code
}
trap try_catch EXIT

get_bearer_token(){
  log "Getting google bearer token."
  curl -s --connect-timeout 5 --max-time 10 --retry 10 --retry-delay 0 --retry-max-time 60 \
    --header "Metadata-Flavor: Google" \
    "http://metadata/computeMetadata/v1/instance/service-accounts/default/token"| jq -r '.access_token' 
}
get_jwt_token(){
  log "Getting JWT token."
  JWT_CLAIM="{\\\"aud\\\":\\\"vault/${ROLE}\\\", \\\"sub\\\": \\\"${SERVICE_ACCOUNT}\\\", \\\"exp\\\": $(expr $(date +'%s') + 900)}"
  bearer_token="$(get_bearer_token)"
  curl -s \
    --connect-timeout 5 --max-time 10 --retry 10 --retry-delay 0 --retry-max-time 60 \
    --header "Authorization: Bearer  ${bearer_token}" \
    --header "Content-Type: application/json" \
    --request POST \
    --data "{\"payload\": \"${JWT_CLAIM}\"}" \
    "https://iam.googleapis.com/v1/projects/${PROJECT}/serviceAccounts/${SERVICE_ACCOUNT}:signJwt"| jq -r '.signedJwt'
}
handle_errors(){
  result=$1 
  message=$2
  errors="$(echo $result| jq -r '.errors|select(. != null)|.[]')"
  if [[ ! -z "$errors" ]]; then 
    errcho "[${CRON_JOB_NAME}] $message: $(echo $errors| tr '\n' ',')"
    return 1
  fi
}
vault_token() {
  log "Getting Vault access token."
  jwt_token="$(get_jwt_token)"
  result="$(curl -s \
        --connect-timeout 5 --max-time 10 --retry 10 --retry-delay 0 --retry-max-time 60 \
        --request POST --data "{\"role\":\"${ROLE}\", \"jwt\":\"${jwt_token}\"}"  ${VAULT_ADDR}/v1/auth/gcp/login )"
  handle_errors "$result" "Error while generating vault access token"
  echo "$result" | jq -r '.auth.client_token'
}


update_jenkins() {
  folder_name="$1"
  jenkins_secret_id="$2"
  jenkins_secret_name="$3"
  jenkins_secret_value="$4"
  jenkins_description="${5}. Last updated $(date)."
  jenkins_secret_type="${6}"
  optionalTypeParam=""
  if [ -n "$jenkins_secret_type" ]; then 
    optionalTypeParam="&type=${jenkins_secret_type}";
  fi
  log "Updating Jenkins folder $folder with secret id $jenkins_secret_id"
  export crumb="$(curl -s --cookie-jar ./cookies \
    -H "X-Forwarded-Groups: gcp-vf-grp-jenkins-admin" \
    -H "X-Forwarded-User: credential-reloader" \
    'http://localhost:8080/jenkins-v2/crumbIssuer/api/json'|jq -r '.crumb' 2>/dev/null)"
  if [ -z "$crumb" ]; then 
    errcho "[${CRON_JOB_NAME}] Couldn't get crumb. Is jenkins up and ready ?"
    return 1
  else 
    curl  --silent --output /dev/null --cookie ./cookies \
      -H "Jenkins-Crumb: $crumb" \
      -H "X-Forwarded-Groups: gcp-vf-grp-jenkins-admin" \
      -H "X-Forwarded-User: credential-reloader"   \
      http://localhost:8080/jenkins-v2/job/folder-credentials-config/buildWithParameters \
      --data "folderName=${folder_name}&secretId=${jenkins_secret_id}&secretName=${jenkins_secret_name}&secretValue=${jenkins_secret_value}&description=${jenkins_description}${optionalTypeParam}"
    return 0
  fi;
}
handle_approle_id() {
  folder="$1"
  secret_value="$2"
  log "Updating approle_id for $folder"
  role_id="$(echo "$secret_value"|jq -r ".role_id")"
  secret_id="$(echo "$secret_value"|jq -r ".secret_id")"
  data="{  \"role_id\": \"${role_id}\", \"secret_id\": \"${secret_id}\" }"
  result="$(curl -s \
    --connect-timeout 5 --max-time 10 --retry 10 --retry-delay 0 --retry-max-time 60 \
    --request POST --data "$data" "${VAULT_ADDR}/v1/auth/approle/login")"
  handle_errors "$result" "Error while extracting vault token from approle"
  token="$(echo "$result"|jq -r ".auth.client_token")"
  vault_token_secret_id="jenkins-vault-token"
  vault_token_secret_name="VAULT_TOKEN"
  type="string"
  update_jenkins "$folder" "$vault_token_secret_id" "$vault_token_secret_name" "$token" "Generated vault token" "$type"
}
extract_approle_only(){
  folder="$1"
  config="$2"
  log "Extracting only approle_id for $folder"
  for secret_id in $(echo "$config" | jq -r '.|keys|.[]' ); do 
    secret_value="$(echo "$config"|jq -r '."'"$secret_id"'"')"
    if echo "$secret_id"| grep -Eqi  "^.*approle.*$" ;then 
      errcho "[${CRON_JOB_NAME}] Updating jenkins $folder vault token."
      handle_approle_id "$folder" "$secret_value"
    fi
  done;
}

update_folder_approle_only() {
  folder="$1"
  log "Processing only approle_id for $folder"
  result="$(curl -s \
      --connect-timeout 5 --max-time 10 --retry 10 --retry-delay 0 --retry-max-time 60 \
      --header "X-Vault-Token: ${VAULT_TOKEN}" \
      "${VAULT_ADDR}/v1/${CONFIG_BUCKET}/$folder" )"
  handle_errors "$result" "Error while listing folder config"
  config="$(echo $result|jq  -r '.data')"
  if [ -n "$config" ]; then
      extract_approle_only "$folder" "$config"
  fi
}

handle_jenkins_secrets(){
  folder="$1"
  config="$2"
  log "Processing jenkins secrets for $folder"
  handler_result=0
  if [ "$config" = "null" ]; then 
    #  $conifg is empty.
    return $handler_result;
  fi
  for vault_secret_id in $(echo "$config" | jq -r '.|keys|.[]' ); do 
    secret_value="$(echo "$config"|jq -r '."'"$vault_secret_id"'"')"
    if echo "$vault_secret_id"| grep -Eqi  "^.*approle.*$" ;then 
      handle_approle_id "$folder" "$secret_value"
      if test $? -gt 0 ; then 
        handler_result=1
      fi
    else
      username="$(echo "$secret_value"|jq -r ".username")"
      password="$(echo "$secret_value"|jq -r ".password")"
      type="$(echo "$secret_value"|jq -r ".type")"
      optionalType=""
      if [ "$type" != "null" ]; then optionalType="${type}"; fi
      description="$(echo "$secret_value"|jq -r ".description")"
      update_jenkins "$folder" "$vault_secret_id" "$username" "$password" "$description" "$optionalType"
      if test $? -gt 0 ; then 
        handler_result=1
      fi
    fi
  done;
  return $handler_result
}

list_config_folders() {
  log "listing folders configured in vault"
  result="$(curl -s \
      --connect-timeout 5 --max-time 10 --retry 10 --retry-delay 0 --retry-max-time 60 \
      --request LIST \
      --header "X-Vault-Token: ${VAULT_TOKEN}" \
      "${VAULT_ADDR}/v1/${CONFIG_BUCKET}/" )"
    handle_errors "$result" "Error while listing folders"
    echo "$result"| jq  -r '.data.keys|.[]'
}
get_folder_secrets() {
  folder="$1"
  log "Extracting $folder secrets."
  folder_sha_file_name="${1}.sha256sum"
  result="$(curl -s \
      --connect-timeout 5 --max-time 10 --retry 10 --retry-delay 0 --retry-max-time 60 \
      --header "X-Vault-Token: ${VAULT_TOKEN}" \
      "${VAULT_ADDR}/v1/${CONFIG_BUCKET}/$folder" )"
  handle_errors "$result" "Error while listing folder config"
  config="$(echo $result|jq  -r '.data')"
  echo "$config"
}
update_folder_config() {
  folder="$1"
  log "Processing all $folder secrets."
  common_config="$2"
  if [ "$folder" = "$COMMON_FOLDER" ]; then 
    exit 0;
  fi
  folder_sha_file_name="${1}.sha256sum"
  folder_config="$(get_folder_secrets "$folder")"
  config_sha="$(echo "${folder_config}${common_config}"| sha256sum)"
  [ -n "${folder_config}${common_config}" ]; config_is_not_empty=$?
  if [ $config_is_not_empty = 0 ]; then
    [ "$config_sha" != "$(cat $folder_sha_file_name 2>/dev/null)" ]; config_sha_has_changed=$?
    if [ $config_sha_has_changed = 0 ]; then 
      echo "[${CRON_JOB_NAME}] Updating jenkins folder: $folder"
      if handle_jenkins_secrets "$folder" "$common_config" && handle_jenkins_secrets "$folder" "$folder_config"; then
        echo "$config_sha" > "$folder_sha_file_name" ; 
      else
        echo "[${CRON_JOB_NAME}] Failed processing some secrets for: $folder"
      fi
    fi
  fi
}
update_folder() {
    folder="$1"
    common_config="$2"
    if echo "${CRON_JOB_NAME}" | grep -Eqi  "^.*config-reloader.*$" ; then
      log "Updating all secrets for $folder"
      update_folder_config "$folder" "${common_config}"
    elif echo "${CRON_JOB_NAME}" | grep -Eqi  "^.*vault-token-reloader.*$" ; then
      log "Updating approle only for $folder"
      update_folder_approle_only "$folder"
    else echo "[${CRON_JOB_NAME}] no action specified."; 
    fi
}
update_folders_including_common_config() {
  config_folders="$1"
  common_config="$(get_folder_secrets "${COMMON_FOLDER}")"
  for folder in ${config_folders}; do 
    update_folder "$folder" "${common_config}"
  done;
}
main() {
  VAULT_TOKEN="$(vault_token)"
  export VAULT_TOKEN
  config_folders="$(list_config_folders | grep -v "${COMMON_FOLDER}")"
  update_folders_including_common_config "${config_folders}"
  echo "[${CRON_JOB_NAME}] Credentails processed for folders: $( echo "$config_folders" | tr '\n' ',')"
}

main
