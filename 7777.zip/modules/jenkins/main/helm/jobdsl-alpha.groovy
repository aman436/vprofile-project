def auth(authRow){
    '''
    Credentials 
        Create, Delete, ManageDomains, Update, View 
    Job  
        Build, Cancel, Configure, ConfigureVersions, Create, Delete, Discover, Move, Read, Workspace 
    Run  
        Delete, Replay, Update 
    View    
        Configure, Create, Delete, Read 
    SCM	
        Tag
    '''
    def namespaces = [credentials:'com.cloudbees.plugins.credentials.CredentialsProvider',
        job:'hudson.model.Item',
        run:'hudson.model.Run',
        view:'hudson.model.View',
        scm:'hudson.scm.SCM']

    def (credentials, job, run, view, scm)=authRow.split(' ')*.trim()*.split('')
    def perm = [
        credentials:[['Create','Delete','ManageDomains','Update','View'],credentials].transpose(),
        job:[['Build','Cancel','Configure','ConfigureVersions','Create','Delete','Discover','Move','Read','Workspace'],job].transpose(),
        run:[['Delete','Replay','Update'],run].transpose(),
        view:[['Configure','Create','Delete','Read'],view].transpose(),
        scm:[['Tag'],scm].transpose()]

    perm.collect{key,permissions-> 
        permissions.findAll {it[1] == '✅'}.collect{ namespaces[key]+"."+it[0] }
    }.flatten() 
}

organizationFolder('VFGroup-CloudAnalytics'){
    description('This contains branch source jobs for GitHub')
    authorization {
                                                    //Credentials Job                     Run    View     Scm
                                                    // C D M U V  B C C CV C D D M R W,   D R U  C C D R   T 
        permissions('gcp-vf-grp-jenkins-admin', auth('✅❌❌❌❌ ❌❌❌❌❌❌❌❌❌❌ ❌✅❌ ❌❌❌❌ ❌'))
    }
    organizations {
        github {
            apiUri('https://github.vodafone.com/api/v3')
            credentialsId('jenkins-github-password') // id of secret in configs release
            repoOwner('VFGroup-CloudAnalytics') 
        }
    }
    triggers {
        cron('H H/4 * * *')
    }
    // See https://issues.jenkins-ci.org/browse/JENKINS-46202
    configure {
        def traits = it / 'navigators' / 'org.jenkinsci.plugins.github__branch__source.GitHubSCMNavigator' / 'traits'
        traits << 'jenkins.scm.impl.trait.WildcardSCMSourceFilterTrait' {
            includes()
        }
        traits << 'org.jenkinsci.plugins.github__branch__source.BranchDiscoveryTrait' {
            strategyId(1) // exclude branches that are also filed as PR
        }
        traits << 'org.jenkinsci.plugins.github__branch__source.OriginPullRequestDiscoveryTrait' {
            strategyId(1)
        }
        traits << 'org.jenkinsci.plugins.github__branch__source.ForkPullRequestDiscoveryTrait' {
            strategyId(1)
            trust(class:'org.jenkinsci.plugins.github_branch_source.ForkPullRequestDiscoveryTrait$TrustPermission')
        }
        it / 'projectFactories' / 'org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProjectFactory' {
            scriptPath('JenkinsfileV2')
        }
    }
}
