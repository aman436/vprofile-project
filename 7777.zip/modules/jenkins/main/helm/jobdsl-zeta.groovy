tenant('vf-cip-eds-live', 'cip') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-cip-eds-live',  dag_deploy_auth('cip'))
    neds_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-cip-eds-live', dag_deploy_auth('cip'))
}

tenant('vf-cip-eds-nonlive', 'cip') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-cip-eds-nonlive',  dag_deploy_auth('cip'))
    neds_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-cip-eds-nonlive', dag_deploy_auth('cip'))
}

tenant('vf-cip-ca-live', 'cip') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-cip-ca-live',  dag_deploy_auth('cip'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-cip-ca-live', dag_deploy_auth('cip'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('cip'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('cip'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', dag_deploy_auth('cip'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-cip-ca-live', img_promote_auth('cip'))
}
tenant('vf-cip-ca-nonlive', 'cip') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-cip-ca-nonlive', dag_deploy_auth('cip'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-cip-ca-nonlive', dag_deploy_auth('cip'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('cip'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('cip'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', dag_deploy_auth('cip'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-cip-ca',    img_promote_auth('cip'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-cip-ca-nonlive',    img_promote_auth('cip'))
    dp_composer_deployer_pipeline(FOLDER + '/neuron-dp-composer-deployer-cip',  img_promote_auth('cip'))
    run_org_folder(FOLDER + '/VFGroup-Analytics-CIP', standard_org_folder_auth('cip'))
}
tenant('vf-gned-cias-dev', 'grp-cias-cf') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('grp-cias')
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-gned-cias-dev', dag_auth)
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-gned-cias-dev', dag_auth)
    //Bif deply pipelines for CIAS dev
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-gned-cias-dev', dag_auth)
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-gned-cias-dev', dag_auth)
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-gned-cias-dev', standard_tenant_auth('grp-cias'))
    run_org_folder(FOLDER + '/VFGroup-Engineering-CIAS', standard_org_folder_auth('grp-cias-cf'))
    def repo_specifier_regex = '.*(neuron-bif-cfg-cias).*'
    run_org_folder(FOLDER + '/VFGroup-CloudAnalytics', standard_org_folder_auth('grp-cias-cf') , repo_specifier_regex)
}
tenant('vf-gned-cias-tst', 'grp-cias-cf') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('grp-cias')
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-gned-cias-tst', dag_auth)
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-gned-cias-tst', dag_auth)
    run_org_folder(FOLDER + '/VFGroup-Engineering-CIAS', standard_org_folder_auth('grp-cias-cf'))
}
tenant('vf-gned-cias-nonlive', 'grp-cias-cf') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('grp-cias')
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-gned-cias-nonlive', dag_auth)
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-gned-cias-nonlive', dag_auth)
    //Bif deply pipelines for CIAS Nonlive
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-gned-cias-nonlive', dag_auth)
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-gned-cias-nonlive', dag_auth)
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-gned-cias-nonlive', standard_tenant_auth('grp-cias'))
    run_org_folder(FOLDER + '/VFGroup-Engineering-CIAS', standard_org_folder_auth('grp-cias-cf'))
}
tenant('vf-gned-cias-live', 'grp-cias-cf') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('grp-cias')
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-gned-cias-live', dag_auth)
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-gned-cias-live', dag_auth)
    //Bif deply pipelines for CIAS Live
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-gned-cias-live', dag_auth)
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-gned-cias-live', dag_auth)
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-gned-cias-live', standard_tenant_auth('grp-cias'))
    run_org_folder(FOLDER + '/VFGroup-Engineering-CIAS', standard_org_folder_auth('grp-cias-cf'))
    def repo_specifier_regex = '.*(neuron-bif-cfg-cias).*'
    run_org_folder(FOLDER + '/VFGroup-CloudAnalytics', standard_org_folder_auth('grp-cias-cf') , repo_specifier_regex)
}
tenant('vf-pt-nwp-live', 'pt-nwp') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-pt-nwp-live',       img_promote_auth('pt-nwp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-pt-nwp-live' , standard_tenant_auth('pt-nwp') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-pt-nwp-live' , standard_tenant_auth('pt-nwp') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-pt-nwp-live' , standard_tenant_auth('pt-nwp') , 'tags/v2.0.0')
}
tenant('vf-d2-ca-live', 'd2') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-d2-ca-live',  dag_deploy_auth('d2'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2-ca-live', dag_deploy_auth('d2'))
    run_org_folder(FOLDER + '/VFGroup-DigitalTwin', standard_org_folder_auth('d2'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-d2-ca-live',  img_promote_auth('d2'))
}
tenant('vf-d2-ca-nonlive', 'd2') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-d2-ca-lab', dag_deploy_auth('d2'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2-ca-lab', dag_deploy_auth('d2'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-d2-ca-lab',  img_promote_auth('d2'))

    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-d2-ca-nonlive', dag_deploy_auth('d2'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2-ca-nonlive', dag_deploy_auth('d2'))
    run_org_folder(FOLDER + '/VFGroup-DigitalTwin', standard_org_folder_auth('d2'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-d2-ca', img_promote_auth('d2'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-d2-ca-nonlive',  img_promote_auth('d2'))
}
tenant('vf-d2dev-ca-live', 'd2dev') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-d2dev-ca-live',  dag_deploy_auth('d2dev'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2dev-ca-live', dag_deploy_auth('d2dev'))
}
tenant('vf-d2dev-ca-nonlive', 'd2dev') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-d2dev-ca-nonlive', dag_deploy_auth('d2dev'))
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-d2dev-ca-openlab', dag_deploy_auth('d2dev'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2dev-ca-nonlive', dag_deploy_auth('d2dev'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2dev-ca-openlab', dag_deploy_auth('d2dev'))
    run_org_folder(FOLDER + '/VFGroup-DigitalTwin', standard_org_folder_auth('d2dev'))
}
tenant('vf-wfm-ca-live', 'wfmuk-ca') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-wfm-ca-live',  dag_deploy_auth('wfmuk-ca'))
    run_org_folder(FOLDER + '/VFGroup-DigitalTwin', standard_org_folder_auth('wfmuk-ca'))
}
tenant('vf-d2-etl-live', 'd2') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-d2-etl-live', dag_deploy_auth('d2'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2-etl-live', dag_deploy_auth('d2'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-d2-etl-live',       img_promote_auth('d2'))
    live_ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-d2-etl-live', img_promote_auth('d2'), [market_name:'ie-d2'])
    //Bif deply pipelines for D2
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-d2-etl-live', dag_deploy_auth('d2'), 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-d2-etl-live', dag_deploy_auth('d2'), 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-d2-etl-live', standard_tenant_auth('d2'), 'tags/v2.0.0')
}
tenant('vf-d2-etl-nonlive', 'd2') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-d2-etl-nonlive', dag_deploy_auth('d2'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2-etl-nonlive', dag_deploy_auth('d2'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-d2-etl-nonlive',    img_promote_auth('d2'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-d2-etl',    img_promote_auth('d2'))
    run_org_folder(FOLDER + '/VFGroup-DigitalTwin', standard_org_folder_auth('d2'))
    ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-d2-etl-nonlive', img_promote_auth('d2'), [market_name:'ie-d2'])
    //Bif deply pipelines for D2
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-d2-etl-nonlive', dag_deploy_auth('d2'), 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-d2-etl-nonlive', dag_deploy_auth('d2'), 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-d2-etl-nonlive', standard_tenant_auth('d2'), 'tags/v2.0.0')
}

tenant('vf-de-ca-live', 'de') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-de-ca-live',  dag_deploy_auth('de'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-de-ca-live', dag_deploy_auth('de'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-ca-live',     img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('ops'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('ops'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', dag_deploy_auth('ops'))
    live_ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-de-ca-live', img_promote_auth('de'), [market_name:'de-ca'])
    // allow master branches of some repositories only
    def repo_specifier_regex = '.*(neuron-bif-de-cfg|helios|composer|hades|de-flows-sql|utilities|images|TN).*'
    def branch_specifier_regex = '.*(master|image-).*'
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics',
                                             standard_org_folder_auth('de'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}
tenant('vf-de-ca-nonlive', 'de') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-de-ca-nonlive', dag_deploy_auth('de'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-de-ca-nonlive',  dag_deploy_auth('de'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-de-ca',     img_promote_auth('de'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-ca-nonlive',  img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-de-ca-nonlive', img_promote_auth('de'), [market_name:'de-ca'])
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics', standard_org_folder_auth('de'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('de'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('de'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp'))
}
tenant('vf-de-ca-lab', 'de') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-ca-lab',      img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    def repo_specifier_regex = '.*images.*'
    def branch_specifier_regex = '.*'
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics',
                                             standard_org_folder_auth('de'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}

tenant('vf-de-fba-lab', 'de') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-fba-lab',      img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    def repo_specifier_regex = '.*images.*'
    def branch_specifier_regex = '.*'
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics',
                                             standard_org_folder_auth('de'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}

tenant('vf-de-tnw-lab', 'de') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-tnw-lab',      img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    def repo_specifier_regex = '.*(images|TN).*'
    def branch_specifier_regex = '.*'
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics',
                                             standard_org_folder_auth('de'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}

tenant('vf-de-hra-lab', 'de') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-hra-lab',      img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    def repo_specifier_regex = '.*images.*'
    def branch_specifier_regex = '.*'
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics',
                                             standard_org_folder_auth('de'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}

tenant('vf-de-cop-lab', 'de') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-cop-lab',      img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    def repo_specifier_regex = '.*(ps_match_mobile|images).*'
    def branch_specifier_regex = '.*'
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics',
                                             standard_org_folder_auth('de'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}

tenant('vf-de-puz-lab', 'de') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-puz-lab',      img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    def repo_specifier_regex = '.*images.*'
    def branch_specifier_regex = '.*'
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics',
                                             standard_org_folder_auth('de'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}

tenant('vf-de-puz-nonlive', 'de') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-puz-nonlive',      img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    def repo_specifier_regex = '.*images.*'
    def branch_specifier_regex = '.*'
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics',
                                             standard_org_folder_auth('de'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}

tenant('vf-de-puz-live', 'de') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-puz-live',      img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    def repo_specifier_regex = '.*images.*'
    def branch_specifier_regex = '.*'
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics',
                                             standard_org_folder_auth('de'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}

tenant('vf-de-ebu-live', 'de') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-de-ebu-live', dag_deploy_auth('de'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-de-ebu-live', dag_deploy_auth('de'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-ebu-live',     img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    def repo_specifier_regex = '.*images.*'
    def branch_specifier_regex = '.*'
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics',
                                             standard_org_folder_auth('de'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}

tenant('vf-de-ebu-nonlive', 'de') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-de-ebu-nonlive', dag_deploy_auth('de'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-de-ebu-nonlive', dag_deploy_auth('de'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-de-ebu',    img_promote_auth('de'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-ebu-nonlive',     img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    def repo_specifier_regex = '.*images.*'
    def branch_specifier_regex = '.*'
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics',
                                             standard_org_folder_auth('de'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}

tenant('vf-de-ebu-lab', 'de') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-de-ebu-lab', dag_deploy_auth('de'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-de-ebu-lab', dag_deploy_auth('de'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-ebu-lab',     img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    def repo_specifier_regex = '.*images.*'
    def branch_specifier_regex = '.*'
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics',
                                             standard_org_folder_auth('de'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}

tenant('vf-de-nwp-live', 'de') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-de-nwp-live', dag_deploy_auth('de'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-de-nwp-live', dag_deploy_auth('de'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-nwp-live',    img_promote_auth('de-nwp'), 'generic-image-promoter-de.groovy')
}

tenant('vf-gned-nwpenergyib-live', 'grp-nwpenergyib') {
    FOLDER ->
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-gned-nwpenergyib-live', dag_deploy_auth('grp-nwpenergyib'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-gned-nwpenergyib', img_promote_auth('grp-nwpenergyib'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-gned-nwpenergyib-live', img_promote_auth('grp-nwpenergyib'))
    //Bif deploy pipelines for NWP
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('grp-nwpenergyib') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('grp-nwpenergyib') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp-nwpenergyib') , 'tags/v2.0.0')
}

tenant('vf-uk-nwp-nonlive', 'uk') {
    FOLDER ->
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-uk-nwp-nonlive', dag_deploy_auth('uk'))
    //Bif deploy pipelines for UK-NWP-NONLIVE
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('uk') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('uk') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('uk') , 'tags/v2.0.0')
}

tenant('vf-uk-nwp-live', 'uk') {
    FOLDER ->
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-uk-nwp-live', dag_deploy_auth('uk'))
    //Bif deploy pipelines for UK-NWP-LIVE
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('uk') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('uk') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('uk'), 'tags/v2.0.0')
}
tenant('vf-gned-nwpccs-live', 'grp-nwpccs') {
    FOLDER ->
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-gned-nwpccs-live', dag_deploy_auth('grp-nwpccs'))
    //Bif deploy pipelines for gned-nwpccs-LIVE
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' , standard_tenant_auth('grp-nwpccs') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds' , standard_tenant_auth('grp-nwpccs') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy' , standard_tenant_auth('grp-nwpccs') , 'tags/v2.0.0')
}
tenant('vf-gned-nwpccs-nonlive', 'grp-nwpccs') {
    FOLDER ->
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-gned-nwpccs-nonlive', dag_deploy_auth('grp-nwpccs'))
    //Bif deploy pipelines for gned-nwpccs-nonlive
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' , standard_tenant_auth('grp-nwpccs') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds' , standard_tenant_auth('grp-nwpccs') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy' , standard_tenant_auth('grp-nwpccs') , 'tags/v2.0.0')
}

tenant('vf-gned-nwpenergyib-nonlive', 'grp-nwpenergyib') {
    FOLDER ->
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-gned-nwpenergyib-nonlive', dag_deploy_auth('grp-nwpenergyib'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-gned-nwpenergyib-nonlive', img_promote_auth('grp-nwpenergyib'))
    //Bif deploy pipelines for NWP
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('grp-nwpenergyib') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('grp-nwpenergyib') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp-nwpenergyib') , 'tags/v2.0.0')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('grp-nwpenergyib') , 'tags/v2.0.0')
}

tenant('vf-de-nwp-nonlive', 'de') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-de-nwp-nonlive', dag_deploy_auth('de'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-de-nwp-nonlive', dag_deploy_auth('de'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-de-nwp',    img_promote_auth('de-nwp'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-nwp-nonlive', img_promote_auth('de-nwp'), 'generic-image-promoter-de.groovy')
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' , standard_tenant_auth('de-nwp') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds' , standard_tenant_auth('de-nwp') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy' , standard_tenant_auth('de-nwp') , 'tags/v2.0.0')
}

tenant('vf-de-train-lab', 'de') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-train-lab', img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    def repo_specifier_regex = '.*images.*'
    def branch_specifier_regex = '.*'
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics',
                                             standard_org_folder_auth('de'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}

tenant('vf-de-ita-lab', 'de') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-ita-lab', img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    def repo_specifier_regex = '.*images.*'
    def branch_specifier_regex = '.*'
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics',
                                             standard_org_folder_auth('de'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}

tenant('vf-de-eds-live', 'de') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-eds-live', img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    // allow master branches of some repositories only
    def repo_specifier_regex = '.*neuron-eds-de.*'
    def branch_specifier_regex = 'master'
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics',
                                             standard_org_folder_auth('de'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}

tenant('vf-de-eds-nonlive', 'de') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-eds-nonlive', img_promote_auth('de'), 'generic-image-promoter-de.groovy')
    def repo_specifier_regex = '.*neuron-eds-de.*'
    run_org_folder(FOLDER + '/VFDE-CloudAnalytics',
                                            standard_org_folder_auth('de'),
                                            repo_specifier_regex
                                           )
}

tenant('vf-es-ca-live', 'es') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-es-ca-live',  dag_deploy_auth('es'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-es-ca-live', dag_deploy_auth('es'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-es-ca-live',        img_promote_auth('es'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('ops'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('ops'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', dag_deploy_auth('ops'))
    live_ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-es-ca-live', img_promote_auth('es'), [market_name:'es-ca'])
    // allow master branches of some repositories only
    def repo_specifier_regex = '.*(composer-config|deploy_code|refresh_vm_image).*'
    def branch_specifier_regex = 'master'
    run_org_folder(FOLDER + '/VFES-CloudAnalytics',
                                             no_viewer_tenant_auth('es'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}
tenant('vf-es-ca-nonlive', 'es') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-es-ca-nonlive', dag_deploy_auth('es'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-es-ca-nonlive',  dag_deploy_auth('es'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-es-ca',     img_promote_auth('es'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-es-ca-nonlive',     img_promote_auth('es'))
    ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-es-ca-nonlive', img_promote_auth('es'), [market_name:'es-ca'])
    ra_prepare_deploy_packages(FOLDER + '/neuron-ra-prepare-deploy-package-es',  img_promote_auth('es'))
    run_org_folder(FOLDER + '/VFES-CloudAnalytics', standard_org_folder_auth('es'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('es'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('es'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp'))
}

tenant('vf-es-cbu-nonlive', 'es') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-es-cbu-nonlive', dag_deploy_auth('es'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-es-cbu-nonlive', dag_deploy_auth('es'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-es-cbu',    img_promote_auth('es'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-es-cbu-nonlive',    img_promote_auth('es'))
}

tenant('vf-es-ebu-nonlive', 'es') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-es-ebu-nonlive', dag_deploy_auth('es'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-es-ebu-nonlive', dag_deploy_auth('es'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-es-ebu',    img_promote_auth('es'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-es-ebu-nonlive',    img_promote_auth('es'))
}

tenant('vf-es-network-nonlive', 'es') {
    FOLDER ->
}

tenant('vf-es-mc2-live', 'es-mc2') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-es-mc2-live', dag_deploy_auth('es-mc2'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-es-mc2-live', dag_deploy_auth('es-mc2'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-es-mc2-live', build_cancel_read_job(['ravi.bhadresa@vodafone.com', 'gcp-vf-grp-jenkins-user']))
}
tenant('vf-es-mc2-nonlive', 'es-mc2') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-es-mc2-nonlive', dag_deploy_auth('es-mc2'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-es-mc2-nonlive', dag_deploy_auth('es-mc2'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-es-mc2',    img_promote_auth('es-mc2'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-es-mc2-nonlive',    img_promote_auth('es-mc2'))
}
tenant('vf-grp-mc2compute-nonlive', 'grp-mc2compute') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-grp-mc2compute-nonlive', dag_deploy_auth('grp-mc2compute'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-mc2compute-nonlive', dag_deploy_auth('grp-mc2compute'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-grp-mc2compute',    img_promote_auth('grp-mc2compute'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-mc2compute-nonlive',    img_promote_auth('grp-mc2compute'))
}
tenant('vf-grp-mc2compute-live', 'grp-mc2compute') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-grp-mc2compute-live', dag_deploy_auth('grp-mc2compute'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-mc2compute-live', dag_deploy_auth('grp-mc2compute'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-grp-mc2compute',    img_promote_auth('grp-mc2compute'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-mc2compute-live',    img_promote_auth('grp-mc2compute'))
}
tenant('vf-gr-ca-live', 'gr') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-gr-ca-live',  dag_deploy_auth('gr'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-gr-ca-live', dag_deploy_auth('gr'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-gr-ca-live',        img_promote_auth('gr'))
    live_ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-gr-ca-live', img_promote_auth('gr'), [market_name:'gr-ca'])
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('ops'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('ops'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', dag_deploy_auth('ops'))
}
tenant('vf-gr-ca-nonlive', 'gr') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-gr-ca-nonlive', dag_deploy_auth('gr'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-gr-ca-nonlive',  dag_deploy_auth('gr'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-gr-ca',     img_promote_auth('gr'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-gr-ca-nonlive',     img_promote_auth('gr'))
    ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-gr-ca-nonlive', img_promote_auth('gr'), [market_name:'gr-ca'])
    dp_composer_deployer_pipeline(FOLDER + '/neuron-dp-composer-deployer-gr',  img_promote_auth('gr'))
    ra_prepare_deploy_packages(FOLDER + '/neuron-ra-prepare-deploy-package-gr',  img_promote_auth('gr'))
    run_org_folder(FOLDER + '/VFGR-CloudAnalytics', standard_org_folder_auth('gr'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('gr'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('gr'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', dag_deploy_auth('grp'))
}
tenant('vf-grp-mc2-live', 'grp-mc2') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-grp-mc2-live', dag_deploy_auth('grp-mc2'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-mc2-live', dag_deploy_auth('grp-mc2'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-mc2-live',  img_promote_auth('grp-mc2'))
}
tenant('vf-grp-mc2-nonlive', 'grp-mc2') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-grp-mc2-nonlive', dag_deploy_auth('grp-mc2'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-mc2-nonlive', dag_deploy_auth('grp-mc2'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-mc2-nonlive',  img_promote_auth('grp-mc2'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-grp-mc2', img_promote_auth('grp-mc2'))
}
tenant('vf-grp-spx-live', 'grp-spx') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-grp-spx-live', dag_deploy_auth('grp-spx'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-spx-live', dag_deploy_auth('grp-spx'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-spx-live',  img_promote_auth('grp-spx'))
}
tenant('vf-grp-spx-nonlive', 'grp-spx') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-grp-spx-nonlive', dag_deploy_auth('grp-spx'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-spx-nonlive', dag_deploy_auth('grp-spx'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-grp-spx', img_promote_auth('grp-spx'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-spx-nonlive',  img_promote_auth('grp-spx'))
}
tenant('vf-grp-spx-lab', 'grp-spx') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-grp-spx-lab', dag_deploy_auth('grp-spx'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-spx-lab', dag_deploy_auth('grp-spx'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-spx-lab',  img_promote_auth('grp-spx'))
}
tenant('vf-ie-ca-live', 'ie') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-ie-ca-live', dag_deploy_auth('ie'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-ie-ca-live', dag_deploy_auth('ie'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-ie-ca-live', img_promote_auth('ie'))
    live_ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-ie-ca-live', img_promote_auth('ie'), [market_name:'ie-ca'])
}
tenant('vf-ie-ca-nonlive', 'ie') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-ie-ca-nonlive', dag_deploy_auth('ie'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-ie-ca-nonlive', dag_deploy_auth('ie'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-ie-ca', img_promote_auth('ie'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-ie-ca-nonlive', img_promote_auth('ie'))
    ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-ie-ca-nonlive', img_promote_auth('ie'), [market_name:'ie-ca'])
    dp_composer_deployer_pipeline(FOLDER + '/neuron-dp-composer-deployer-ie', img_promote_auth('ie'))
    ra_prepare_deploy_packages(FOLDER + '/neuron-ra-prepare-deploy-package-ie',  img_promote_auth('ie'))
    run_org_folder(FOLDER + '/VFIE-CloudAnalytics', standard_org_folder_auth('ie'))
}
tenant('vf-it-ca-live', 'it') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-it-ca-live',  dag_deploy_auth('it'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-it-ca-live', dag_deploy_auth('it'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-it-ca-live',        img_promote_auth('it'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('ops'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('ops'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', dag_deploy_auth('ops'))
    live_ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-it-ca-live', img_promote_auth('it'), [market_name:'it-ca'])
}
tenant('vf-it-ca-nonlive', 'it') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-it-ca-nonlive', dag_deploy_auth('it'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-it-ca-nonlive',  dag_deploy_auth('it'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-it-ca',     img_promote_auth('it'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-it-ca-nonlive',     img_promote_auth('it'))
    ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-it-ca-nonlive', img_promote_auth('it'), [market_name:'it-ca'])
    ra_prepare_deploy_packages(FOLDER + '/neuron-ra-prepare-deploy-package-it',  img_promote_auth('it'))
    run_org_folder(FOLDER + '/VFIT-CloudAnalytics', standard_org_folder_auth('it'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('it'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('it'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp'))
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('it'))
}
tenant('vf-it-puz-live', 'it-puz') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-it-puz-live', dag_deploy_auth('it-puz'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-it-puz-live', dag_deploy_auth('it-puz'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-it-puz-live',       img_promote_auth('it-puz'))
    live_ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-it-puz-live', img_promote_auth('it-puz'), [market_name: 'it-puz'])
    //BIFv5 deploy pipelines for it-puz
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' , standard_tenant_auth('it-puz') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-de-puz-live' , standard_tenant_auth('it-puz') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy' , standard_tenant_auth('it-puz') , 'tags/v2.0.0')
}
tenant('vf-it-puz-nonlive', 'it-puz') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-it-puz-nonlive', dag_deploy_auth('it-puz'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-it-puz-nonlive', dag_deploy_auth('it-puz'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-it-puz-nonlive',    img_promote_auth('it-puz'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-it-puz',    img_promote_auth('it-puz') , 'tags/v2.1')
    ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-it-puz-nonlive', img_promote_auth('it-puz'), [market_name: 'it-puz'])
    run_org_folder(FOLDER + '/VFGroup-MA-Puzzle', standard_org_folder_auth('it-puz'))
    //BIFv5 deploy pipelines for it-puz
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' , standard_tenant_auth('it-puz') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds' , standard_tenant_auth('it-puz') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy' , standard_tenant_auth('it-puz') , 'tags/v2.0.0')
}
tenant('vf-it-puz-lab', 'it-puz') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-it-puz-lab', dag_deploy_auth('it-puz'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-it-puz-lab',     dag_deploy_auth('it-puz'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-it-puz-lab',        img_promote_auth('it-puz'))
}
tenant('vf-lm3-ca-live', 'lm3') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-lm3-ca-live', build_cancel_read_job(['gcp-vf-grp-jenkins-user']))
}
tenant('vf-lm3-ca-nonlive', 'lm3') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-lm3-ca-nonlive', build_cancel_read_job(['gcp-vf-grp-jenkins-user']))
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-lm3-ca-nonlive', dag_deploy_auth('lm3'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-lm3-ca-nonlive', dag_deploy_auth('lm3'))
}
tenant('vf-mc2dev-ca-live', 'mc2dev') {
    FOLDER ->
}
tenant('vf-mc2dev-ca-nonlive', 'mc2dev') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-mc2dev-ca-nonlive', build_cancel_read_job(['gcp-vf-mc2dev-platformengineers', 'gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user']))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-mc2dev-ca-nonlive', build_cancel_read_job(['gcp-vf-mc2dev-platformengineers', 'gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user']))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-mc2dev-ca-nonlive', build_cancel_read_job(['connor.wilkes@vodafone.com', 'gcp-vf-grp-jenkins-user']))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-mc2dev-ca', build_cancel_read_job(['connor.wilkes@vodafone.com', 'gcp-vf-grp-jenkins-user']))
}

tenant('vf-pt-aa-live', 'pt-aa') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-pt-aa-live', dag_deploy_auth('pt-aa'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-pt-aa-live', dag_deploy_auth('pt-aa'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-pt-aa-live',  img_promote_auth('pt-aa'))
}

tenant('vf-pt-aa-nonlive', 'pt-aa') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-pt-aa-nonlive', dag_deploy_auth('pt-aa'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-pt-aa-nonlive', dag_deploy_auth('pt-aa'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-pt-aa-nonlive',  img_promote_auth('pt-aa'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-pt-aa', img_promote_auth('pt-aa'))
}
tenant('vf-pt-aa-lab', 'pt-aa') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-pt-aa-lab', dag_deploy_auth('pt-aa'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-pt-aa-lab', dag_deploy_auth('pt-aa'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-pt-aa-lab',  img_promote_auth('pt-aa'))
}
tenant('vf-pt-ca-live', 'pt') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-pt-ca-live',  dag_deploy_auth('pt'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-pt-ca-live',        img_promote_auth('pt'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-pt-ca-live', dag_deploy_auth('pt'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('ops') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('ops') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', dag_deploy_auth('ops') , 'tags/v2.0.0')
    live_ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-pt-ca-live', img_promote_auth('pt'), [market_name:'pt-ca'])
}
tenant('vf-pt-ca-nonlive', 'pt') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-pt-ca-nonlive', dag_deploy_auth('pt'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-pt-ca-nonlive',  dag_deploy_auth('pt'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-pt-ca',     img_promote_auth('pt'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-pt-ca-nonlive',     img_promote_auth('pt'))
    run_org_folder(FOLDER + '/VFPT-CloudAnalytics', standard_org_folder_auth('pt'))
    ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-pt-ca-nonlive', img_promote_auth('pt'), [market_name:'pt-ca'])
    ra_prepare_deploy_packages(FOLDER + '/neuron-ra-prepare-deploy-package-pt',  img_promote_auth('pt'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('pt') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('pt') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp') , 'tags/v2.0.0')
}

tenant('vf-pt-ds-live', 'pt') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-pt-ds-live',  dag_deploy_auth('pt'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-pt-ds-live',        img_promote_auth('pt'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-pt-ds-live', dag_deploy_auth('pt'))
    live_ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-pt-ds-live', img_promote_auth('pt'), [market_name:'pt-ca'])
}
tenant('vf-pt-ds-nonlive', 'pt') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-pt-ds-nonlive', dag_deploy_auth('pt'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-pt-ds-nonlive',  dag_deploy_auth('pt'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-pt-ca',     img_promote_auth('pt'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-pt-ds-nonlive',     img_promote_auth('pt'))
    run_org_folder(FOLDER + '/VFPT-CloudAnalytics', standard_org_folder_auth('pt'))
    ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-pt-ds-nonlive', img_promote_auth('pt'), [market_name:'pt-ca'])
    ra_prepare_deploy_packages(FOLDER + '/neuron-ra-prepare-deploy-package-pt',  img_promote_auth('pt'))
}

tenant('vf-pt-ca-lab', 'pt') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-pt-ca-lab',     img_promote_auth('pt'))
}

tenant('vf-pt-ngbi-prd-gen-01', 'pt-ngbi') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-pt-ngbi-prd-gen-01', dag_deploy_auth('pt-ngbi'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-pt-ngbi-prd-gen-01',    img_promote_auth('pt-ngbi'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-pt-ngbi-prd-gen-01', dag_deploy_auth('pt-ngbi'))
}

tenant('vf-pt-ngbi-nonlive', 'pt-ngbi') {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-pt-ngbi',    img_promote_auth('pt-ngbi'))
}

tenant('vf-pt-ngbi-pprd-gen-02', 'pt-ngbi') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-pt-ngbi-pprd-gen-02', dag_deploy_auth('pt-ngbi'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-pt-ngbi-pprd-gen-02', dag_deploy_auth('pt-ngbi'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-pt-ngbi-pprd-gen-02',    img_promote_auth('pt-ngbi'))
}

tenant('vf-pt-ngbi-pprd-gen-03', 'pt-ngbi') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-pt-ngbi-pprd-gen-03', dag_deploy_auth('pt-ngbi'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-pt-ngbi-pprd-gen-03', dag_deploy_auth('pt-ngbi'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-pt-ngbi-pprd-gen-03',    img_promote_auth('pt-ngbi'))
}

tenant('vf-sky-ca-live', 'sky') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-sky-ca-live',  dag_deploy_auth('sky'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-sky-ca-live', dag_deploy_auth('sky'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-sky-ca-live', img_promote_auth('sky'))
}

tenant('vf-sky-ca-nonlive', 'sky') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-sky-ca-nonlive', dag_deploy_auth('sky'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-sky-ca-nonlive', dag_deploy_auth('sky'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-sky-ca-nonlive', img_promote_auth('sky'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-sky-ca', img_promote_auth('sky'))
}

tenant('vf-uk-mc2-live', 'uk-mc2') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-uk-mc2-live', dag_deploy_auth('uk-mc2'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-uk-mc2-live', dag_deploy_auth('uk-mc2'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-uk-mc2-live',  img_promote_auth('uk-mc2'))
}

tenant('vf-uk-mc2-nonlive', 'uk-mc2') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-uk-mc2-lab', dag_deploy_auth('uk-mc2'))
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-uk-mc2-nonlive', dag_deploy_auth('uk-mc2'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-uk-mc2-lab', dag_deploy_auth('uk-mc2'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-uk-mc2-nonlive', dag_deploy_auth('uk-mc2'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-uk-mc2', img_promote_auth('uk-mc2'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-uk-mc2-lab',  img_promote_auth('uk-mc2'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-uk-mc2-nonlive',  img_promote_auth('uk-mc2'))
}

tenant('vf-uk-ca-live', 'uk') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-uk-ca-live', img_promote_auth('uk'))
}

tenant('vf-uk-ca-nonlive', 'uk') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-uk-ca-nonlive', img_promote_auth('uk'))
}

tenant('vf-uk-vbuk-live', 'uk-vbuk') {
    FOLDER ->
    drs_deploy_policies_pipeline_versioned(FOLDER + '/neuron-drs-deploy-policies', standard_tenant_auth('grp') , 'tags/v2.0.0')
    drs_deploy_functions_pipeline_versioned(FOLDER + '/neuron-drs-deploy-functions', standard_tenant_auth('grp') , 'tags/v2.0.0')
    drs_ops_trash_pipeline_versioned(FOLDER + '/neuron-ops-trash', standard_tenant_auth('grp') , 'tags/v2.0.0')
    drs_ops_prepare_trash_pipeline_versioned(FOLDER + '/neuron-ops-prepare-trash', standard_tenant_auth('grp') , 'tags/v2.0.0')
}

tenant('vf-cz-ca-nonlive', 'cz') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-cz-ca-nonlive', img_promote_auth('cz'))
}

tenant('vf-al-ca-nonlive', 'al') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-al-ca-nonlive', img_promote_auth('al'))
}

tenant('vf-za-ca-nonlive', 'za') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-za-ca-nonlive', img_promote_auth('za'))
}

tenant('vf-za-aa-live', 'za-aa') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-za-aa-live', dag_deploy_auth('za-aa'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-za-aa-live', dag_deploy_auth('za-aa'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-za-aa-live',  img_promote_auth('za-aa'))
}

tenant('vf-za-aa-nonlive', 'za-aa') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-za-aa-nonlive', dag_deploy_auth('za-aa'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-za-aa-nonlive', dag_deploy_auth('za-aa'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-za-aa', img_promote_auth('za-aa'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-za-aa-nonlive',  img_promote_auth('za-aa'))
    run_org_folder(FOLDER + '/VCZA-BigData', standard_org_folder_auth('za-aa'))
}
tenant('vf-atesio-nwp-live', 'atesio-nwp') {
    FOLDER ->
}
tenant('vf-atesio-nwp-nonlive', 'atesio-nwp') {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-atesio-nwp',    img_promote_short_auth('atesio-nwp'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-atesio-nwp-nonlive', img_promote_short_auth('atesio-nwp'))
}
tenant('vf-cip-sky-live', 'sky') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-cip-sky-live',      img_promote_auth('sky'))
}
tenant('vf-cip-sky-nonlive', 'sky') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-cip-sky-nonlive',   img_promote_auth('sky'))
}
tenant('vf-continual-nwp-live', 'continual-nwp') {
    FOLDER ->
}
tenant('vf-continual-nwp-nonlive', 'continual-nwp') {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-continual-nwp', img_promote_short_auth('continual-nnwp'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-continual-nwp-nonlive', img_promote_short_auth('continual-nwp'))
}

tenant('vf-es-nwp-live', 'es-nwp') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-es-nwp-live',       img_promote_auth('es-nwp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' , standard_tenant_auth('es-nwp') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds' , standard_tenant_auth('es-nwp') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy' , standard_tenant_auth('es-nwp') , 'tags/v2.0.0')
}

tenant('vf-es-nwp-nonlive', 'es-nwp') {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-es-nwp',    img_promote_auth('es-nwp'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-es-nwp-nonlive',    img_promote_auth('es-nwp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' ,  standard_tenant_auth('es-nwp') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds' ,  standard_tenant_auth('es-nwp') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy' ,  standard_tenant_auth('es-nwp') , 'tags/v2.0.0')
    def repo_specifier_regex = '.*DE---Dataflow-RPS-Correlation.*'
    run_org_folder(FOLDER + '/vfgroup-gned-nwplanning',
                                            standard_org_folder_auth('es-nwp'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-gned-nwp-live', 'gned-nwp') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-gned-nwp-live', img_promote_short_auth('gned-nwp'))
    live_ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-gned-nwp-live', img_promote_auth('gned-nwp'), [market_name:'gned-nwp'])
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', standard_tenant_auth('gned-nwp') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', standard_tenant_auth('gned-nwp') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('gned-nwp') , 'tags/v2.0.0')
}
tenant('vf-gned-nwp-nonlive', 'gned-nwp') {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-gned-nwp',      img_promote_short_auth('gned-nwp'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-gned-nwp-nonlive', img_promote_short_auth('gned-nwp'))
    ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-gned-nwp-nonlive', img_promote_auth('gned-nwp'), [market_name:'gned-nwp'])
    run_org_folder(FOLDER + '/vfgroup-gned-nwplanning', standard_org_folder_auth('gned-nwp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', standard_tenant_auth('gned-nwp') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', standard_tenant_auth('gned-nwp') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('gned-nwp') , 'tags/v2.0.0')

}
tenant('vf-gr-nwp-live', 'gr-nwp') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-gr-nwp-live',       img_promote_auth('gr-nwp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' , standard_tenant_auth('gr-nwp') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds' , standard_tenant_auth('gr-nwp') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy' , standard_tenant_auth('gr-nwp') , 'tags/v2.0.0')
}
tenant('vf-gr-nwp-nonlive', 'gr-nwp') {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-gr-nwp',    img_promote_auth('gr-nwp'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-gr-nwp-nonlive',    img_promote_auth('gr-nwp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' , standard_tenant_auth('gr-nwp') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds' , standard_tenant_auth('gr-nwp') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy' , standard_tenant_auth('gr-nwp') , 'tags/v2.0.0')
}
tenant('vf-grp-cmrbdai-live', cmrbdai_auth()) {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-cmrbdai-live', cmrbdai_auth())
}
tenant('vf-grp-cmrbdai-nonlive', cmrbdai_auth()) {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-grp-cmrbdai', cmrbdai_auth())
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-cmrbdai-nonlive', cmrbdai_auth())
}
tenant('vf-grp-cmrbdai-lab', cmrbdai_auth()) {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-cmrbdai-lab', cmrbdai_auth())
}
tenant('vf-hu-ca-live', 'hu') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-hu-ca-live',        img_promote_auth('hu'))
    live_ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-hu-ca-live', img_promote_auth('hu'), [market_name:'hu-ca'])
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('ops'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('ops'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('ops'))
}
tenant('vf-hu-ca-nonlive', 'hu') {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-hu',        img_promote_auth('hu'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-hu-ca-nonlive',     img_promote_auth('hu'))
    ndgcsync_sync_pipeline(FOLDER + '/neuron-ndgcsync-hu-ca-nonlive', img_promote_auth('hu'), [market_name:'hu-ca'])
    run_org_folder(FOLDER + '/VFHU-CloudAnalytics', standard_org_folder_auth('hu'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('hu'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('hu'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp'))
}
tenant('vf-hu-nwp-live', 'hu-nwp') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-hu-nwp-live',       img_promote_auth('hu-nwp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' , standard_tenant_auth('hu-nwp') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds' , standard_tenant_auth('hu-nwp') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy' , standard_tenant_auth('hu-nwp') , 'tags/v2.0.0')
}
tenant('vf-hu-nwp-nonlive', 'hu-nwp') {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-hu-nwp',    img_promote_auth('hu-nwp'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-hu-nwp-nonlive',    img_promote_auth('hu-nwp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' , standard_tenant_auth('hu-nwp') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds' , standard_tenant_auth('hu-nwp') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy' , standard_tenant_auth('hu-nwp') , 'tags/v2.0.0')
}
tenant('vf-it-nwp-live', 'it-nwp') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-it-nwp-live',       img_promote_auth('it-nwp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' , standard_tenant_auth('it-nwp') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds' , standard_tenant_auth('it-nwp') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('it-nwp'), 'tags/v2.0.0')
}
tenant('vf-it-nwp-nonlive', 'it-nwp') {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-it-nwp',    img_promote_auth('it-nwp'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-it-nwp-nonlive',    img_promote_auth('it-nwp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' ,  standard_tenant_auth('it-nwp') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds' ,  standard_tenant_auth('it-nwp') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy' ,  standard_tenant_auth('it-nwp') , 'tags/v2.0.0')
}
tenant('vf-itanpo-nwp-live', 'it-nwp') {
    FOLDER ->
}
tenant('vf-itanpo-nwp-nonlive', 'it-nwp') {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-itanpo-nwp', img_promote_auth('it-nwp'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-itanpo-nwp-nonlive', img_promote_auth('it-nwp'))
}
tenant('vf-lm1-ca-live', 'lm1') {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-lm1-ca',    build_cancel_read_job(['gcp-vf-grp-jenkins-user']))
}
tenant('vf-lm1-ca-nonlive', 'lm1') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-lm1-ca-nonlive', build_cancel_read_job(['gcp-vf-grp-jenkins-user']))
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-lm1-ca-nonlive', dag_deploy_auth('lm1'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-lm1-ca-nonlive', dag_deploy_auth('lm1'))
    dp_composer_deployer_pipeline(FOLDER + '/neuron-dp-composer-deployer-lm1',  img_promote_auth('lm1'))
    ra_prepare_deploy_packages(FOLDER + '/neuron-ra-prepare-deploy-package-lm1',  img_promote_auth('lm1'))
}
tenant('vf-nok-nwp-live', 'nok-nwp') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-nok-nwp-live', build_cancel_read_job(['gcp-vf-nwp-nok-ds-user', 'gcp-vf-grp-jenkins-user']))
}
tenant('vf-nok-nwp-nonlive', 'nok-nwp') {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-nok-nwp', build_cancel_read_job(['gcp-vf-nwp-nok-ds-user', 'gcp-vf-grp-jenkins-user']))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-nok-nwp-nonlive', build_cancel_read_job(['gcp-vf-nwp-nok-ds-user', 'gcp-vf-grp-jenkins-user']))
}

tenant('vf-pt-nwp-nonlive', 'pt-nwp') {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-pt-nwp',    img_promote_auth('pt-nwp'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-pt-nwp-nonlive',    img_promote_auth('pt-nwp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-pt-nwp-nonlive' , standard_tenant_auth('pt-nwp') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-pt-nwp-nonlive' , standard_tenant_auth('pt-nwp') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-pt-nwp-nonlive' , standard_tenant_auth('pt-nwp') , 'tags/v2.0.0')
}
tenant('vf-ro-ca-live', 'ro') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-ro-ca-live',        img_promote_auth('ro'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' , dag_deploy_auth('ops') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds' , dag_deploy_auth('ops') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy' , dag_deploy_auth('ops') , 'tags/v2.0.0')
}
tenant('vf-ro-ca-nonlive', 'ro') {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-ro-ca',     img_promote_auth('ro'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-ro-ca-nonlive',     img_promote_auth('ro'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' , dag_deploy_auth('ro') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds' , dag_deploy_auth('ro') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy' , standard_tenant_auth('grp') , 'tags/v2.0.0')
}
tenant('vf-ro-nwp-live', 'ro-nwp') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-ro-nwp-live',       tenant_pipeline_auth('ro') + img_promote_auth('ro-nwp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' , standard_tenant_auth('ro-nwp') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-ro-nwp-live' , standard_tenant_auth('ro-nwp') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy' , standard_tenant_auth('ro-nwp') , 'tags/v2.0.0')
}
tenant('vf-ro-nwp-nonlive', 'ro-nwp') {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-ro-nwp',    img_promote_auth('ro-nwp'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-ro-nwp-nonlive',    tenant_pipeline_auth('ro') + img_promote_auth('ro-nwp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator' , standard_tenant_auth('ro-nwp') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds' , standard_tenant_auth('ro-nwp') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy' , standard_tenant_auth('ro-nwp') , 'tags/v2.0.0')
}
tenant('vf-cis-cms-dataengineering', 'cis-cms-dataengineer') {
    FOLDER ->
    def repo_specifier_regex = '.*(vf-cis-cms-df-.*|vf-cis-dynamo-dp-pg-.*|vf-cis-dynamo-dp-ppl-.*|vf-cis-dynamo-dp-tool-.*|vf-cis-dynamo-dp-lib-.*|vf-cis-dynamo-dp-dag-.*).*'
    def branch_specifier_regex = '.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                             standard_org_folder_auth('cis-cms-dataengineer'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
}
tenant('vf-cis-dynamo', 'grp-dynamo') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-cis-dynamo.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('grp-dynamo'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-grp-dynamo-lab-lm', 'lml-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-lml-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('lml-ngbi'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-de-ngbi-dev-gen-01', 'de-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-de-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('de-ngbi'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-de-ngbi-tst-gen-01', 'de-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-de-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('de-ngbi'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-de-ngbi-pprd-gen-01', 'de-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-de-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('de-ngbi'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-de-ngbi-prd-gen-01', 'de-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-de-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('de-ngbi'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-de-puz-live', 'de-puz') {
    FOLDER ->
    // def dag_auth = dag_deploy_auth('de-puz')
    def repo_specifier_regex = '.*(puzzle-bif-cfg-de|de-puzzle-reconciliation).*'
    run_org_folder(FOLDER + '/VFGroup-MA-Puzzle',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('de-puz'),
                                            repo_specifier_regex
                                           )
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-de-puz-live', dag_deploy_auth('de-puz'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-de-puz-live', dag_deploy_auth('de-puz'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-puz-live', img_promote_auth('de-puz'))
    //BIFv5 deploy pipelines for de-puz
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('de-puz') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('de-puz') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('de-puz') , 'tags/v2.0.0')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('de-puz') , 'tags/v2.0.0')
}
tenant('vf-de-puz-nonlive', 'de-puz') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('de-puz')
    def repo_specifier_regex = '.*(puzzle-bif-cfg-de|de-puzzle-reconciliation).*'
    run_org_folder(FOLDER + '/VFGroup-MA-Puzzle',
                                                    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                                    + tenant_read_job_auth('de-puz'),
                                                    repo_specifier_regex
                                                          )
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-de-puz-nonlive', dag_deploy_auth('de-puz'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-de-puz-nonlive', dag_auth)
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-de-puz', img_promote_auth('de-puz'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-puz-nonlive', img_promote_auth('de-puz'))
    //BIFv5 deploy pipelines for de-puz
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('de-puz') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('de-puz') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('de-puz') , 'tags/v2.0.0')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('de-puz') , 'tags/v2.0.0')
}
tenant('vf-pt-nucleus', 'pt-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-pt-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('pt-ngbi'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-pt-ngbi-pprd-gen-03', 'pt-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-pt-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('pt-ngbi'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-pt-ngbi-prd-gen-01', 'pt-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-pt-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('pt-ngbi'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-grp-dts-prd-eds', 'vrs-dts') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('vrs-dts')
    def repo_specifier_regex = '.*DTS-EDS.*'
    run_org_folder(FOLDER + '/VFGroup-VRS-DTS',
                                                    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                                    + tenant_read_job_auth('vrs-dts'),
                                                    repo_specifier_regex
                                                          )
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-dts-prd-eds', dag_auth)
}
tenant('vf-gned-eds-live', 'gned-nwp') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-gned-eds-live',  dag_deploy_auth('gned-nwp'))
    neds_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-gned-eds-live', dag_deploy_auth('gned-nwp'))
}
tenant('vf-gned-eds-nonlive', 'gned-nwp') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-gned-eds-nonlive',  dag_deploy_auth('gned-nwp'))
    neds_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-gned-eds-nonlive', dag_deploy_auth('gned-nwp'))
}
tenant('vf-uk-ngbi-pprd-gen-01', 'uk-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-uk-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('uk-ngbi'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-uk-ngbi-prd-gen-01', 'uk-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-uk-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('uk-ngbi'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-uk-ngbi-dev-gen-01', 'uk-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-uk-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('uk-ngbi'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-uk-ngbi-tst-gen-01', 'uk-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-uk-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('uk-ngbi'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-cz-ngbi-pprd-gen-01', 'cz-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-cz-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('cz-ngbi'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-cz-ngbi-prd-gen-01', 'cz-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-cz-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('cz-ngbi'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-cz-ngbi-dev-gen-01', 'cz-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-cz-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('cz-ngbi'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-cz-ngbi-tst-gen-01', 'cz-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-cz-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('cz-ngbi'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-inf-ca-live', 'inf') {
    FOLDER ->
    def repo_specifier_regex = '.*(infini?ty|kubeflow|vf-(es|ro|ie|uk)-ngbi-mc2-aa).*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                            + tenant_read_job_auth('inf'),
                                            repo_specifier_regex
                                           )
}
tenant('vf-grp-neds-nonlive-trusted', 'grp-neds') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('grp-neds')
    def repo_specifier_regex = '.*vf-cis-neds.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                                    build_read_job__read_view(['gcp-vf-grp-neds-jenkins-admin', 'gcp-vf-grp-neds-jenkins-user'])
                                                    + tenant_read_job_auth('grp-neds'),
                                                    repo_specifier_regex
                                                          )
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-grp-neds-nonlive-trusted', dag_deploy_auth('grp-neds'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-neds-nonlive-trusted', dag_auth)
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-vf-grp-neds-nonlive-trusted', img_promote_auth('grp-neds'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-neds-nonlive-trusted', img_promote_auth('grp-neds'))
}

tenant('vf-grp-neds-live-trusted', 'grp-neds') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('grp-neds')
    def repo_specifier_regex = '.*vf-cis-neds.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                                    build_read_job__read_view(['gcp-vf-grp-neds-jenkins-admin', 'gcp-vf-grp-neds-jenkins-user'])
                                                    + tenant_read_job_auth('grp-neds'),
                                                    repo_specifier_regex
                                                          )
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-grp-neds-live-trusted', dag_deploy_auth('grp-neds'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-neds-live-trusted', dag_auth)
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-vf-grp-neds-live-trusted', img_promote_auth('grp-neds'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-neds-live-trusted', img_promote_auth('grp-neds'))
}

tenant('vf-grp-vrsbi-nonlive', 'vrsbidev') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('vrsbidev')
    def repo_specifier_regex = '.*(vrs-cfg-bi|vrs-bi-smef).*'
    run_org_folder(FOLDER + '/VFGroup-VRS-DTS',
                                                    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                                    + tenant_read_job_auth('vrsbidev'),
                                                    repo_specifier_regex
                                                          )
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-grp-vrsbi-nonlive', dag_deploy_auth('vrsbidev'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-vrsbi-nonlive', dag_auth)
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-nonlive-vrsbi', img_promote_auth('vrsbidev'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-vrsbi-nonlive', img_promote_auth('vrsbidev'))
    //SMEF pipelines
    dp_composer_deployer_pipeline(FOLDER + '/neuron-dp-composer-deployer-vrsbi', img_promote_auth('vrsbidev'))
    ra_prepare_deploy_packages(FOLDER + '/neuron-ra-prepare-deploy-package-vrsbi', img_promote_auth('vrsbidev'))
    //BIF pipelines
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-grp-vrsbi-nonlive', dag_deploy_auth('vrsbidev'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-grp-vrsbi-nonlive', dag_deploy_auth('vrsbidev'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-grp-vrsbi-nonlive', standard_tenant_auth('vrsbidev'))
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test-vf-grp-vrsbi-nonlive', dag_deploy_auth('vrsbidev'))
    //BIFv5.x pipelines
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-grp-vrsbi-nonlive', dag_deploy_auth('vrsbidev') , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-grp-vrsbi-nonlive', dag_deploy_auth('vrsbidev') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-grp-vrsbi-nonlive', standard_tenant_auth('vrsbidev') , 'tags/v2.0.0')
}
tenant('vf-grp-vrsbi-live', 'vrsbidev') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('vrsbidev')
    def repo_specifier_regex = '.*(vrs-cfg-bi|vrs-bi-smef).*'
    run_org_folder(FOLDER + '/VFGroup-VRS-DTS',
                                                    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                                                    + tenant_read_job_auth('vrsbidev'),
                                                    repo_specifier_regex
                                                          )
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-grp-vrsbi-live', dag_deploy_auth('vrsbidev'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-vrsbi-live', dag_auth)
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-live-vrsbi', img_promote_auth('vrsbidev'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-vrsbi-live', img_promote_auth('vrsbidev'))
    //SMEF pipelines
    dp_composer_deployer_pipeline(FOLDER + '/neuron-dp-composer-deployer-vrsbi', img_promote_auth('vrsbidev'))
    ra_prepare_deploy_packages(FOLDER + '/neuron-ra-prepare-deploy-package-vrsbi', img_promote_auth('vrsbidev'))
    //BIF pipelines
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-grp-vrsbi-live', dag_deploy_auth('vrsbidev'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-grp-vrsbi-live', dag_deploy_auth('vrsbidev'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-grp-vrsbi-live', standard_tenant_auth('vrsbidev'))
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test-vf-grp-vrsbi-live', dag_deploy_auth('vrsbidev'))
    //BIFv5.x pipelines
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-grp-vrsbi-live', dag_deploy_auth('vrsbidev')  , 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-grp-vrsbi-live', dag_deploy_auth('vrsbidev') , 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-grp-vrsbi-live', standard_tenant_auth('vrsbidev') , 'tags/v2.0.0')
}

group_folder('VFGroup') {
    FOLDER ->
    run_org_folder(FOLDER + '/VFGroup-CloudAnalytics',
                   build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
                   + tenant_read_job_auth('de')
                   + tenant_read_job_auth('es')
                   + tenant_read_job_auth('hu')
                   + tenant_read_job_auth('it')
                   + tenant_read_job_auth('pt')
                   + tenant_read_job_auth('uk')
                   + tenant_read_job_auth('cz')
                   + tenant_read_job_auth('grp-constellation')
                  )

    run_org_folder(FOLDER + '/VFGroup-Business-BigData', standard_org_folder_auth('vge'))

    def ngbi_branch_specifier_regex = '^(?!vf-cis-dynamo-ci-jobs$)(?!vf-hu-ngbi-app-cfg$)(?!vf-pt-ngbi-app-cfg$)(?!vf-de-ngbi-app-cfg$)(?!vf-lml-ngbi-app-cfg$)(?!vf-uk-ngbi-app-cfg$)(?!vf-cz-ngbi-app-cfg$)(?!vf-uk-ngbi-ml-aa$)(?!infinity)(?!kubeflow)(?!vf-cis-cms-df-.*$)(?!vf-cis-dynamo-dp-pg-.*$)(?!vf-cis-dynamo-dp-ppl-.*$)(?!vf-cis-dynamo-dp-tool-.*$)(?!vf-cis-dynamo-dp-lib-.*$)(?!vf-cis-dynamo-dp-dag-.*$).*$'

    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                            [
                                                    //Credentials Job                     Run    View     Scm
                                                    // C D M U V  B C C CV C D D M R W,   D R U  C C D R   T
                                                    auth('❌❌❌❌❌ ✅✅✅❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-grp-jenkins-admin'),
                                                    auth('❌❌❌❌❌ ✅✅✅❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-grp-jenkins-user'),
                                                    auth('❌❌❌❌❌ ✅✅❌❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-pt-ngbi-etl-jenkins-admin'),
                                            ],
                                            ngbi_branch_specifier_regex
                                                  )
}

tenant('vf-uk-ngbi-dev-ml-01', 'uk-ngbi-ml-dev') {
    FOLDER ->
    def repo_specifier_regex = '.*(ml_device_recommendation|ml_prototype|pl_dataproc|fs_subscriber_device|fs_billing|fs_usage|ml_pathway|fs_subscriber_base|pl_common_utils).*'
    def branch_specifier_regex = '.*(develop|feature).*'
    run_org_folder(FOLDER + '/VFUK-BD',
                                             standard_org_folder_auth('uk-ngbi-ml-dev'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
    def repo_specifier_regex_template = '.*(vf-uk-ngbi-ml-aa).*'
    def branch_specifier_regex_template = '.*(develop|feature).*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                                             standard_org_folder_auth('uk-ngbi-ml-dev'),
                                                             repo_specifier_regex_template,
                                                             branch_specifier_regex_template
                                                                   )
    app_deploy_pipeline_ml(FOLDER + '/neuron-app-deploy-vf-uk-ngbi-dev-ml-01', dag_deploy_auth('uk-ngbi-ml-dev'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-vf-uk-ngbi-dev-ml-01', img_promote_auth('uk-ngbi-ml-dev'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-uk-ngbi-dev-ml-01', img_promote_auth('uk-ngbi-ml-dev'), 'generic-image-promoter-de.groovy')
}

tenant('vf-uk-ngbi-tst-ml-01', 'uk-ngbi-ml-tst') {
    FOLDER ->
    def repo_specifier_regex = '.*(ml_device_recommendation|ml_prototype|pl_dataproc|fs_subscriber_device|fs_billing|fs_usage|ml_pathway|fs_subscriber_base|pl_common_utils).*'
    def branch_specifier_regex = 'release.*'
    run_org_folder(FOLDER + '/VFUK-BD',
                                             standard_org_folder_auth('uk-ngbi-ml-tst'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
    def repo_specifier_regex_template = '.*(vf-uk-ngbi-ml-aa).*'
    def branch_specifier_regex_template = 'release.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                                             standard_org_folder_auth('uk-ngbi-ml-tst'),
                                                             repo_specifier_regex_template,
                                                             branch_specifier_regex_template
                                                                   )
    app_deploy_pipeline_ml(FOLDER + '/neuron-app-deploy-vf-uk-ngbi-tst-ml-01', dag_deploy_auth('uk-ngbi-ml-tst'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-vf-uk-ngbi-tst-ml-01', img_promote_auth('uk-ngbi-ml-tst'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-uk-ngbi-tst-ml-01', img_promote_auth('uk-ngbi-ml-tst'), 'generic-image-promoter-de.groovy')
}

tenant('vf-uk-ngbi-pprd-ml-01', 'uk-ngbi-ml-pprd') {
    FOLDER ->
    def repo_specifier_regex = '.*(ml_device_recommendation|ml_prototype|pl_dataproc|fs_subscriber_device|fs_billing|fs_usage|ml_pathway|fs_subscriber_base|pl_common_utils).*'
    def branch_specifier_regex = 'release.*'
    run_org_folder(FOLDER + '/VFUK-BD',
                                             standard_org_folder_auth('uk-ngbi-ml-pprd'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
    def repo_specifier_regex_template = '.*(vf-uk-ngbi-ml-aa).*'
    def branch_specifier_regex_template = 'release.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                                             standard_org_folder_auth('uk-ngbi-ml-pprd'),
                                                             repo_specifier_regex_template,
                                                             branch_specifier_regex_template
                                                                   )
    app_deploy_pipeline_ml(FOLDER + '/neuron-app-deploy-vf-uk-ngbi-pprd-ml-01', dag_deploy_auth('uk-ngbi-ml-pprd'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-vf-uk-ngbi-pprd-ml-01', img_promote_auth('uk-ngbi-ml-pprd'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-uk-ngbi-pprd-ml-01', img_promote_auth('uk-ngbi-ml-pprd'), 'generic-image-promoter-de.groovy')
}

tenant('vf-uk-ngbi-prd-ml-01', 'uk-ngbi-ml-prd') {
    FOLDER ->
    def repo_specifier_regex = '.*(ml_device_recommendation|ml_prototype|pl_dataproc|fs_subscriber_device|fs_billing|fs_usage|ml_pathway|fs_subscriber_base|pl_common_utils).*'
    def branch_specifier_regex = 'main'
    run_org_folder(FOLDER + '/VFUK-BD',
                                             standard_org_folder_auth('uk-ngbi-ml-prd'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
    def repo_specifier_regex_template = '.*(vf-uk-ngbi-ml-aa).*'
    def branch_specifier_regex_template = 'master'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                                             standard_org_folder_auth('uk-ngbi-ml-prd'),
                                                             repo_specifier_regex_template,
                                                             branch_specifier_regex_template
                                                                   )
    app_deploy_pipeline_ml(FOLDER + '/neuron-app-deploy-vf-uk-ngbi-prd-ml-01', dag_deploy_auth('uk-ngbi-ml-prd'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-vf-uk-ngbi-prd-ml-01', img_promote_auth('uk-ngbi-ml-prd'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-uk-ngbi-prd-ml-01', img_promote_auth('uk-ngbi-ml-prd'), 'generic-image-promoter-de.groovy')
}

tenant('vf-uk-ngbi-dev-shrd-01', 'uk-ngbi-ml-dev') {
    FOLDER ->
    def repo_specifier_regex = '.*(ml_device_recommendation|ml_prototype|pl_dataproc|fs_subscriber_device|fs_billing|fs_usage|ml_pathway|fs_subscriber_base|pl_common_utils).*'
    def branch_specifier_regex = '.*(develop|feature).*'
    run_org_folder(FOLDER + '/VFUK-BD',
                                             standard_org_folder_auth('uk-ngbi-ml-dev'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
    def repo_specifier_regex_template = '.*(vf-uk-ngbi-ml-aa).*'
    def branch_specifier_regex_template = '.*(develop|feature).*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                                             standard_org_folder_auth('uk-ngbi-ml-dev'),
                                                             repo_specifier_regex_template,
                                                             branch_specifier_regex_template
                                                                   )
    dag_deploy_pipeline_shrd_composer(FOLDER + '/neuron-dag-deploy-vf-uk-ngbi-dev-shrd-01', dag_deploy_auth('uk-ngbi-ml-dev'))
}

tenant('vf-uk-ngbi-tst-shrd-01', 'uk-ngbi-ml-tst') {
    FOLDER ->
    def repo_specifier_regex = '.*(ml_device_recommendation|ml_prototype|pl_dataproc|fs_subscriber_device|fs_billing|fs_usage|ml_pathway|fs_subscriber_base|pl_common_utils).*'
    def branch_specifier_regex = 'release.*'
    run_org_folder(FOLDER + '/VFUK-BD',
                                             standard_org_folder_auth('uk-ngbi-ml-tst'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
    def repo_specifier_regex_template = '.*(vf-uk-ngbi-ml-aa).*'
    def branch_specifier_regex_template = 'release.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                                             standard_org_folder_auth('uk-ngbi-ml-tst'),
                                                             repo_specifier_regex_template,
                                                             branch_specifier_regex_template
                                                                   )
    dag_deploy_pipeline_shrd_composer(FOLDER + '/neuron-dag-deploy-vf-uk-ngbi-tst-shrd-01', dag_deploy_auth('uk-ngbi-ml-tst'))
}

tenant('vf-uk-ngbi-pprd-shrd-01', 'uk-ngbi-ml-pprd') {
    FOLDER ->
    def repo_specifier_regex = '.*(ml_device_recommendation|ml_prototype|pl_dataproc|fs_subscriber_device|fs_billing|fs_usage|ml_pathway|fs_subscriber_base|pl_common_utils).*'
    def branch_specifier_regex = 'release.*'
    run_org_folder(FOLDER + '/VFUK-BD',
                                             standard_org_folder_auth('uk-ngbi-ml-pprd'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
    def repo_specifier_regex_template = '.*(vf-uk-ngbi-ml-aa).*'
    def branch_specifier_regex_template = 'release.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                                             standard_org_folder_auth('uk-ngbi-ml-pprd'),
                                                             repo_specifier_regex_template,
                                                             branch_specifier_regex_template
                                                                   )
    dag_deploy_pipeline_shrd_composer(FOLDER + '/neuron-dag-deploy-vf-uk-ngbi-pprd-shrd-01', dag_deploy_auth('uk-ngbi-ml-pprd'))
}

tenant('vf-uk-ngbi-prd-shrd-01', 'uk-ngbi-ml-prd') {
    FOLDER ->
    def repo_specifier_regex = '.*(ml_device_recommendation|ml_prototype|pl_dataproc|fs_subscriber_device|fs_billing|fs_usage|ml_pathway|fs_subscriber_base|pl_common_utils).*'
    def branch_specifier_regex = 'main'
    run_org_folder(FOLDER + '/VFUK-BD',
                                             standard_org_folder_auth('uk-ngbi-ml-prd'),
                                             repo_specifier_regex,
                                             branch_specifier_regex
                                                   )
    def repo_specifier_regex_template = '.*(vf-uk-ngbi-ml-aa).*'
    def branch_specifier_regex_template = 'master'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
                                                             standard_org_folder_auth('uk-ngbi-ml-prd'),
                                                             repo_specifier_regex_template,
                                                             branch_specifier_regex_template
                                                                   )
    dag_deploy_pipeline_shrd_composer(FOLDER + '/neuron-dag-deploy-vf-uk-ngbi-prd-shrd-01', dag_deploy_auth('uk-ngbi-ml-prd'))
}
