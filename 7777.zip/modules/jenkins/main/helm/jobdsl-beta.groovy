tenant('vf-vbit-ip-nonlive-alpha', 'grp-vbit') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-vbit-ip-nonlive-alpha',  dag_deploy_auth('grp-vbit'))
    run_org_folder(FOLDER + '/VFGroup-VBIT', standard_org_folder_auth('grp-vbit') + standard_tenant_auth('grp-vbit'))
}

tenant('vf-d2dev-ca-live', 'd2dev') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-d2dev-ca-live',  dag_deploy_auth('d2dev'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2dev-ca-live', dag_deploy_auth('d2dev'))
    //D2TST
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2tst-ca-live', dag_deploy_auth('d2tst'))

    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-d2dev-ca-live', img_promote_auth('d2dev'))
}

tenant('vf-d2dev-ca-lab', 'd2dev') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-d2dev-ca-lab', dag_deploy_auth('d2dev'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2dev-ca-lab', dag_deploy_auth('d2dev'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('d2dev'), 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('d2dev'), 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('d2dev'), 'tags/v2.0.0')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('d2dev'))
}

tenant('vf-d2dev-ca-nonlive', 'd2dev') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('d2dev')

    //
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-d2dev-ca-nonlive', dag_auth)
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-d2dev-ca-lab', dag_auth)
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-d2dev-ca-openlab', dag_auth)
    //
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2dev-ca-nonlive', dag_auth)
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2dev-ca-lab', dag_auth)
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2dev-ca-openlab', dag_auth)
    //D2TST
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2tst-ca-lab', dag_deploy_auth('d2tst'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2tst-ca-nonlive', dag_deploy_auth('d2tst'))
    //
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-d2dev-ca-nonlive', img_promote_auth('d2dev'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-d2dev-ca-lab', img_promote_auth('d2dev'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-d2dev-ca-openlab', img_promote_auth('d2dev'))
    //
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-d2dev-ca', img_promote_auth('d2dev'))
    //
    run_org_folder(FOLDER + '/VFGroup-DigitalTwin', standard_org_folder_auth('d2dev') + standard_tenant_auth('d2tst'))
    run_org_folder(FOLDER + '/vfie-bigdata', standard_org_folder_auth('d2dev'))
}

tenant('vf-d2tst-etl-nonlive', 'd2tst') {
    FOLDER ->
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2tst-etl-nonlive', dag_deploy_auth('d2tst'))
    //Bif deply pipelines for D2tst
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-d2tst-etl-nonlive', dag_deploy_auth('d2tst'), 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-d2tst-etl-nonlive', dag_deploy_auth('d2tst'), 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-d2tst-etl-nonlive', standard_tenant_auth('d2tst'), 'tags/v2.0.0')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test-vf-d2tst-etl-nonlive', dag_deploy_auth('d2tst'))
}

tenant('vf-d2tst-etl-live', 'd2tst') {
    FOLDER ->
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-d2tst-etl-live', dag_deploy_auth('d2tst'))
    //Bif deply pipelines for D2tst
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-d2tst-etl-live', dag_deploy_auth('d2tst'), 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-d2tst-etl-live', dag_deploy_auth('d2tst'), 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-d2tst-etl-live', standard_tenant_auth('d2tst'), 'tags/v2.0.0')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test-vf-d2tst-etl-live', dag_deploy_auth('d2tst'))
}

tenant('vf-gned-cias-alpha', 'grp-cias') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('grp-cias')
    //Bif deploy pipelines for CIAS alpha
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-gned-cias-alpha', dag_auth, 'develop')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-gned-cias-alpha', dag_auth , 'develop')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-gned-cias-alpha', standard_tenant_auth('grp-cias'), 'develop')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test-vf-gned-cias-alpha', dag_auth)
    //
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-gned-cias-alpha', dag_auth)
    //
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-gned-cias-alpha', dag_auth)
    //
    run_org_folder(FOLDER + '/VFGroup-Engineering-CIAS', standard_org_folder_auth('grp-cias') + standard_tenant_auth('grp-cias-cf'))

    def repo_specifier_regex = '.*(neuron-bif-cfg-cias).*'
    run_org_folder(FOLDER + '/VFGroup-CloudAnalytics', standard_org_folder_auth('grp-cias') + standard_tenant_auth('grp-cias-cf'),
    repo_specifier_regex
    )
}

tenant('vf-gned-cias-tst', 'grp-cias') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('grp-cias')
    //Bif deploy pipelines for CIAS beta
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-gned-cias-tst', dag_auth, 'develop')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-gned-cias-tst', dag_auth , 'develop')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-gned-cias-tst', standard_tenant_auth('grp-cias'), 'develop')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test-vf-gned-cias-tst', dag_auth)
    //
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-gned-cias-tst', dag_auth)
    //
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-gned-cias-tst', dag_auth)
    //
    run_org_folder(FOLDER + '/VFGroup-Engineering-CIAS', standard_org_folder_auth('grp-cias') + standard_tenant_auth('grp-cias-cf'))
}

tenant('vf-devie-ca-live', 'devie') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-devie-ca-live',  dag_deploy_auth('devie'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-devie-ca-live', dag_deploy_auth('devie'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-devie-ca-live', img_promote_auth('devie'))
}

tenant('vf-devie-ca-nonlive', 'devie') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('devie')
    //
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-devie-ca-nonlive', dag_auth)
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-devie-ca-lab', dag_auth)
    //
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-devie-ca-nonlive', dag_auth)
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-devie-ca-lab', dag_auth)
    //
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-devie-ca-nonlive', img_promote_auth('devie'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-devie-ca-lab', img_promote_auth('devie'))

    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-devie-ca', img_promote_auth('devie'))

    run_org_folder(FOLDER + '/vfie-bigdata', standard_org_folder_auth('devie'))
}

tenant('vf-mc2dev-ca-live', 'mc2dev') {
    FOLDER ->
    live_app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-mc2dev-ca-live',  dag_deploy_auth('mc2dev'))
    live_dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-mc2dev-ca-live', dag_deploy_auth('mc2dev'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-mc2dev-ca-live', img_promote_auth('mc2dev'))
}

tenant('vf-mc2dev-ca-nonlive', 'mc2dev') {
    FOLDER ->
    //
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-mc2dev-ca-nonlive', dag_deploy_auth('mc2dev'))
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-mc2dev-ca-lab', dag_deploy_auth('mc2dev'))
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-mc2dev-ca-openlab', dag_deploy_auth('mc2dev'))
    //
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-mc2dev-ca-lab', dag_deploy_auth('mc2dev'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-mc2dev-ca-nonlive', dag_deploy_auth('mc2dev'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-mc2dev-ca-openlab', dag_deploy_auth('mc2dev'))
    //
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-mc2dev-ca', img_promote_auth('mc2dev'))
    //
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-mc2dev-ca-nonlive', img_promote_auth('mc2dev'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-mc2dev-ca-lab', img_promote_auth('mc2dev'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-mc2dev-ca-openlab', img_promote_auth('mc2dev'))
}

tenant('vf-eng-ca-live', 'grp') {
    FOLDER ->
    //
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('grp'), 'develop')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('grp'), 'develop')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp'), 'develop')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('grp'), 'develop')
    drs_deploy_policies_pipeline_versioned(FOLDER + '/neuron-drs-deploy-policies', standard_tenant_auth('grp'))
    drs_deploy_functions_pipeline_versioned(FOLDER + '/neuron-drs-deploy-functions', standard_tenant_auth('grp'))
    drs_test_pipeline_versioned(FOLDER + '/neuron-drs-test', standard_tenant_auth('grp'))
    drs_ops_trash_pipeline_versioned(FOLDER + '/neuron-ops-trash', standard_tenant_auth('grp'))
    drs_ops_prepare_trash_pipeline_versioned(FOLDER + '/neuron-ops-prepare-trash', standard_tenant_auth('grp'))
}

tenant('vf-eng-ca-nonlive', 'grp') {
    FOLDER ->
    //
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('grp'), 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('grp'), 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp'), 'tags/v2.0.0')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('grp'), 'tags/v2.0.0')
}

tenant('vf-eng-ca-lab', 'grp') {
    FOLDER ->
    //
    drs_deploy_policies_pipeline_versioned(FOLDER + '/neuron-drs-deploy-policies', standard_tenant_auth('grp'), 'tags/v3.0.0')
    drs_deploy_functions_pipeline_versioned(FOLDER + '/neuron-drs-deploy-functions', standard_tenant_auth('grp'), 'tags/v3.0.0')
    drs_test_pipeline_versioned(FOLDER + '/neuron-drs-test', standard_tenant_auth('grp'), 'tags/v3.0.0')
    drs_ops_trash_pipeline_versioned(FOLDER + '/neuron-ops-trash', standard_tenant_auth('grp'), 'tags/v3.0.0')
    drs_ops_prepare_trash_pipeline_versioned(FOLDER + '/neuron-ops-prepare-trash', standard_tenant_auth('grp'), 'tags/v3.0.0')
}

tenant('vf-grp-lm3-beta-datahub-mgmt', 'grp') {
    FOLDER ->
    //
    drs_deploy_policies_pipeline_versioned(FOLDER + '/neuron-drs-deploy-policies', standard_tenant_auth('grp'), 'tags/v3.0.0')
    drs_deploy_functions_pipeline_versioned(FOLDER + '/neuron-drs-deploy-functions', standard_tenant_auth('grp'), 'tags/v3.0.0')
    drs_test_pipeline_versioned(FOLDER + '/neuron-drs-test', standard_tenant_auth('grp'), 'tags/v3.0.0')
    drs_ops_trash_pipeline_versioned(FOLDER + '/neuron-ops-trash', standard_tenant_auth('grp'), 'tags/v3.0.0')
    drs_ops_prepare_trash_pipeline_versioned(FOLDER + '/neuron-ops-prepare-trash', standard_tenant_auth('grp'), 'tags/v3.0.0')
}

tenant('vf-lm1-ca-live', 'grp') {
    FOLDER ->
    //
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('grp'), 'develop')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('grp'), 'develop')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp'), 'develop')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('grp'), 'develop')
}

tenant('vf-lm1-ca-nonlive', 'grp') {
    FOLDER ->
    //
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('grp'), 'develop')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('grp'), 'develop')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp'), 'develop')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('grp'), 'develop')
}

tenant('vf-lm2-ca-live', 'grp') {
    FOLDER ->
    //
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('grp'), 'develop')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('grp'), 'develop')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp'), 'develop')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('grp'), 'develop')
}

tenant('vf-lm2-ca-nonlive', 'grp') {
    FOLDER ->
    //
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('grp'), 'develop')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('grp'), 'develop')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp'), 'develop')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('grp'), 'develop')
}

tenant('vf-lm3-ca-live', 'grp') {
    FOLDER ->
    //
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('grp'), 'develop')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('grp'), 'develop')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp'), 'develop')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('grp'), 'develop')
    drs_deploy_policies_pipeline_versioned(FOLDER + '/neuron-drs-deploy-policies', standard_tenant_auth('grp'), 'develop')
    drs_deploy_functions_pipeline_versioned(FOLDER + '/neuron-drs-deploy-functions', standard_tenant_auth('grp'), 'develop')
    drs_test_pipeline_versioned(FOLDER + '/neuron-drs-test', standard_tenant_auth('grp'), 'develop')
}

tenant('vf-lm3-ca-nonlive', 'grp') {
    FOLDER ->
    //
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('grp'), 'develop')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('grp'), 'develop')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp'), 'develop')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('grp'), 'develop')
}

tenant('vf-lm4-ca-live', 'grp') {
    FOLDER ->
    //
    drs_deploy_policies_pipeline_versioned(FOLDER + '/neuron-drs-deploy-policies', standard_tenant_auth('grp'))
    drs_deploy_functions_pipeline_versioned(FOLDER + '/neuron-drs-deploy-functions', standard_tenant_auth('grp'))
    drs_test_pipeline_versioned(FOLDER + '/neuron-drs-test', standard_tenant_auth('grp'))
    drs_ops_trash_pipeline_versioned(FOLDER + '/neuron-ops-trash', standard_tenant_auth('grp'))
    drs_ops_prepare_trash_pipeline_versioned(FOLDER + '/neuron-ops-prepare-trash', standard_tenant_auth('grp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('grp'), 'develop')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('grp'), 'develop')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp'), 'develop')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('grp'), 'develop')
}

tenant('vf-lm4-ca-nonlive', 'grp') {
    FOLDER ->
    //
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('grp'), 'develop')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('grp'), 'develop')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp'), 'develop')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('grp'), 'develop')
}

tenant('vf-uk-vbuk-live', 'grp') {
    FOLDER ->
    //
    drs_deploy_policies_pipeline_versioned(FOLDER + '/neuron-drs-deploy-policies', standard_tenant_auth('grp'), 'tags/v2.0.0')
    drs_deploy_functions_pipeline_versioned(FOLDER + '/neuron-drs-deploy-functions', standard_tenant_auth('grp'), 'tags/v2.0.0')
    drs_ops_trash_pipeline_versioned(FOLDER + '/neuron-ops-trash', standard_tenant_auth('grp'), 'tags/v2.0.0')
    drs_ops_prepare_trash_pipeline_versioned(FOLDER + '/neuron-ops-prepare-trash', standard_tenant_auth('grp'), 'tags/v2.0.0')
}

tenant('vf-cis-dynamo', 'grp-dynamo') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-cis-dynamo.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('grp-dynamo'),
    repo_specifier_regex
    )
}

tenant('vf-tst-nwp-live', 'tst-nwp') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-tst-nwp-live', img_promote_auth('tst-nwp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('tst-nwp'), 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('tst-nwp'), 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('tst-nwp'), 'tags/v2.0.0')
}

tenant('vf-sit-nwp-nonlive', 'sit-nwp') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-sit-nwp-nonlive', img_promote_auth('sit-nwp'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-sit-nwp', img_promote_short_auth('sit-nwp'))
}

tenant('vf-sit-nwp-live', 'sit-nwp') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-sit-nwp-live', img_promote_auth('sit-nwp'))
    run_org_folder(FOLDER + '/vfgroup-gned-nwplanning', standard_org_folder_auth('sit-nwp'))
}

tenant('vf-dev-nwp-live', 'dev-nwp') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-dev-nwp-live', img_promote_auth('dev-nwp'))
    run_org_folder(FOLDER + '/vfgroup-gned-nwplanning', standard_org_folder_auth('dev-nwp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-dev-nwp-live', dag_deploy_auth('dev-nwp'), 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-dev-nwp-live', dag_deploy_auth('dev-nwpp'), 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-dev-nwp-live', standard_tenant_auth('dev-nwp'), 'tags/v2.0.0')
}

tenant('vf-dev-nwp-nonlive', 'dev-nwp') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-dev-nwp-nonlive', img_promote_auth('dev-nwp'))
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-dev-nwp', img_promote_short_auth('dev-nwp'))
}

tenant('vf-lm1-nucleus', 'cis-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-lm1-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('cis-ngbi'),
    repo_specifier_regex
    )
}

tenant('vf-scmuat-ca-nonlive', 'scmuat') {
    FOLDER ->
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('scmuat'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('scmuat'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('scmuat'))
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('scmuat'))
    run_org_folder(FOLDER + '/VFGroup-Analytics-CIP', standard_org_folder_auth('scmuat'))
}

tenant('vf-scmdev-ca-live', 'scmuat') {
    FOLDER ->
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('scmuat'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('scmuat'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('scmuat'))
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('scmuat'))
    run_org_folder(FOLDER + '/VFGroup-Analytics-CIP', standard_org_folder_auth('scmuat'))
}

tenant('vf-cis-cms-dataengineering', 'cis-cms-dataengineer') {
    FOLDER ->
    def repo_specifier_regex = '.*(vf-cis-cms-df-.*|vf-cis-dynamo-dp-pg-.*|vf-cis-dynamo-dp-ppl-.*|vf-cis-dynamo-dp-tool-.*|vf-cis-dynamo-dp-lib-.*|vf-cis-dynamo-dp-dag-.*).*'
    def branch_specifier_regex = '.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    standard_org_folder_auth('cis-cms-dataengineer'),
    repo_specifier_regex,
    branch_specifier_regex
                                                   )
}

tenant('vf-lm2-nucleus', 'cis-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-lm2-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('cis-ngbi'),
    repo_specifier_regex
    )
}

tenant('vf-lm4-nucleus', 'cis-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-lm4-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('cis-ngbi'),
    repo_specifier_regex
    )
}

tenant('vf-uk-nucleus', 'uk-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-uk-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('uk-ngbi'),
    repo_specifier_regex
    )
}

tenant('vf-pt-nucleus', 'pt-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-pt-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('pt-ngbi'),
    repo_specifier_regex
    )
}

tenant('vf-pt-ngbi-dev-gen-03', 'pt-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-pt-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('pt-ngbi'),
    repo_specifier_regex
    )
}

tenant('vf-pt-ngbi-tst-gen-04', 'pt-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-pt-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('pt-ngbi'),
    repo_specifier_regex
    )
}

tenant('vf-cis-ngbi-dev-gen-uka', 'cis-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-uk-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('cis-ngbi'),
    repo_specifier_regex
    )
}

tenant('vf-cis-ngbi-dev-gen-ukb', 'cis-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-uk-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('cis-ngbi'),
    repo_specifier_regex
    )
}

tenant('vf-cis-ngbi-tst-gen-ukb', 'cis-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-uk-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('cis-ngbi'),
    repo_specifier_regex
    )
}

tenant('vf-cis-ngbi-pprd-gen-ukb', 'cis-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-uk-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('cis-ngbi'),
    repo_specifier_regex
    )
}

tenant('vf-cis-ngbi-prd-gen-ukb', 'cis-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-uk-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('cis-ngbi'),
    repo_specifier_regex
    )
}

tenant('vf-cis-ngbi-dev-gen-czb', 'cis-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-cz-ngbi-app-cfg.*'
    def branch_specifier_regex_template = '.*(master|feature).*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
     build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
     + tenant_read_job_auth('cis-ngbi'),
    repo_specifier_regex,
    branch_specifier_regex_template
    )
}

group_folder('VFGroup') {
    FOLDER ->
    def exclusions_list = ['vf-cis-dynamo-ci-jobs', 'vf-lm.*-ngbi-app-cfg', 'vf-uk-ngbi-app-cfg', 'vf-cz-ngbi-app-cfg', 'vf-pt-ngbi-app-cfg', 'infinity|kubeflow', 'neuron-gcp-platform', 'neuron-gcp-project-configs', 'bda-nifi-gcp-config', 'vf-cis-neds', 'vf-cis-cms-df.*', 'vf-cis-dynamo-dp-pg-.*', 'vf-cis-dynamo-dp-ppl-.*', 'vf-cis-dynamo-dp-tool-.*', 'vf-cis-dynamo-dp-lib-.*', 'vf-cis-dynamo-dp-dag-.*']
    def exclusions = exclusions_list.join('$)(?!')
    def exclude_branch_specifier_regex = "^(?!${exclusions}).*\$ "

    run_org_folder(FOLDER + '/VFGroup-CloudAnalytics',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('de')
    + tenant_read_job_auth('es')
    + tenant_read_job_auth('hu')
    + tenant_read_job_auth('it')
    + tenant_read_job_auth('pt')
    + tenant_read_job_auth('uk')
    + tenant_read_job_auth('cz')
    + tenant_read_job_auth('grp-constellation'),
    exclude_branch_specifier_regex
    )
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    [
    //Credentials Job                     Run    View     Scm
    // C D M U V  B C C CV C D D M R W,   D R U  C C D R   T
    auth('❌❌❌❌❌ ✅✅✅❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-grp-jenkins-admin'),
    auth('❌❌❌❌❌ ✅✅✅❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-grp-jenkins-user'),
    auth('❌❌❌❌❌ ✅✅❌❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-pt-ngbi-etl-jenkins-admin'),
    ] + standard_tenant_auth('hu-ngbi'),
    exclude_branch_specifier_regex
    )

    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-ebu-lab', standard_tenant_auth('de'))

    // Alpha and Beta IBP Build and Promote Pipelines
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build', img_promote_auth('grp'), 'develop')
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-eng-ca-live', img_promote_auth('grp'), 'generic-image-promoter.groovy', 'develop')
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-lm1-ca-live', img_promote_auth('grp'), 'generic-image-promoter.groovy', 'develop')
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-lm4-ca-live', img_promote_auth('grp'), 'generic-image-promoter-de.groovy', 'develop')
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-lm3-ca-nonlive', img_promote_auth('grp'), 'generic-image-promoter.groovy', 'develop')
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-lm3-ca-live', img_promote_auth('grp'), 'generic-image-promoter.groovy', 'tags/v2.2')

    // Alpha and Beta App & Dag Deploy Pipelines
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-eng-ca-live', standard_tenant_auth('grp'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-eng-ca-live', standard_tenant_auth('grp'))
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-lm1-ca-live', standard_tenant_auth('grp'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-lm1-ca-live', standard_tenant_auth('grp'))
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-lm4-ca-live', standard_tenant_auth('grp'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-lm4-ca-live', standard_tenant_auth('grp'))

    // Alpha and Beta RedAgent Deploy Pipelines
    ra_prepare_deploy_packages(FOLDER + '/neuron-ra-prepare-deploy-package',  standard_tenant_auth('grp'))

    ndgcsync_sync_pipeline('VFGroup/NDGCSync for BIF-Test', ['admin', 'user'].collect { auth('❌❌❌❌❌ ✅✅✅❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-grp-jenkins-' + it) }, [market_name:'it-puz'])

    // BIF Test OLD Pipelines - Beta - To be removed once new ones are validated
    // bif_test_framework('VFGroup/bif-test-framework_LM3', 'https://github.vodafone.com/sohinee-saha/neuron-bif-cfg.git')
    // bif_test_framework('VFGroup/bif-test-framework_LM4', 'https://github.vodafone.com/Vijay-kumar65/neuron-bif-cfg.git', '2.26.0')
    // bif_test_framework('VFGroup/bif-test-framework_LM5', 'https://github.vodafone.com/Chetan-Badgujar/neuron-bif-cfg.git')
    // bif_test_framework('VFGroup/bif-test-framework_alpha', 'https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-bif-cfg')
    // bif_test_framework('VFGroup/bif-test-framework_beta', 'https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-bif-cfg')

    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-dev-eds-nonlive', dag_deploy_auth('dev-eds'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-dev-eds-nonlive', dag_deploy_auth('dev-eds'))

    //Composer deployer
    dp_composer_deployer_pipeline('VFGroup/neuron-dp-composer-deployer-gr',  standard_tenant_auth('gr'))

    //RA prepare deploy package
    ra_prepare_deploy_packages('VFGroup/neuron-ra-prepare-deploy-package-gr',  standard_tenant_auth('gr'))

    // SMEF - Prepare DPO packages Pipeline
    dp_composer_deployer_pipeline(FOLDER + '/neuron-dp-composer-deployer', img_promote_auth('grp'))

    // RedAgent - Prepare RedAgent packages Pipeline
    ra_prepare_deploy_packages(FOLDER + '/neuron-ra-prepare-deploy-package', standard_tenant_auth('grp'))

    // App & Dag Deploy Pipelines - Alpha NonLive
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-eng-ca-nonlive', standard_tenant_auth('grp'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-eng-ca-nonlive', standard_tenant_auth('grp'))

    // BIF Deploy & Test NEW Pipelines - Alpha and Beta
    ['eng', 'lm1', 'lm2', 'lm3', 'lm4', 'lm5'].each { prj ->
        ['nonlive', 'live'].each { env ->
            bif_deploy_pipeline_versioned(FOLDER + "/neuron-bif-deploy-vf-$prj-ca-$env", standard_tenant_auth('grp'), 'tags/v2.0.0')
            bif_deploy_orchestrator_pipeline_versioned(FOLDER + "/neuron-bif-deploy-orchestrator-vf-$prj-ca-$env", standard_tenant_auth('grp'), 'tags/v2.0.0')
            bif_deploy_feeds_pipeline_versioned(FOLDER + "/neuron-bif-deploy-feeds-vf-$prj-ca-$env", standard_tenant_auth('grp'), 'tags/v2.0.0')
            bif_test_pipeline_versioned(FOLDER + "/neuron-bif-test-vf-$prj-ca-$env", standard_tenant_auth('grp'))
        }
    }
}

tenant('vf-infdev-ca-live', 'infdev') {
    FOLDER ->
}

tenant('vf-infdev-ca-nonlive', 'infdev') {
    FOLDER ->
    def repo_specifier_regex = '.*(infinity|kubeflow).*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('infdev'),
    repo_specifier_regex
    )
}

// This is a temporary fix to get the operations team going
// We have to split by individual project
tenant('vf-pt-nucleus', 'pt-ngbi') {
    FOLDER ->
    def repo_specifier_regex = '.*vf-pt-ngbi-app-cfg.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('pt-ngbi'),
    repo_specifier_regex
    )
}

tenant('vf-grp-dts-dev-eds', 'vrs-dts') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('vrs-dts')
    def repo_specifier_regex = '.*DTS-EDS.*'
    run_org_folder(FOLDER + '/VFGroup-VRS-DTS',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('vrs-dts'),
    repo_specifier_regex
    )
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-dts-dev-eds', dag_auth)
}

tenant('vf-dev-puz-lab', 'puzdev') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('puzdev')
    def repo_specifier_regex = '.*(puzzle-bif-cfg-de|de-puzzle-reconciliation).*'
    run_org_folder(FOLDER + '/VFGroup-MA-Puzzle',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('puzdev'),
    repo_specifier_regex
    )
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-dev-puz-lab', dag_deploy_auth('puzdev'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-dev-puz-lab', dag_auth)
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-dev-puz', img_promote_auth('puzdev'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-dev-puz-lab', img_promote_auth('puzdev'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('puzdev'))
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('puzdev'))
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('puzdev'))
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('puzdev'))
}

tenant('vf-grp-neds-alpha-trusted', 'grp-neds') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('grp-neds')
    def repo_specifier_regex = '.*vf-cis-neds.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-neds-jenkins-admin', 'gcp-vf-grp-neds-jenkins-user'])
    + tenant_read_job_auth('grp-neds'),
    repo_specifier_regex
    )
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-grp-neds-alpha-trusted', dag_deploy_auth('grp-neds'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-neds-alpha-trusted', dag_auth)
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-grp-neds-alpha-trusted', img_promote_auth('grp-neds'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-neds-alpha-trusted', img_promote_auth('grp-neds'))
}

tenant('vf-grp-neds-beta-trusted', 'grp-neds') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('grp-neds')
    def repo_specifier_regex = '.*vf-cis-neds.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-neds-jenkins-admin', 'gcp-vf-grp-neds-jenkins-user'])
    + tenant_read_job_auth('grp-neds'),
    repo_specifier_regex
    )
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-grp-neds-beta-trusted', dag_deploy_auth('grp-neds'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-neds-beta-trusted', dag_auth)
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-vf-grp-neds-beta-trusted', img_promote_auth('grp-neds'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-neds-beta-trusted', img_promote_auth('grp-neds'))
}

tenant('vf-grp-neds-alpha-untrusted', 'grp-neds') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('grp-neds')
    def repo_specifier_regex = '.*vf-cis-neds.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-neds-jenkins-admin', 'gcp-vf-grp-neds-jenkins-user'])
    + tenant_read_job_auth('grp-neds'),
    repo_specifier_regex
    )
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-grp-neds-alpha-untrusted', dag_deploy_auth('grp-neds'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-neds-alpha-untrusted', dag_auth)
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-grp-neds-alpha-untrusted', img_promote_auth('grp-neds'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-neds-alpha-untrusted', img_promote_auth('grp-neds'))
}

tenant('vf-grp-neds-beta-untrusted', 'grp-neds') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('grp-neds')
    def repo_specifier_regex = '.*vf-cis-neds.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    build_read_job__read_view(['gcp-vf-grp-neds-jenkins-admin', 'gcp-vf-grp-neds-jenkins-user'])
    + tenant_read_job_auth('grp-neds'),
    repo_specifier_regex
    )
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-grp-neds-beta-untrusted', dag_deploy_auth('grp-neds'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-neds-beta-untrusted', dag_auth)
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-grp-neds-beta-untrusted', img_promote_auth('grp-neds'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-neds-beta-untrusted', img_promote_auth('grp-neds'))
}

tenant('vf-devuk-vbuk-nonlive', 'devuk-vbuk') {
    FOLDER ->
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-devuk-vbuk', img_promote_short_auth('devuk-vbuk'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-devuk-vbuk-nonlive', img_promote_auth('devuk-vbuk'))
}

tenant('vf-devuk-vbuk-live', 'devuk-vbuk') {
    FOLDER ->
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-devuk-vbuk-live', img_promote_auth('devuk-vbuk'))
    run_org_folder(FOLDER + '/VFGroup-Olympus', standard_org_folder_auth('devuk-vbuk'))
}

tenant('vf-grp-vrsbi-alpha', 'vrsbidev') {
    FOLDER ->
    def dag_auth = dag_deploy_auth('vrsbidev')
    def repo_specifier_regex = '.*vrs-cfg-bi.*'
    run_org_folder(FOLDER + '/VFGroup-VRS-DTS',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('vrsbidev'),
    repo_specifier_regex
    )
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-grp-vrsbi-alpha', dag_deploy_auth('vrsbidev'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-grp-vrsbi-alpha', dag_auth)
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build-dev-vrsbi', img_promote_auth('vrsbidev'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-grp-vrsbi-alpha', img_promote_auth('vrsbidev'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator-vf-grp-vrsbi-alpha', dag_deploy_auth('vrsbidev'), 'develop')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds-vf-grp-vrsbi-alpha', dag_deploy_auth('vrsbidev'), 'develop')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy-vf-grp-vrsbi-alpha', standard_tenant_auth('vrsbidev'), 'develop')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test-vf-grp-vrsbi-alpha', dag_deploy_auth('vrsbidev'), 'develop')
}

tenant('vf-uk-ngbi-dev-ml-b', 'uk-ngbi-ml-dev') {
    FOLDER ->
    def repo_specifier_regex = '.*(ml_device_recommendation|ml_prototype|pl_dataproc|fs_subscriber_device|fs_billing|fs_usage|ml_pathway|fs_subscriber_base|pl_common_utils).*'
    def branch_specifier_regex = 'develop'
    run_org_folder(FOLDER + '/VFUK-BD',
    standard_org_folder_auth('uk-ngbi-ml-dev'),
    repo_specifier_regex,
    branch_specifier_regex
    )
    def repo_specifier_regex_template = '.*vf-uk-ngbi-ml-aa.*'
    def branch_specifier_regex_template = '.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    standard_org_folder_auth('uk-ngbi-ml-dev'),
    repo_specifier_regex_template,
    branch_specifier_regex_template
    )
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-vf-uk-ngbi-dev-ml-b',     img_promote_auth('uk-ngbi-ml-dev'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-uk-ngbi-dev-ml-b',  img_promote_auth('uk-ngbi-ml-dev'), 'generic-image-promoter-de.groovy')
    app_deploy_pipeline_ml(FOLDER + '/neuron-app-deploy-vf-uk-ngbi-dev-ml-b', dag_deploy_auth('uk-ngbi-ml-dev'))
}

tenant('vf-uk-ngbi-tst-ml-b', 'uk-ngbi-ml-tst') {
    FOLDER ->
    def repo_specifier_regex = '.*(ml_device_recommendation|ml_prototype|pl_dataproc|fs_subscriber_device|fs_billing|fs_usage|ml_pathway|fs_subscriber_base|pl_common_utils).*'
    def branch_specifier_regex = 'release.*'
    run_org_folder(FOLDER + '/VFUK-BD',
    standard_org_folder_auth('uk-ngbi-ml-tst'),
    repo_specifier_regex,
    branch_specifier_regex
    )
    def repo_specifier_regex_template = '.*vf-uk-ngbi-ml-aa.*'
    def branch_specifier_regex_template = 'release.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    standard_org_folder_auth('uk-ngbi-ml-tst'),
    repo_specifier_regex_template,
    branch_specifier_regex_template
    )
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-vf-uk-ngbi-tst-ml-b',     img_promote_auth('uk-ngbi-ml-tst'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-uk-ngbi-tst-ml-b',  img_promote_auth('uk-ngbi-ml-tst'), 'generic-image-promoter-de.groovy')
    app_deploy_pipeline_ml(FOLDER + '/neuron-app-deploy-vf-uk-ngbi-tst-ml-b', dag_deploy_auth('uk-ngbi-ml-tst'))
}

tenant('vf-uk-ngbi-pprd-ml-b', 'uk-ngbi-ml-pprd') {
    FOLDER ->
    def repo_specifier_regex = '.*(ml_device_recommendation|ml_prototype|pl_dataproc|fs_subscriber_device|fs_billing|fs_usage|ml_pathway|fs_subscriber_base|pl_common_utils).*'
    def branch_specifier_regex = 'release.*'
    run_org_folder(FOLDER + '/VFUK-BD',
    standard_org_folder_auth('uk-ngbi-ml-pprd'),
    repo_specifier_regex,
    branch_specifier_regex
    )
    def repo_specifier_regex_template = '.*vf-uk-ngbi-ml-aa.*'
    def branch_specifier_regex_template = 'release.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    standard_org_folder_auth('uk-ngbi-ml-pprd'),
    repo_specifier_regex_template,
    branch_specifier_regex_template
                                                                   )
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-vf-uk-ngbi-pprd-ml-b',     img_promote_auth('uk-ngbi-ml-pprd'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-uk-ngbi-pprd-ml-b',  img_promote_auth('uk-ngbi-ml-pprd'), 'generic-image-promoter-de.groovy')
    app_deploy_pipeline_ml(FOLDER + '/neuron-app-deploy-vf-uk-ngbi-pprd-ml-b', dag_deploy_auth('uk-ngbi-ml-pprd'))
}

tenant('vf-uk-ngbi-prd-ml-b', 'uk-ngbi-ml-prd') {
    FOLDER ->
    def repo_specifier_regex = '.*(ml_device_recommendation|ml_prototype|pl_dataproc|fs_subscriber_device|fs_billing|fs_usage|ml_pathway|fs_subscriber_base|pl_common_utils).*'
    def branch_specifier_regex = 'main'
    run_org_folder(FOLDER + '/VFUK-BD',
    standard_org_folder_auth('uk-ngbi-ml-prd'),
    repo_specifier_regex,
    branch_specifier_regex
    )
    def repo_specifier_regex_template = '.*vf-uk-ngbi-ml-aa.*'
    def branch_specifier_regex_template = 'master'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    standard_org_folder_auth('uk-ngbi-ml-prd'),
    repo_specifier_regex_template,
    branch_specifier_regex_template
    )
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-vf-uk-ngbi-prd-ml-b',     img_promote_auth('uk-ngbi-ml-prd'))
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-uk-ngbi-prd-ml-b',  img_promote_auth('uk-ngbi-ml-prd'), 'generic-image-promoter-de.groovy')
    app_deploy_pipeline_ml(FOLDER + '/neuron-app-deploy-vf-uk-ngbi-prd-ml-b', dag_deploy_auth('uk-ngbi-ml-prd'))
}

tenant('vf-uk-ngbi-dev-shrd-b', 'uk-ngbi-ml-dev') {
    FOLDER ->
    def repo_specifier_regex = '.*(ml_device_recommendation|ml_prototype|pl_dataproc|fs_subscriber_device|fs_billing|fs_usage|ml_pathway|fs_subscriber_base|pl_common_utils).*'
    def branch_specifier_regex = 'develop'
    run_org_folder(FOLDER + '/VFUK-BD',
    standard_org_folder_auth('uk-ngbi-ml-dev'),
    repo_specifier_regex,
    branch_specifier_regex
    )
    def repo_specifier_regex_template = '.*vf-uk-ngbi-ml-aa.*'
    def branch_specifier_regex_template = '.*(develop|feature).*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    standard_org_folder_auth('uk-ngbi-ml-dev'),
    repo_specifier_regex_template,
    branch_specifier_regex_template
    )
    dag_deploy_pipeline_shrd_composer(FOLDER + '/neuron-dag-deploy-vf-uk-ngbi-dev-shrd-b', dag_deploy_auth('uk-ngbi-ml-dev'))
}

tenant('vf-uk-ngbi-tst-shrd-b', 'uk-ngbi-ml-tst') {
    FOLDER ->
    def repo_specifier_regex = '.*(ml_device_recommendation|ml_prototype|pl_dataproc|fs_subscriber_device|fs_billing|fs_usage|ml_pathway|fs_subscriber_base|pl_common_utils).*'
    def branch_specifier_regex = 'release.*'
    run_org_folder(FOLDER + '/VFUK-BD',
    standard_org_folder_auth('uk-ngbi-ml-tst'),
    repo_specifier_regex,
    branch_specifier_regex
                )
    def repo_specifier_regex_template = '.*vf-uk-ngbi-ml-aa.*'
    def branch_specifier_regex_template = 'release.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    standard_org_folder_auth('uk-ngbi-ml-tst'),
    repo_specifier_regex_template,
    branch_specifier_regex_template
                )
    dag_deploy_pipeline_shrd_composer(FOLDER + '/neuron-dag-deploy-vf-uk-ngbi-tst-shrd-b', dag_deploy_auth('uk-ngbi-ml-tst'))
}

tenant('vf-uk-ngbi-pprd-shrd-b', 'uk-ngbi-ml-pprd') {
    FOLDER ->
    def repo_specifier_regex = '.*(ml_device_recommendation|ml_prototype|pl_dataproc|fs_subscriber_device|fs_billing|fs_usage|ml_pathway|fs_subscriber_base|pl_common_utils).*'
    def branch_specifier_regex = 'release.*'
    run_org_folder(FOLDER + '/VFUK-BD',
    standard_org_folder_auth('uk-ngbi-ml-pprd'),
    repo_specifier_regex,
    branch_specifier_regex
    )
    def repo_specifier_regex_template = '.*vf-uk-ngbi-ml-aa.*'
    def branch_specifier_regex_template = 'release.*'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    standard_org_folder_auth('uk-ngbi-ml-pprd'),
    repo_specifier_regex_template,
    branch_specifier_regex_template
    )
    dag_deploy_pipeline_shrd_composer(FOLDER + '/neuron-dag-deploy-vf-uk-ngbi-pprd-shrd-b', dag_deploy_auth('uk-ngbi-ml-pprd'))
}

tenant('vf-uk-ngbi-prd-shrd-b', 'uk-ngbi-ml-prd') {
    FOLDER ->
    def repo_specifier_regex = '.*(ml_device_recommendation|ml_prototype|pl_dataproc|fs_subscriber_device|fs_billing|fs_usage|ml_pathway|fs_subscriber_base|pl_common_utils).*'
    def branch_specifier_regex = 'main'
    run_org_folder(FOLDER + '/VFUK-BD',
    standard_org_folder_auth('uk-ngbi-ml-prd'),
    repo_specifier_regex,
    branch_specifier_regex
    )
    def repo_specifier_regex_template = '.*vf-uk-ngbi-ml-aa.*'
    def branch_specifier_regex_template = 'master'
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    standard_org_folder_auth('uk-ngbi-ml-prd'),
    repo_specifier_regex_template,
    branch_specifier_regex_template
    )
    dag_deploy_pipeline_shrd_composer(FOLDER + '/neuron-dag-deploy-vf-uk-ngbi-prd-shrd-b', dag_deploy_auth('uk-ngbi-ml-prd'))
}

tenant('vf-cip-hrapps-dev-live', 'grp-hrapps-dev') {
    FOLDER ->
    def repo_specifier_regex = '.*cip-askhr.*'
    run_org_folder(FOLDER + '/VFGroup-Analytics-CIP',
    build_read_job__read_view(['gcp-vf-grp-hrapps-dev-jenkins-admin', 'gcp-vf-grp-hrapps-dev-jenkins-user'])
    + tenant_read_job_auth('grp-hrapps-dev'),
    repo_specifier_regex
    )
}

tenant('vf-cip-hrapps-tst-live', 'grp-hrapps-tst') {
    FOLDER ->
    def repo_specifier_regex = '.*cip-askhr.*'
    run_org_folder(FOLDER + '/VFGroup-Analytics-CIP',
    build_read_job__read_view(['gcp-vf-grp-hrapps-tst-jenkins-admin', 'gcp-vf-grp-hrapps-tst-jenkins-user'])
    + tenant_read_job_auth('grp-hrapps-tst'),
    repo_specifier_regex
    )
}

tenant('vf-grp-shared-services-lab', 'grp-beta') {
    FOLDER ->
    def repo_specifier_regex = '.*neuron-gcp-vault-ephemeral-keys.*'
    run_org_folder(FOLDER + '/VFGroup-CloudAnalytics',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-beta-jenkins-user'])
    + tenant_read_job_auth('grp-beta'),
    repo_specifier_regex
    )
}
