group_folder('VFGroup') {
    FOLDER ->
    def exclusions_list = ['vf-cis-dynamo-ci-jobs', 'vf-lm.*-ngbi-app-cfg', 'vf-uk-ngbi-app-cfg', 'vf-cz-ngbi-app-cfg', 'vf-pt-ngbi-app-cfg', 'infinity|kubeflow', 'neuron-gcp-platform', 'neuron-gcp-project-configs', 'bda-nifi-gcp-config', 'vf-cis-neds', 'vf-cis-cms-df.*', 'vf-cis-dynamo-dp-pg-.*', 'vf-cis-dynamo-dp-ppl-.*', 'vf-cis-dynamo-dp-tool-.*', 'vf-cis-dynamo-dp-lib-.*', 'vf-cis-dynamo-dp-dag-.*']
    def exclusions = exclusions_list.join('$)(?!')
    def exclude_branch_specifier_regex = "^(?!${exclusions}).*\$ "

    run_org_folder(FOLDER + '/VFGroup-CloudAnalytics',
    build_read_job__read_view(['gcp-vf-grp-jenkins-admin', 'gcp-vf-grp-jenkins-user'])
    + tenant_read_job_auth('de')
    + tenant_read_job_auth('es')
    + tenant_read_job_auth('hu')
    + tenant_read_job_auth('it')
    + tenant_read_job_auth('pt')
    + tenant_read_job_auth('uk')
    + tenant_read_job_auth('cz')
    + tenant_read_job_auth('grp-constellation'),
    exclude_branch_specifier_regex
    )
    run_org_folder(FOLDER + '/VFGroup-NextGenBI',
    [
    //Credentials Job                     Run    View     Scm
    // C D M U V  B C C CV C D D M R W,   D R U  C C D R   T
    auth('❌❌❌❌❌ ✅✅✅❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-grp-jenkins-admin'),
    auth('❌❌❌❌❌ ✅✅✅❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-grp-jenkins-user'),
    auth('❌❌❌❌❌ ✅✅❌❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-pt-ngbi-etl-jenkins-admin'),
    ] + standard_tenant_auth('hu-ngbi'),
    exclude_branch_specifier_regex
    )

    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-de-ebu-lab', standard_tenant_auth('de'))

    // Alpha and Beta IBP Build and Promote Pipelines
    dp_image_build_pipeline_versioned(FOLDER + '/neuron-dataproc-image-build', img_promote_auth('grp'), 'develop')
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-eng-ca-live', img_promote_auth('grp'), 'generic-image-promoter.groovy', 'develop')
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-lm1-ca-live', img_promote_auth('grp'), 'generic-image-promoter.groovy', 'develop')
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-lm4-ca-live', img_promote_auth('grp'), 'generic-image-promoter-de.groovy', 'develop')
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-lm3-ca-nonlive', img_promote_auth('grp'), 'generic-image-promoter.groovy', 'develop')
    dp_image_promote_pipeline_versioned(FOLDER + '/neuron-image-promote-vf-lm3-ca-live', img_promote_auth('grp'), 'generic-image-promoter.groovy', 'tags/v2.2')

    // Alpha and Beta App & Dag Deploy Pipelines
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-eng-ca-live', standard_tenant_auth('grp'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-eng-ca-live', standard_tenant_auth('grp'))
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-lm1-ca-live', standard_tenant_auth('grp'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-lm1-ca-live', standard_tenant_auth('grp'))
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-lm4-ca-live', standard_tenant_auth('grp'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-lm4-ca-live', standard_tenant_auth('grp'))

    // Alpha and Beta RedAgent Deploy Pipelines
    ra_prepare_deploy_packages(FOLDER + '/neuron-ra-prepare-deploy-package',  standard_tenant_auth('grp'))

    ndgcsync_sync_pipeline('VFGroup/NDGCSync for BIF-Test', ['admin', 'user'].collect { auth('❌❌❌❌❌ ✅✅✅❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-grp-jenkins-' + it) }, [market_name:'it-puz'])

    // BIF Test OLD Pipelines - Beta - To be removed once new ones are validated
    // bif_test_framework('VFGroup/bif-test-framework_LM3', 'https://github.vodafone.com/sohinee-saha/neuron-bif-cfg.git')
    // bif_test_framework('VFGroup/bif-test-framework_LM4', 'https://github.vodafone.com/Vijay-kumar65/neuron-bif-cfg.git', '2.26.0')
    // bif_test_framework('VFGroup/bif-test-framework_LM5', 'https://github.vodafone.com/Chetan-Badgujar/neuron-bif-cfg.git')
    // bif_test_framework('VFGroup/bif-test-framework_alpha', 'https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-bif-cfg')
    // bif_test_framework('VFGroup/bif-test-framework_beta', 'https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-bif-cfg')

    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-dev-eds-nonlive', dag_deploy_auth('dev-eds'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-dev-eds-nonlive', dag_deploy_auth('dev-eds'))

    //Composer deployer
    dp_composer_deployer_pipeline('VFGroup/neuron-dp-composer-deployer-gr',  standard_tenant_auth('gr'))

    //RA prepare deploy package
    ra_prepare_deploy_packages('VFGroup/neuron-ra-prepare-deploy-package-gr',  standard_tenant_auth('gr'))

    // SMEF - Prepare DPO packages Pipeline
    dp_composer_deployer_pipeline(FOLDER + '/neuron-dp-composer-deployer', img_promote_auth('grp'))

    // RedAgent - Prepare RedAgent packages Pipeline
    ra_prepare_deploy_packages(FOLDER + '/neuron-ra-prepare-deploy-package', standard_tenant_auth('grp'))

    // App & Dag Deploy Pipelines - Alpha NonLive
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-vf-eng-ca-nonlive', standard_tenant_auth('grp'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-vf-eng-ca-nonlive', standard_tenant_auth('grp'))

    // BIF Deploy & Test NEW Pipelines - Alpha and Beta
    ['eng', 'lm1', 'lm2', 'lm3', 'lm4', 'lm5'].each { prj ->
        ['nonlive', 'live'].each { env ->
            bif_deploy_pipeline_versioned(FOLDER + "/neuron-bif-deploy-vf-$prj-ca-$env", standard_tenant_auth('grp'), 'tags/v2.0.0')
            bif_deploy_orchestrator_pipeline_versioned(FOLDER + "/neuron-bif-deploy-orchestrator-vf-$prj-ca-$env", standard_tenant_auth('grp'), 'tags/v2.0.0')
            bif_deploy_feeds_pipeline_versioned(FOLDER + "/neuron-bif-deploy-feeds-vf-$prj-ca-$env", standard_tenant_auth('grp'), 'tags/v2.0.0')
            bif_test_pipeline_versioned(FOLDER + "/neuron-bif-test-vf-$prj-ca-$env", standard_tenant_auth('grp'))
        }
    }
}

tenant('demo-tenant', 'grp') {
    FOLDER ->
    app_deploy_pipeline(FOLDER + '/neuron-app-deploy-demo-tenant', dag_deploy_auth('grp'))
    dag_deploy_pipeline(FOLDER + '/neuron-dag-deploy-demo-tenant', dag_deploy_auth('grp'))
    bif_deploy_orchestrator_pipeline_versioned(FOLDER + '/neuron-bif-deploy-orchestrator', dag_deploy_auth('grp'), 'tags/v2.0.0')
    bif_deploy_feeds_pipeline_versioned(FOLDER + '/neuron-bif-deploy-feeds', dag_deploy_auth('grp'), 'tags/v2.0.0')
    bif_deploy_pipeline_versioned(FOLDER + '/neuron-bif-deploy', standard_tenant_auth('grp'), 'tags/v2.0.0')
    bif_test_pipeline_versioned(FOLDER + '/neuron-bif-test', dag_deploy_auth('grp'))
}