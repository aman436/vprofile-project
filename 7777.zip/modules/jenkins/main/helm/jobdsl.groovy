// vault credentials reloader

def updateFolderCredentialsScript = '''
    def getFolder(name){
        Jenkins.instance.getAllItems(com.cloudbees.hudson.plugins.folder.Folder.class)
        .findAll{it.name.equals(name)}.getAt(0)
    }
    def getCredentials(folder){
        def creds=folder.properties.findAll{it.class.toString().contains('FolderCredentialsProperty')}.getAt(0)
        def result
        if(!creds){
            result = new com.cloudbees.hudson.plugins.folder.properties.FolderCredentialsProvider$FolderCredentialsProperty()
            folder.addProperty(result)
            Jenkins.instance.save()
        }
        result ?: creds
    }
    def updateCredentials(store, credential, new_username, new_pass, new_description, type='usernamePassword'){
        def new_credential
        if(type=='usernamePassword'){
            new_credential = new com.cloudbees.plugins.credentials.impl.UsernamePasswordCredentialsImpl(credential.scope, credential.id, new_description, new_username, new_pass)
        } else {
            new_credential = new org.jenkinsci.plugins.plaincredentials.impl.StringCredentialsImpl(
                credential.scope, credential.id, new_description,
                hudson.util.Secret.fromString(new_pass))
        }
        store.updateCredentials(
            com.cloudbees.plugins.credentials.domains.Domain.global(),
            credential,
            new_credential
        )
        Jenkins.instance.save()
    }
    def addCredential(store, credential_id, user_name, user_pass, description='', type='usernamePassword'){
        def new_credential
        if(type=='usernamePassword'){
            new_credential = new com.cloudbees.plugins.credentials.impl.UsernamePasswordCredentialsImpl(com.cloudbees.plugins.credentials.CredentialsScope.GLOBAL, credential_id, description, user_name, user_pass)
        } else {
            new_credential = new org.jenkinsci.plugins.plaincredentials.impl.StringCredentialsImpl(
                com.cloudbees.plugins.credentials.CredentialsScope.GLOBAL,
                credential_id,
                description,
                hudson.util.Secret.fromString(user_pass))
        }
        store.addCredentials(com.cloudbees.plugins.credentials.domains.Domain.global(), new_credential)
    }

    def creds = getCredentials(getFolder(params.folderName))
    def credential =  creds.credentials.findAll{it.id == params.secretId}.getAt(0)
    if (credential) {
        updateCredentials(creds.store, credential, params.secretName, params.secretValue.value, params.description, params.type)
    }
    else {
        addCredential(creds.store, params.secretId, params.secretName, params.secretValue.value, params.description, params.type)
    }
'''

pipelineJob('folder-credentials-config') {
        authorization {
        permissions(auth('❌❌❌❌❌ ✅✅✅❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-grp-jenkins-admin'))
        }
    parameters {
        stringParam('folderName', '')
        stringParam('secretId', '')
        // secretValue defined in configure block
        stringParam('secretName', '')
        stringParam('description', '')
        stringParam('type', 'usernamePassword')
    }
    definition {
        cps {
            script updateFolderCredentialsScript
            sandbox(false)
        }
    }
    properties {
        disableConcurrentBuilds()
        buildDiscarder {
            strategy {
                logRotator {
                    artifactDaysToKeepStr '1'
                    artifactNumToKeepStr '30'
                    daysToKeepStr '1'
                    numToKeepStr '30'
                }
            }
        }
    }

    configure { job ->
        def params = job / 'properties'  / 'hudson.model.ParametersDefinitionProperty' / 'parameterDefinitions'
        params << 'hudson.model.PasswordParameterDefinition' {
            name('secretValue')
        }
    }
}

// Grrovy script approval
def approveGroovyScript(theScript) {
    jenkins.model.Jenkins.instance.getExtensionList('org.jenkinsci.plugins.scriptsecurity.scripts.ScriptApproval')[0].get()
    .preapprove(theScript, org.jenkinsci.plugins.scriptsecurity.scripts.languages.GroovyLanguage.get())
}
approveGroovyScript(updateFolderCredentialsScript)

// ===

def run_org_folder(name, org_folder_permissions, repository_specifier_regex='.*', branch_name_specifier_regex='.*')  {
    return organizationFolder(name) {
        description('This contains branch source jobs for GitHub')
        authorization {
            org_folder_permissions.each { permissions(it) }
        }
        organizations {
            github {
                apiUri('https://github.vodafone.com/api/v3')
                credentialsId('gcp-jenkins-ghe-funcuser') // id of secret in configs release
                repoOwner(name?.split('/')?.getAt(-1))
            }
        }
        // See https://issues.jenkins-ci.org/browse/JENKINS-46202
        configure {
            it / 'triggers' / 'com.cloudbees.hudson.plugins.folder.computed.PeriodicFolderTrigger'( plugin:'cloudbees-folder@6.14') {
                spec('* * * * * * *')
                interval('3600000')
            }
            def childTriggers = it / 'properties' / 'jenkins.branch.OrganizationChildTriggersProperty'
            childTriggers / 'templates' / 'com.cloudbees.hudson.plugins.folder.computed.PeriodicFolderTrigger' {
                spec('* * * * * * *')
                interval('3600000')
            }
            def traits = it / 'navigators' / 'org.jenkinsci.plugins.github__branch__source.GitHubSCMNavigator' / 'traits'

            traits << 'org.jenkinsci.plugins.github__branch__source.BranchDiscoveryTrait' {
                strategyId(3) // All branches & PRs
            }
            traits << 'org.jenkinsci.plugins.github__branch__source.OriginPullRequestDiscoveryTrait' {
                strategyId(1) // Merge the pull request with the current target branch revision
            }
            traits << 'org.jenkinsci.plugins.github__branch__source.ForkPullRequestDiscoveryTrait' {
                strategyId(2) // The current PR revision
                trust(class:'org.jenkinsci.plugins.github_branch_source.ForkPullRequestDiscoveryTrait$TrustContributors')
            }
            // filter names of repos
            traits << 'jenkins.scm.impl.trait.RegexSCMSourceFilterTrait' {
                regex(repository_specifier_regex)
            }
            // filter names of branches
            traits << 'jenkins.scm.impl.trait.RegexSCMHeadFilterTrait' {
                regex(branch_name_specifier_regex)
            }
            it / 'projectFactories' / 'org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProjectFactory' {
                scriptPath("$JENKINSFILE")
            }
        }
    }
}

def tenant(tenant, tenant_auth, tenant_config= { }, add_custom_authentication=true) {
    def folder_exists = jenkins.model.Jenkins.instance.getItem(tenant)?.class == com.cloudbees.hudson.plugins.folder.Folder
    if (! folder_exists ) {
        folder(tenant) {
            displayName(tenant)
            authorization {
                if ( add_custom_authentication ) {
                    dag_deploy_auth(tenant_auth).each { permissions(it) }
                } else {
                    permissions(auth('❌❌❌❌❌ ❌❌❌❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'authenticated'))
                }
            }
        }
    }
    if (tenant_config) tenant_config(tenant)
}

def group_folder(folder_name, tenant_config) {
    auth = false
    tenant(folder_name, '', tenant_config, auth)
}

def app_deploy_pipeline_ml(name, pipeline_permissions, live=false) {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            choiceParam('Repository', ['ml_device_recommendation', 'ml_prototype', 'pl_dataproc', 'fs_subscriber_device', 'fs_billing', 'fs_usage', 'ml_pathway', 'fs_subscriber_base', 'pl_common_utils', 'vf-uk-ngbi-ml-aa'], 'From which repository does the artifact come from. ')
            choiceParam('Environment', ['dev-01', 'tst-01', 'pprd-01', 'pprd-02', 'pprd-03', 'pprd-04', 'pprd-05', 'pprd-06', 'prd-01'], 'Choose according the artefact environment.')
            stringParam('Version', '' , 'Artefact version number, for example: 1.0.0' )
            stringParam('Bucket_Name', '' , 'Introduce the name of an existing bucket' )
            choiceParam('Artefact_Type', ['SNAPSHOT', 'RELEASE'], 'Choose release for definitive deployments or Production environment.')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/Neuron-Deployments.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch('app-deploy-ml')
                        scriptPath('app/Jenkinsfile')
                    }
                }
                lightweight()
            }
        }
    }
}

def app_deploy_pipeline(name, pipeline_permissions, live=false) {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            stringParam('GroupID', 'com.vodafone.neuron.[proj].[lm]', 'The Artefact Group ID')
            stringParam('ArtefactId', 'test_appdeploy', 'The Artefact ID')
            stringParam('ArtefactVersion', '4.5', 'The Artefact Version')
            stringParam('Classifier', '', 'The Artefact Calssifier')
            stringParam('Packaging', 'zip', 'The Packaging Type (e.g. zip, jar...)')
            choiceParam('Decompress', ['yes', 'no'], 'The state of the app file in destination bucket')
            choiceParam('Bucket', live ? ['proda', 'prodb'] : ['dev', 'qa', 'preprod'], 'Where would like to deploy artefact?')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/Neuron-Deployments.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch('develop-v2-vault')
                        scriptPath('app/Jenkinsfile')
                    }
                }
                lightweight()
            }
        }
    }
}
def live_app_deploy_pipeline(name, pipeline_permissions) {
    return app_deploy_pipeline(name, pipeline_permissions, true)
}

def dag_deploy_pipeline(name, pipeline_permissions, live=false) {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            stringParam('GroupID', 'com.vodafone.neuron.[proj].[lm]', 'The Artefact Group ID')
            stringParam('ArtefactId', 'test_appdeploy', 'The Artefact ID')
            stringParam('ArtefactVersion', '4.5', 'The Artefact Version')
            stringParam('Classifier', '', 'The Artefact Calssifier')
            stringParam('Packaging', 'zip', 'The Packaging Type (e.g. zip, jar...)')
            choiceParam('Decompress', ['yes', 'no'], 'The state of the app file in destination bucket')
            choiceParam('Bucket', live ? ['composer-proda', 'composer-prodb'] : ['composer-dev', 'composer-qa', 'composer-preprod'], 'Where would like to deploy artefact?')
            stringParam('ComposerLocation', 'europe-west1', 'Where is Composer cluster located?')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/Neuron-Deployments.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch('develop-v2-vault')
                        scriptPath('dag/Jenkinsfile')
                    }
                }
                lightweight()
            }
        }
    }
}

def dag_deploy_pipeline_shrd_composer(name, pipeline_permissions, live=false) {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            choiceParam('Repository', ['ml_device_recommendation', 'ml_prototype', 'pl_dataproc', 'fs_subscriber_device', 'fs_billing', 'fs_usage', 'ml_pathway', 'fs_subscriber_base', 'pl_common_utils', 'vf-uk-ngbi-ml-aa'], 'From which repository does the artifact come from. ')
            choiceParam('Environment', ['dev-01', 'tst-01', 'pprd-01', 'pprd-02', 'pprd-03', 'pprd-04', 'pprd-05', 'pprd-06', 'prd-01'], 'Choose according the artefact environment.' )
            stringParam('Version', '', 'Artefact version number, for example: 1.0.0' )
            choiceParam('Artefact_Type', ['SNAPSHOT', 'RELEASE'], 'Choose release for definitive deployments or Production environment.')
            stringParam('Composer_Name', '', 'Composer Name.')
            choiceParam('Composer_Location', ['europe-west1', 'europe-west2', 'europe-west3'], 'Where is the Composer cluster located?')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/Neuron-Deployments.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch('dag-deploy-ml')
                        scriptPath('dag/Jenkinsfile')
                    }
                }
                lightweight()
            }
        }
    }
}

def live_dag_deploy_pipeline(name, pipeline_permissions) {
    dag_deploy_pipeline(name, pipeline_permissions, true)
}

def neds_dag_deploy_pipeline(name, pipeline_permissions) {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            stringParam('GroupID', 'com.vodafone.neuron.[proj].[lm]', 'The Artefact Group ID')
            stringParam('ArtefactId', 'test_appdeploy', 'The Artefact ID')
            stringParam('ArtefactVersion', '4.5', 'The Artefact Version')
            stringParam('Classifier', '', 'The Artefact Calssifier')
            stringParam('Packaging', 'zip', 'The Packaging Type (e.g. zip, jar...)')
            choiceParam('Decompress', ['yes', 'no'], 'The state of the app file in destination bucket')
            choiceParam('Bucket', ['neds-composer'], 'Where would like to deploy artefact?')
            stringParam('ComposerLocation', 'europe-west1', 'Where is Composer cluster located?')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/Neuron-Deployments.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch('develop-v2-vault')
                        scriptPath('dag/Jenkinsfile')
                    }
                }
                lightweight()
            }
        }
    }
}

def dp_image_build_pipeline_versioned(name, pipeline_permissions, ibp_version='tags/v2.1') {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            stringParam('BaseImageUrl', '', 'What is the url of the base image')
            stringParam('ImageLabel', '', 'The label value')
            stringParam('RequirementsRepo', '', 'Requirements git repository url')
            stringParam('RequirementsCommitId', '', 'Requirements git repository commitId')
            stringParam('PythonRequirementsPath', '', 'Python requirements file path')
            stringParam('UnixRequirementsPath', '', 'Unix requirements file path')
            choiceParam('InstallUnixPackages', ['false', 'true'], 'Install Unix Packages?')
            stringParam('ImageNamePrefix', '', 'length of less than or equal to 8 characters')
            choiceParam('ModifyBasePackages', ['false', 'true'], 'Modify packages on base image?')
            choiceParam('PipUpgrade', ['false', 'true'], 'Upgrade pip?')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-pipeline-jobs.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch(ibp_version)
                        scriptPath('image-build-jobs/generic-dataproc-image-build.groovy')
                    }
                }
                lightweight()
            }
        }
    }
}

def dp_image_promote_pipeline_versioned(name, pipeline_permissions, jenkinsfile_name='generic-image-promoter.groovy', ibp_version='tags/v2.1') {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            stringParam('ImageName', '', 'What is the image name')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-pipeline-jobs.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch(ibp_version)
                        scriptPath('image-promote-jobs/' + jenkinsfile_name)
                    }
                }
                lightweight()
            }
        }
    }
}

def ndgcsync_sync_pipeline_params_mapping(key) {
    def desc = [
        'PROJECT_ID':'The GCP Project of the BIF Datastore',
        'BIF_DS_NAMESPACE':'The Datastore namespace',
        'COMMUNITY_NAME':'The Collibra Community e.g. IT, PT, Na',
        'DGC_TENANT_CODE':'The Community Name e.g. Cloud Analytics, Puzzle',
        'COLLIBRA_CREDENTIALS_KEY':'The Collibra credentials key in Vault',
        'COLLIBRA_DATASOURCE_TARGET_DOMAIN':'Collibra target domain for datasource',
        'COLLIBRA_CONVERSION_TARGET_DOMAIN':'Collibra target domain for Converted Feeds',
        'COLLIBRA_INGESTION_TARGET_DOMAIN':'Collibra target domain for Ingested Feeds',]
    def mapping =  [
        'pt-ca-nonlive':[
            ['PROJECT_ID', 'vf-pt-ca-nonlive',   ],
            ['BIF_DS_NAMESPACE', 'smoketest-namespace', ],
            ['COMMUNITY_NAME', 'Cloud Analytics - PT',],
            ['DGC_TENANT_CODE', 'PT', ]],
        'pt-ca-live':[
            ['PROJECT_ID', 'vf-pt-ca-live',],
            ['BIF_DS_NAMESPACE', 'vf-pt-live-namespace', ],
            ['COMMUNITY_NAME', 'Cloud Analytics - PT',],
            ['DGC_TENANT_CODE', 'PT', ],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-pt-ca', ],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category Live', ],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion Live', ],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion Live', ]],
        'de-ca-live':[
            ['PROJECT_ID', 'vf-de-ca-live',],
            ['BIF_DS_NAMESPACE', 'vf-de-live-namespace', ],
            ['COMMUNITY_NAME', 'Cloud Analytics - DE',],
            ['DGC_TENANT_CODE', 'DE', ],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-de-ca', ],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category Live', ],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion Live', ],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion Live', ]],
        'de-ca-nonlive':[
            ['PROJECT_ID', 'vf-de-ca-nonlive',   ],
            ['BIF_DS_NAMESPACE', 'build-chain', ],
            ['COMMUNITY_NAME', 'Cloud Analytics - DE',],
            ['DGC_TENANT_CODE', 'DE', ],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-de-ca', ],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category Non-Live', ],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion Non-Live', ],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion Non-Live', ]],
        'es-ca-live':[
            ['PROJECT_ID', 'vf-es-ca-live',],
            ['BIF_DS_NAMESPACE', 'vf-es-ca-live-namespace', ],
            ['COMMUNITY_NAME', 'Cloud Analytics - ES',],
            ['DGC_TENANT_CODE', 'ES', ],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-es-ca', ],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category Live', ],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion Live', ],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion Live', ]],
        'es-ca-nonlive':[
            ['PROJECT_ID', 'vf-es-ca-nonlive',   ],
            ['BIF_DS_NAMESPACE', 'build-chain', ],
            ['COMMUNITY_NAME', 'Cloud Analytics - ES',],
            ['DGC_TENANT_CODE', 'ES', ],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-es-ca', ],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category Non-Live', ],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion Non-Live', ],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion Non-Live', ]],
        'it-ca-live':[
            ['PROJECT_ID', 'vf-it-ca-live',],
            ['BIF_DS_NAMESPACE', 'vf-it-live-namespace', ],
            ['COMMUNITY_NAME', 'Cloud Analytics - IT',],
            ['DGC_TENANT_CODE', 'IT', ],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-it-ca', ],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category Live', ],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion Live', ],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion Live', ]],
        'it-ca-nonlive':[
            ['PROJECT_ID', 'vf-es-ca-nonlive',   ],
            ['BIF_DS_NAMESPACE', 'build-chain', ],
            ['COMMUNITY_NAME', 'Cloud Analytics - IT',],
            ['DGC_TENANT_CODE', 'IT', ],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-it-ca', ],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category Non-Live', ],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion Non-Live', ],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion Non-Live', ]],
        'gr-ca-live':[
            ['PROJECT_ID', 'vf-gr-ca-live',],
            ['BIF_DS_NAMESPACE', 'vf-gr-ca-live-namespace', ],
            ['COMMUNITY_NAME', 'Cloud Analytics - GR'],
            ['DGC_TENANT_CODE', 'GR', ],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-gr-ca', ],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category Live', ],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion Live', ],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion Live', ]],
        'gr-ca-nonlive':[
            ['PROJECT_ID', 'vf-gr-ca-nonlive',   ],
            ['BIF_DS_NAMESPACE', 'vf-gr-ca-nonlive-namespace', ],
            ['COMMUNITY_NAME', 'Cloud Analytics - GR'],
            ['DGC_TENANT_CODE', 'GR', ],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-gr-ca', ],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category Non-Live', ],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion Non-Live', ],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion Non-Live', ]],
        'hu-ca-live':[
            ['PROJECT_ID', 'vf-hu-ca-live',],
            ['BIF_DS_NAMESPACE', 'vf-hu-ca-live-namespace', ],
            ['COMMUNITY_NAME', 'Cloud Analytics - HU'],
            ['DGC_TENANT_CODE', 'HU', ],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-hu-ca', ],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category Live', ],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion Live', ],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion Live', ]],
        'hu-ca-nonlive':[
            ['PROJECT_ID', 'vf-hu-ca-nonlive',   ],
            ['BIF_DS_NAMESPACE', 'vf-hu-ca-nonlive-namespace', ],
            ['COMMUNITY_NAME', 'Cloud Analytics - HU'],
            ['DGC_TENANT_CODE', 'HU', ],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-hu-ca', ],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category Live', ],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion Live', ],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion Live', ]],
        'it-puz-live':[
            ['PROJECT_ID', 'vf-it-puz-live',     ],
            ['DGC_TENANT_CODE', 'IT',],
            ['COMMUNITY_NAME', 'Puzzle - IT',],
            ['BIF_DS_NAMESPACE', 'build-chain',],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-it-ca',],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category Puzzle Live',],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion Puzzle Live',],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion Puzzle Live',],],
        'it-puz-nonlive':[
            ['PROJECT_ID', 'vf-it-puz-nonlive',  ],
            ['DGC_TENANT_CODE', 'IT',],
            ['COMMUNITY_NAME', 'Puzzle - IT',],
            ['BIF_DS_NAMESPACE', 'build-chain',],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-it-ca',],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category PuzzleNon-Live',],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion PuzzleNon-Live',],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion PuzzleNon-Live',],],
        'gned-nwp-live':[
            ['PROJECT_ID', 'vf-gned-nwp-live',   ],
            ['DGC_TENANT_CODE', 'GNED',],
            ['COMMUNITY_NAME', 'Network Planning - GNED',],
            ['BIF_DS_NAMESPACE', 'build-chain',],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-nwp-ca',],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category Live',],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion Live',],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion Live',],],
        'gned-nwp-nonlive':[
            ['PROJECT_ID', 'vf-gned-nwp-nonlive',],
            ['DGC_TENANT_CODE', 'GNED',],
            ['COMMUNITY_NAME', 'Network Planning - GNED',],
            ['BIF_DS_NAMESPACE', 'build-chain',],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-nwp-ca',],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category Non-Live',],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion Non-Live',],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion Non-Live',]],
        'ie-d2-live':[
            ['PROJECT_ID', 'vf-d2-etl-live',   ],
            ['DGC_TENANT_CODE', 'IE',],
            ['COMMUNITY_NAME', 'DigitalTwins - IE',],
            ['BIF_DS_NAMESPACE', 'build-chain',],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-ie-d2',],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category Live',],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion Live',],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion Live',],],
        'ie-d2-nonlive':[
            ['PROJECT_ID', 'vf-d2-etl-nonlive',],
            ['DGC_TENANT_CODE', 'IE',],
            ['COMMUNITY_NAME', 'DigitalTwins - IE',],
            ['BIF_DS_NAMESPACE', 'build-chain',],
            ['COLLIBRA_CREDENTIALS_KEY', 'collibra-sync-ie-d2',],
            ['COLLIBRA_DATASOURCE_TARGET_DOMAIN', 'Data Category Non-Live',],
            ['COLLIBRA_CONVERSION_TARGET_DOMAIN', 'Data Feed Conversion Non-Live',],
            ['COLLIBRA_INGESTION_TARGET_DOMAIN', 'Data Feed Ingestion Non-Live',],
        ],
     ]

    return mapping.getAt(key).collect {
        def fieldName = it[0]
        it << desc[fieldName]
    }
}

def ndgcsync_sync_pipeline(name, pipeline_permissions, params=[:]) {
    // params = [market_name, is_live, scmUrl, branch, scriptPath, pipeline_params ]
    def scriptPathEnv = params.is_live ? 'live' : 'nonlive'
    def scmUrl = params.scmUrl ?: 'https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-dgc-sync-svcs.git'
    def calculatedBranch = params.branch ?: 'tags/v1.6'
    def market_to_scriptPath = [
        'it-puz':'puz/it/',
        'gned-nwp': 'nwp/GNED/',
        'pt-ca': 'ca/pt/',
        'de-ca': 'ca/de/',
        'es-ca': 'ca/es/',
        'gr-ca': 'ca/gr/',
        'hu-ca': 'ca/hu/',
        'it-ca': 'ca/it/',
        'ie-d2': 'd2/ie/',
    ]
    def calculatedScriptPath = params.scriptPath ?: 'scheduler/jenkins/zeta/' + market_to_scriptPath[params.market_name] + scriptPathEnv + '/Jenkinsfile'
    def calculatedParams = params.pipeline_params ?: ndgcsync_sync_pipeline_params_mapping(params.market_name + '-' + scriptPathEnv)
    pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            calculatedParams.each { stringParam(it) }
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url(scmUrl)
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch(calculatedBranch)
                        scriptPath(calculatedScriptPath)
                    }
                }
                lightweight()
            }
        }
        triggers {
            cron('@midnight')
        }
    }
}

def live_ndgcsync_sync_pipeline(name, pipeline_permissions, params) {
    params.is_live = true
    ndgcsync_sync_pipeline(name, pipeline_permissions, params)
}

//RA_PREPARE_DEPLOY_PACKAGES
def ra_prepare_deploy_packages(name, pipeline_permissions) {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            stringParam('target_project', '', 'target project. Ex: vf-it-ca-nonlive, vf-pt-ca-live')
            stringParam('target_environment', '', 'target environment. Ex: dev, qa, proda, prodb')
            stringParam('group_id', 'com.vodafone.neuron.ra.core', 'red agent group id. Ex: com.vodafone.neuron.ra.pt, com.vodafone.neuron.ra.it')
            stringParam('artifact_id', '', 'artifact id. Ex: distribution, test-distribution')
            stringParam('version', '', 'red agent version. Ex: 5.10, 4.30-SNAPSHOT')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-redagent-deploy.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch('develop')
                        scriptPath('prepare_ra_packages.groovy')
                    }
                }
                lightweight()
            }
        }
    }
}

//DP_COMPOSER_DEPLOYER
def dp_composer_deployer_pipeline(name, pipeline_permissions) {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            stringParam('target_project', '', 'target project. Ex: vf-it-ca-nonlive, vf-pt-ca-live')
            stringParam('target_environment', '', 'target environment. Ex: dev, qa, proda, prodb')
            stringParam('group_id', 'com.vodafone.neuron.ra.core', 'red agent group id. Ex: com.vodafone.neuron.ra.pt, com.vodafone.neuron.ra.it')
            stringParam('artifact_id', '', 'artifact id. Ex: distribution, test-distribution')
            stringParam('version', '', 'red agent version. Ex: 5.10, 4.30-SNAPSHOT')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-redagent-deploy.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch('develop')
                        scriptPath('prepare_generic_packages.groovy')
                    }
                }
                lightweight()
            }
        }
    }
}

def bif_test_framework(name, scm_url, scm_branch='develop') {
    return pipelineJob(name) {
        authorization {
            permissions(auth('❌❌❌❌❌ ✅✅✅❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-grp-jenkins-admin'))
            permissions(auth('❌❌❌❌❌ ✅✅✅❌❌❌❌❌✅❌ ❌❌❌ ❌❌❌❌ ❌', 'gcp-vf-grp-jenkins-user'))
        }
        parameters {
            stringParam('PROJECT_ID', 'vf-eng-ca-live', 'The GCP Project of the BIF Datastore eg: vf-eng-ca-live')
            stringParam('ENVIRONMENT', 'proda', 'The target environment (proda, prodb, ...)')
            stringParam('BIF_NAMESPACE_SUFFIX', '', 'The namespace suffix eg: 2.13')
            stringParam('TRIGGER_TYPE', '', 'The type of run to execute, eg: sanity or regression')
            stringParam('BIF_APP_VERSION', '', 'The BIF Application version, can be a branch, a tag or an ID')
            stringParam('LOG_LEVEL', 'info', 'The log level to be used in BTF')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-redagent-deploy.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch(scm_branch)
                        scriptPath('bif_test_framework/Jenkinsfile')
                    }
                }
                lightweight()
            }
        }
    }
}

def bif_deploy_pipeline_versioned(name, pipeline_permissions, bif_pipelines_version='tags/v1.1.0') {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            stringParam('ENVIRONMENT', 'proda', 'The target environment (dev, qa, preprod, proda, prodb)')
            stringParam('BIF_APP_VERSION', 'develop', 'The BIF Application version, can be a branch, a tag or an ID')
            stringParam('BIF_CFG_REPO_URL', 'https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-bif-cfg', 'The BIF Config repository URL')
            stringParam('BIF_CFG_VERSION', 'develop', 'The BIF Config repository version, can be a branch, a tag or an ID')
            stringParam('PGS_FILE_PATHS', 'dsconfig/configuration/*/processing_groups.yaml', 'List of space separated custom processing group files to use, as relative path in the BIF Config repo. Optional.')
            stringParam('BIF_NAMESPACE_SUFFIX', '', 'The namespace suffix eg: 2.13. Optional, for testing purposes only.')
            stringParam('LOG_LEVEL', 'info', 'The log level to be used. Optional.')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-bif-jenkins-pipelines.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch(bif_pipelines_version)
                        scriptPath('jenkins_pipelines/deploy-bif.groovy')
                    }
                }
                lightweight()
            }
        }
    }
}

def bif_deploy_feeds_pipeline_versioned(name, pipeline_permissions, bif_pipelines_version='tags/v1.1.0') {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            stringParam('ENVIRONMENT', 'proda', 'The target environment (dev, qa, preprod, proda, prodb)')
            stringParam('BIF_APP_VERSION', 'develop', 'The BIF Application version, can be a branch, a tag or an ID')
            stringParam('BIF_CFG_REPO_URL', 'https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-bif-cfg', 'The BIF Config repository URL')
            stringParam('BIF_CFG_VERSION', 'develop', 'The BIF Config repository version, can be a branch, a tag or an ID')
            stringParam('FEEDS_FILE_PATHS', '', 'List of space separated relative paths to the cfg repo for feed configuration files. Python glob expressions accepted to process multiple feeds but need to include file suffix. E.g.: dsconfig/inbound/*/*_conversion.xml')
            stringParam('BIF_NAMESPACE_SUFFIX', '', 'The namespace suffix eg: 2.13. Optional, for testing purposes only.')
            stringParam('RUN_ID', '', 'Run Identifier (for testing purposes only)')
            stringParam('LOG_LEVEL', 'info', 'The log level to be used. Optional.')
            choiceParam('SYNC_CONSTELLATION', ['False', 'True'], 'Constellation API import into Collibra (UUID is required in the ConfigID of the configuration_conversion.xml to successfully import)')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-bif-jenkins-pipelines.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch(bif_pipelines_version)
                        scriptPath('jenkins_pipelines/deploy-bif-feeds.groovy')
                    }
                }
                lightweight()
            }
        }
    }
}

def bif_deploy_orchestrator_pipeline_versioned(name, pipeline_permissions, bif_pipelines_version='tags/v1.1.0') {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            stringParam('ENVIRONMENT', 'proda', 'The target environment (dev, qa, preprod, proda, prodb)')
            stringParam('BIF_APP_VERSION', 'develop', 'The BIF Application version, can be a branch, a tag or an ID')
            stringParam('BIF_CFG_REPO_URL', 'https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-bif-cfg', 'The BIF Config repository URL')
            stringParam('BIF_CFG_VERSION', 'develop', 'The BIF Config repository version, can be a branch, a tag or an ID')
            stringParam('PGS_FILE_PATHS', 'dsconfig/configuration/*/processing_groups.yaml', 'List of space separated custom processing group files to use, as relative path in the BIF Config repo. Optional.')
            stringParam('BIF_NAMESPACE_SUFFIX', '', 'The namespace suffix eg: 2.13. Optional, for testing purposes only.')
            stringParam('LOG_LEVEL', 'info', 'The log level to be used. Optional.')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-bif-jenkins-pipelines.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch(bif_pipelines_version)
                        scriptPath('jenkins_pipelines/deploy-bif-orchestrator.groovy')
                    }
                }
                lightweight()
            }
        }
    }
}

def bif_test_pipeline_versioned(name, pipeline_permissions, bif_pipelines_version='develop') {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            stringParam('ENVIRONMENT', 'proda', 'The target environment (dev, qa, preprod, proda, prodb)')
            stringParam('BIF_APP_VERSION', 'develop', 'The BIF Application version, can be a branch, a tag or an ID')
            stringParam('BIF_CFG_REPO_URL', 'https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-bif-cfg', 'The BIF Config repository URL')
            stringParam('BIF_CFG_VERSION', 'develop', 'The BIF Config repository version, can be a branch, a tag or an ID')
            stringParam('BIF_NAMESPACE_SUFFIX', '', 'The namespace suffix eg: 2.13. Optional, for testing purposes only.')
            stringParam('TRIGGER_TYPE', '', 'The type of run to execute, eg: sanity or regression')
            stringParam('LOG_LEVEL', 'info', 'The log level to be used. Optional.')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-bif-jenkins-pipelines.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch(bif_pipelines_version)
                        scriptPath('jenkins_pipelines/run-bif-tests.groovy')
                    }
                }
                lightweight()
            }
        }
    }
}

def drs_deploy_policies_pipeline_versioned(name, pipeline_permissions, drs_pipelines_version='develop') {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            stringParam('ENVIRONMENT', 'proda', 'The target environment (dev, qa, preprod, proda, prodb)')
            stringParam('DRS_APP_VERSION', 'develop', 'The DRS Application version, can be a branch, a tag or an ID')
            stringParam('DRS_CFG_REPO_URL', 'https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-drs-cfg', 'The DRS Config repository URL')
            stringParam('DRS_CFG_VERSION', 'develop', 'The DRS Config repository version, can be a branch, a tag or an ID')
            stringParam('POLICIES_FILE_PATHS', '', 'List of space separated relative paths to the cfg repo for policies retention files. E.g.: dsconfig/inbound/*/*_retention.xml')
            stringParam('DRS_NAMESPACE_SUFFIX', '', 'The namespace suffix eg: 2.13. Optional, for testing purposes only.')
            stringParam('RUN_ID', '', 'Run Identifier (for testing purposes only)')
            stringParam('LOG_LEVEL', 'info', 'The log level to be used. Optional.')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-app-jenkins-pipelines.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch(drs_pipelines_version)
                        scriptPath('jenkins_pipelines/deploy-policy-drs.groovy')
                    }
                }
                lightweight()
            }
        }
    }
}

def drs_test_pipeline_versioned(name, pipeline_permissions, drs_pipelines_version='develop') {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            stringParam('ENVIRONMENT', 'proda', 'The target environment (dev, qa, preprod, proda, prodb)')
            stringParam('DRS_APP_VERSION', 'develop', 'The DRS Application version, can be a branch, a tag or an ID')
            stringParam('DRS_CFG_REPO_URL', 'https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-drs-cfg', 'The DRS Config repository URL')
            stringParam('DRS_CFG_VERSION', 'develop', 'The DRS Config repository version, can be a branch, a tag or an ID')
            stringParam('SUFFIX', '', 'Optional, If given this suffix will be added to the audit report')
            stringParam('TRIGGER_TYPE', '', 'The type of run to execute, eg: sanity or regression')
            stringParam('RUN_ID', '', 'The run_id to which test data gets copied. ')
            stringParam('LOG_LEVEL', 'info', 'The log level to be used. Optional.')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-app-jenkins-pipelines.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch(drs_pipelines_version)
                        scriptPath('jenkins_pipelines/run-drs-tests.groovy')
                    }
                }
                lightweight()
            }
        }
    }
}

def drs_deploy_functions_pipeline_versioned(name, pipeline_permissions, drs_pipelines_version='develop') {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            stringParam('ENVIRONMENT', 'proda', 'The target environment (dev, qa, preprod, proda, prodb)')
            stringParam('DRS_APP_VERSION', 'develop', 'The DRS Application version, can be a branch, a tag or an ID')
            stringParam('DRS_CFG_REPO_URL', 'https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-drs-cfg', 'The DRS Config repository URL')
            stringParam('DRS_CFG_VERSION', 'develop', 'The DRS Config repository version, can be a branch, a tag or an ID')
            stringParam('CLOUD_FUNCTION_NAME', 'all', 'DRS Cloud Functions eg: all')
            stringParam('DRS_NAMESPACE_SUFFIX', '', 'The namespace suffix eg: 2.13. Optional, for testing purposes only.')
            stringParam('PGS_FILE_PATHS', '', 'List of space separated custom processing group files to use, as relative path in the DRS Config repo')
            stringParam('LOG_LEVEL', 'info', 'The log level to be used. Optional.')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-app-jenkins-pipelines.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch(drs_pipelines_version)
                        scriptPath('jenkins_pipelines/deploy-functions-drs.groovy')
                    }
                }
                lightweight()
            }
        }
    }
}

def drs_ops_trash_pipeline_versioned(name, pipeline_permissions, drs_pipelines_version='develop') {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            stringParam('TRASH_FUNCTION_NAME', '', 'The name of the trash function to trigger')
            stringParam('EXECUTION_ID', '', 'The job id of the trash function. ')
            stringParam('LOG_LEVEL', 'info', 'The log level to be used. Optional.')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-app-jenkins-pipelines.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch(drs_pipelines_version)
                        scriptPath('jenkins_pipelines/run-trash-ops.groovy')
                    }
                }
                lightweight()
            }
        }
    }
}

def drs_ops_prepare_trash_pipeline_versioned(name, pipeline_permissions, drs_pipelines_version='develop') {
    return pipelineJob(name) {
        authorization {
            pipeline_permissions.each { permissions(it) }
        }
        parameters {
            stringParam('PREPARE_TRASH_FUNCTION_NAME', '', 'The name of the prepare trash function to be triggered')
            stringParam('EXECUTION_ID', '', 'The job id of the prepare trash function. ')
            stringParam('LOG_LEVEL', 'info', 'The log level to be used. Optional.')
        }
        definition {
            cpsScm {
                scm {
                    git {
                        remote {
                            url('https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-app-jenkins-pipelines.git')
                            credentials('gcp-jenkins-ghe-funcuser')
                        }
                        branch(drs_pipelines_version)
                        scriptPath('jenkins_pipelines/run-prepare-trash-ops.groovy')
                    }
                }
                lightweight()
            }
        }
    }
}
