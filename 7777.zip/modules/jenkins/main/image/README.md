docker build -t eu.gcr.io/vf-grp-neuronenabler-nonlive/alpine-curl-jq:1.0.6 -f  modules/jenkins/main/image/credentials-reloader.Dockerfile .

# vf-vault dockerfile
# docker build -t eu.gcr.io/vf-grp-neuronenabler-nonlive/vault:1.5.4-vf -f  modules/jenkins/main/image/vf-vault.Dockerfile .
