
# Getting started

## Introduction

This deployment sets up a Jenkins CI deployment complete with plugins, (as specified in the plugins.txt file during the image build).

## Presenting an internal LB and DNS name
Each internal service, (Jenkins, Nexus, etc.) will present an internal load-balancer with an internal DNS entry, e.g. (Jenkins - jenkins.neuron.bdc.vf.local.).
1. Create private zone:
1.1. gcloud beta dns --project=vf-grp-shared-services-nonlive managed-zones create neuron-bdc-vf-local --description= --dns-name=neuron.bdc.vf.local. --visibility=private --networks vf-group-ss-vpc

2. Create DNS record for internal LB
2.1.`gcloud dns --project=vf-grp-shared-services-nonlive record-sets transaction start --zone=neuron-bdc-vf-local`
`gcloud dns --project=vf-grp-shared-services-nonlive record-sets transaction add 172.20.23.9 --name=jenkins.neuron.bdc.vf.local. --ttl=5 --type=A --zone=neuron-bdc-vf-local`
`gcloud dns --project=vf-grp-shared-services-nonlive record-sets transaction execute --zone=neuron-bdc-vf-local`
  

## Deploying
```
kubectl apply -f pvc.yaml 
kubectl apply -f services.yaml
kubectl apply -f deployment.yaml
```
