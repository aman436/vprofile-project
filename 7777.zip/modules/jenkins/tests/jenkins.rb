# frozen_string_literal: true

def run_jenkins(params)
  project_id = params['config']['project_id']
  control "#{project_id} : jenkins : " do
    title 'Infrastructure for jenkins setup correctly'
    impact 0.4
  end
end
