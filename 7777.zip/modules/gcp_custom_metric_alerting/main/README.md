This Module is a generic one creates log based metrics and its associated alerts.
You can also add a list of email notification channels that you want to be notified when this alert is fired.

input variables required are:
  custom_metric_alert: List of maps
  notification_channels: List of strings (emails}.

**** Important Prerequisite: Make you have a workspace for your project ******
Before running this module, make sure to create a workspace, if it's not already created, as it can only be created via the console,
Kindly follow this link to create the workspace: "https://cloud.google.com/monitoring/workspaces/create#single-project-workspace"


Module call examples from project configuration:
make sure a resource is defined for your specific project.

```bash
modules:
  - name: terraform_provider_base_tf12
  - name: gcp_custom_metric_alerting
    notification_channels: ["gcp-lm1-ca-owner@vodafone.com", "gcp-lm2-ca-ops@vodafone.com"]
    custom_metric_alert:
      "DAG Disable":
        metric_name: "dag-disable-metric"
        alert_name: "P3_${var.project_id}_LIVE_dag-disabled"
        custom_metric_filter: "resource.type=\"cloud_composer_environment\" resource.labels.location=\"europe-west1\" resource.labels.environment_name=\"neds-composer\" \"/admin/airflow/paused?is_paused=false\""
        custom_metric_kind: "DELTA"
        custom_metric_type: "INT64"
        alert_filter: "metric.type=\"logging.googleapis.com/user/dag-disable-metric(Must be same as Metric Name)\" resource.type=\"cloudsql_database\""
        alert_combiner: "OR"
        alert_duration: "0s"
        alert_threshold: "10"
        alert_alignment: "600s"
        alert_comparison: "COMPARISON_GT"
        alert_aligner: "ALIGN_RATE"
        alert_reducer: "REDUCE_COUNT"
        alert_doc: "A dag on composer airflow has been disabled"
      "No Files Received from Source":
        metric_name: "no-files-received-cw-delta"
        alert_name: "no-files-received-cw-delta"
        custom_metric_filter: "resource.type=\"cloud_composer_environment\" labels.\"task-id\"=\"check_file_count\" labels.workflow=~ \"contractwatch_delta_load\" textPayload=~\"INFO - file_count: 0\""
        custom_metric_kind: "DELTA"
        custom_metric_type: "INT64"
        alert_filter: "metric.type=\"logging.googleapis.com/user/no-files-received-cw-delta(Must be same as Metric Name)\" resource.type=\"cloud_composer_environment\""
        alert_combiner: "OR"
        alert_duration: "0s"
        alert_threshold: "1"
        alert_alignment: "60s"
        alert_comparison: "COMPARISON_GT"
        alert_aligner: "ALIGN_RATE"
        alert_reducer: "REDUCE_COUNT"
        alert_doc: "No files received today from source for CW Delta load DAG. Please check with Source Team"
```

Recommendation: Use predefined Groups for DE/DS/PE/Owners/Ops created via PCS code base for your project.
https://github.vodafone.com/VFGroup-GDC-PCS/pcs-gcp-customer-yaml-config/tree/master/groups_mgmt

