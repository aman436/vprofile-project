# frozen_string_literal: true

def run_restricted_zone_gke(params)
  project_id = params['config']['project_id']
  control "#{project_id} : restricted_zone_gke : " do
    title 'restricted_zone_gke setup correctly'
    impact 0.4
  end
end
