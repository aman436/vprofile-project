# frozen_string_literal: true

['vm'].each do |lib|
  require_relative "#{Dir.pwd}/target/tests/libraries/#{lib}.rb"
end
  
  def run_remote_dev_vm_instance(params)
    project_id = params['config']['project_id']
    vm_name="vf-grp-neuronenabler-nonlive-dev-vm-#{params['variables']['project_team_name']}"

    control "#{project_id} : #{params['config']['module_name']}" do
      title 'Remote dev VM instance exist and configured correctly'
      impact 0.3
  
      vm_instance_exists(
        vm_name,
        project_id,
        params['variables']['zone']
      )
      vm_instance_zone(
        vm_name,
        project_id,
        params['variables']['zone']
      )
      vm_instance_status(
        vm_name,
        project_id,
        params['variables']['zone']
      )
      vm_instance_machine_type(
        vm_name,
        project_id,
        params['variables']['zone'],
        params['variables']['vm_type']
      )
      vm_no_public_ip(
        vm_name,
        project_id,
        params['variables']['zone'],
        params['tests']['public_ip']
      )
      vm_in_subnet(
        vm_name,
        project_id,
        params['variables']['zone'],
        params['variables']['management_zone_name']
      )

      # Service Accounts
      service_account_name =  "dev-vm-#{params['variables']['project_team_name']}-sa@vf-grp-neuronenabler-nonlive.iam.gserviceaccount.com"
      sa_exists(service_account_name, project_id)

      params['tests']['roles'].each do |role|
        sa_iam_role_exists(
          "dev-vm-#{params['variables']['project_team_name']}-sa@vf-grp-neuronenabler-nonlive.iam.gserviceaccount.com",
          project_id,
          role
        )
      end
  

    end
  end
  