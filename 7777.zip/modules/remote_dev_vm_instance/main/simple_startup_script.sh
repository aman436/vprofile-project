#! /bin/bash
now=$(date)
printf "\n\n##### Updating system at $now\n" |& tee -a /opt/startup_out.txt
apt-get -y update |& tee -a /opt/startup_out.txt
printf "\n##### Done with system check ($now)\n" |& tee -a /opt/startup_out.txt
