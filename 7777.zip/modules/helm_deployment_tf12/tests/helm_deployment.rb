# frozen_string_literal: true

def run_k8s_deploy(params)
  project_id = params['config']['project_id']
  control "#{project_id} : k8s_deploy : " do
    title 'K8s deployment setup correctly'
    impact 0.4
  end
end
