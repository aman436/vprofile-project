
# Getting started

## Introduction

This deployment sets up a nginx hosted static page that serves as a portal to Neuron services.

## Deploying
```
kubectl apply -f landing-page-deploy.yaml 
```
