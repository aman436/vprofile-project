# frozen_string_literal: true

def run_landing_page(params)
  project_id = params['config']['project_id']
  control "#{project_id} : landing_page : " do
    title 'Landing page setup correctly'
    impact 0.4
  end
end
