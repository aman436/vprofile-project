# Terraform Google Composer Module

The module was designed to set-up a composer environment.

Should be used with the `nucleus_core_infra` module.

This module can be used multiple times in the same project to create multiple composer instances.
