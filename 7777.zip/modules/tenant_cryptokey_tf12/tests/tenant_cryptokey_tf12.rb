# frozen_string_literal: true

require_relative "#{Dir.pwd}/target/tests/libraries/cmek.rb"

def run_tenant_cryptokey_tf12(params)
  project_id = params['config']['project_id']
  key_location = params['variables']['key_location']
  control "#{project_id} : #{params['config']['module_name']}" do
    title 'Correct CMEK keys set up'
    impact 0.8
    if params['variables']['bq_key']
      key_ring_name = "keyring-#{project_id}-bq-#{params['variables']['bq_key_location']}"
      check_keyring(project_id.to_s, key_ring_name, params['variables']['bq_key_location'])
      check_keys("cmek-HSM-#{project_id}-#{params['variables']['bq_key_location']}-bq", project_id, params['variables']['bq_key_location'], key_ring_name, params['variables']['bq_key_access'])
    end
    if params['variables']['gcs_key']
      key_ring_name = "keyring-#{project_id}-gcs-#{params['variables']['gcs_key_location']}"
      check_keyring(project_id.to_s, key_ring_name, params['variables']['gcs_key_location'])
      check_keys("cmek-HSM-#{project_id}-#{params['variables']['gcs_key_location']}-gcs", project_id, params['variables']['gcs_key_location'], key_ring_name, params['variables']['gcs_key_access'])
    end
  end
end