from templater.main.ModulePythonTemplater import ModulePythonTemplater
import logging
import os


class TenantVaultTemplater(ModulePythonTemplater):
    def _create_configs_values(self, base_config: dict) -> list:
        logging.debug(
            f"TenantVaultTemplater._create_configs_values: base_config: {base_config}"
        )
        tenant_list: list = base_config.pop("tenant_list")
        region: str = base_config.pop("region")
        return [
            {
                "config": {
                    "terraform_resource_name": f"""tenant_vault_{tenant_dict.get('name')}{f"-{tenant_dict.get('program')}" if tenant_dict.get('program') else ""}""",
                    "base_path": os.getcwd(),
                    "terraform_module_name": "k8s_deploy",
                },
                "variables": {
                    **base_config,
                    **{
                        "config_values": {
                          **{
                            "TF_TENANT_PREFIX": f"""vault-{tenant_dict.get('name')}{f"-{tenant_dict.get('program')}" if tenant_dict.get("program") else ""}""",
                            "TF_KMS_PROJECT_NAME": f"vf-{tenant_dict.get('name')}-dhk{tenant_dict.get('dhk_suffix', '')}",
                            "TF_KMS_REGION": tenant_dict.get("region", region),
                            "TF_VAULT_BUCKET_NAME": f"""vf{tenant_dict.get('name')}-dh-vault-secrets{f"-{tenant_dict.get('program')}" if tenant_dict.get("program") else ""}""",
                            "TF_KMS_KEY_RING": f"keyring-vf-{tenant_dict.get('name')}-dhk{tenant_dict.get('dhk_suffix', '')}-{tenant_dict.get('region', region)}",
                            "TF_KMS_CRYPTO_KEY": f"cmek-HSM-vf-{tenant_dict.get('name')}-gcs-{tenant_dict.get('region', region)}-agf",
                            "TF_VAULT_CRT_BASE64": """${base64encode("${module.vault_core.vault_crt_base64_vault}\\n${module.vault_core.vault_crt_base64_vault_ca}")}""",
                            "TF_VAULT_KEY_BASE64": """${base64encode("${module.vault_core.vault_key_base64}")}""",
                          },
                          **base_config.pop('config_values', {}),
                        }
                    },
                },
            }
            for tenant_dict in tenant_list
        ]

    def run(self, config: dict) -> str:
        return "".join(
            [
                self.Jinja.run_template(
                    template_name="module_template", params=tenant_config
                )
                for tenant_config in self._create_configs_values(config)
            ]
        )
