#!/bin/bash -xe

yum update -y

if [[ $EUID -ne 0 ]]; then
  echo "This script must be run as root" 1>&2
  exit 1
fi

restrict_su() {
  cat >/tmp/sudoers.sh <<"EOF"
#!/bin/bash
sudo chmod a+r /var/google-sudoers.d/*
sudo chmod a+r /etc/sudoers.d/google_sudoers
if grep -Fq "/bin/su" /etc/sudoers.d/google_sudoers
then
  :
else
  sudo awk 'FNR==1{print $0 ", !/bin/su";}' /etc/sudoers.d/google_sudoers > /tmp/google_sudoers
  sudo visudo -c -f /tmp/google_sudoers
  if [ "$?" -eq "0" ]; then
    sudo cp -f /tmp/google_sudoers /etc/sudoers.d/google_sudoers
  fi
fi
for file in /var/google-sudoers.d/*; do
  echo "Removing individual user access"
  echo "Removing individual user access for $file"
  filename=$(basename $file)
  if sudo grep -Fq "/bin/su" $file
  then
    echo "Su access already removed from $filename"
  else
    echo "Removing su access for $filename"
    sudo awk 'FNR==1{print $0 ", !/bin/su";}' $file > /tmp/$filename
    sudo visudo -c -f /tmp/$filename
    if [ "$?" -eq "0" ]; then
      sudo cp -f /tmp/$filename $file
    fi
  fi
done
/bin/bash
EOF

  chmod a+x /tmp/sudoers.sh
  chmod a+r /var/google-sudoers.d

  echo -e '\nForceCommand /tmp/sudoers.sh' >>/etc/ssh/sshd_config
  systemctl restart sshd
}

enable_google_monitoring() {
  echo "[INFO] Installing Stackdriver Monitoring and logging agent"

  curl https://dl.google.com/cloudagents/install-monitoring-agent.sh | bash -

  systemctl restart stackdriver-agent
  systemctl enable stackdriver-agent

  curl https://dl.google.com/cloudagents/install-logging-agent.sh | bash -

  mkdir -p /etc/google-fluentd/config.d/
  cat >/etc/google-fluentd/config.d/squid.conf <<"EOF"
<source>
  @type tail
  <parse>
    @type json
  </parse>  
  path /var/log/squid/*.log
  pos_file /var/lib/google-fluentd/pos/squid.pos
  read_from_head true
  tag squid
</source>
EOF

  systemctl restart google-fluentd
  systemctl enable google-fluentd
}

enable_squid() {
  # Install squid proxy
  #
  # Once squid is installed, linux system proxy can be set with the following environment variables:
  #   export https_proxy=http://127.0.0.1:3128/
  #   export https_proxy=http://127.0.0.1:3128/
  #   export no_proxy=169.254.169.254  # Skip proxy for the local Metadata Server.

  echo "[INFO] Installing Squid"

  yum install -y squid

  gsutil cp ${whitelist_gcs} /etc/squid/whitelist.txt
  gsutil cp ${squid_config_gcs} /etc/squid/squid.conf

  if [ ! -d /etc/squid/ssl ]; then
    echo "[INFO] Generating SSL cert"
    mkdir -p /etc/squid/ssl
    cd /etc/squid/ssl
    openssl genrsa -out squid.key 4096
    openssl req -new -key squid.key -out squid.csr -subj "/C=XX/ST=XX/L=squid/O=squid/CN=squid"
    openssl x509 -req -days 3650 -in squid.csr -signkey squid.key -out squid.crt
    cat squid.key squid.crt >>squid.pem

    /usr/lib64/squid/security_file_certgen -c -s /var/spool/squid/ssl_db -M 4MB
  fi

  systemctl stop squid
  systemctl start squid
  systemctl enable squid

  sysctl -w net.ipv4.ip_forward=1
  echo "net.ipv4.ip_forward = 1" >>/etc/sysctl.d/ip_forward.conf

  my_ip=$(hostname -I | xargs)
  iptables -t nat -A PREROUTING -p tcp --dport 443 -j DNAT --to-destination $my_ip:443
  iptables -t nat -A PREROUTING -p tcp --dport 80 -j DNAT --to-destination $my_ip:80
  iptables-save >/etc/sysconfig/iptables
}

# infinite net cat process listening for health check
enable_health_check_port() {
  yum install -y nc
  nohup bash -c "while true; do nc -l -p 8080 -c 'echo -e \"HTTP/1.1 200 OK\n\n \$(date)\"'; done" &
}

watch_for_whitelist_changes() {
  cat >/tmp/reload_config.sh <<"EOF"
#!/bin/bash
while true; do
  sleep 10
  gsutil cp ${whitelist_gcs} /etc/squid/whitelist.txt
  gsutil cp ${squid_config_gcs} /etc/squid/squid.conf
  squid -k parse && squid -k reconfigure
done
EOF
  chmod +x /tmp/reload_config.sh
  nohup bash -c "/tmp/reload_config.sh" &
}

###################################
# Main body of script starts here #
###################################
echo "[INFO] Start of script"

echo "Enable squid ?"${enable_squid}
if [ ${enable_squid} = true ]; then
  enable_squid
fi

echo "Enable google monitoring ?"${enable_google_monitoring}
if [ ${enable_google_monitoring} = true ]; then
  enable_google_monitoring
fi

echo "Restrict su ?"${restrict_su}
if [ ${restrict_su} = true ]; then
  restrict_su
fi

enable_health_check_port
watch_for_whitelist_changes

echo "[INFO] - Script completed"
