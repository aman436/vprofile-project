Inspired by:
https://aws.amazon.com/blogs/security/how-to-add-dns-filtering-to-your-nat-instance-with-squid/

This module assumes: 
- the var.vpc_name contains a NAT Gateway and unrestricted access to the internet
- the var.vpc_name contains a Cloud Router

This module creates: 
- in the var.subnet_name: a squid proxy deployment in the chosen subnet with a "public" network tag
- in the var.vpc_name: routing rules to transparently proxy all requests through squid if the machine does not use "public" network tag
- in the var.vpc_name: firewall rules to allow squid to receive connections

Features:
- Does not require exporting HTTP_PROXY or HTTPS_PROXY
- Updating the whitelist does not require the squid restart. A live reloading mechanism observes configuration in the bucket and reloads it automatically.
- Detailed structured logs in cloud logging for all requests

