# frozen_string_literal: true

def run_tenant_core_gke_tf12(params)
  project_id = params['config']['project_id']
  control "#{project_id} : tenant_core_gke_tf12 : " do
    title 'tenant_core_gke_tf12 setup correctly'
    impact 0.4
  end
end
