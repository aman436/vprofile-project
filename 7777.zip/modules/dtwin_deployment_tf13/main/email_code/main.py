import requests
import google.auth
import google.auth.transport.requests
import smtplib
import time
import google.oauth2.id_token
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

SENDER_EMAIL = "digitaltwinapp@vodafone.com"
VAULT_ROLE = "vf-d2tst-etl-nonlive-iam"
PROJECT_ID = "vf-d2tst-ca-nonlive"
SERVICE_ACCOUNT = "vf-d2tst-ca-email-function@vf-d2tst-ca-nonlive.iam.gserviceaccount.com"

VAULT_URL = "https://beta-gvp.vault.neuron.bdp.vodafone.com/"
def generate_bearer_token():
    creds, project = google.auth.default(scopes=["https://www.googleapis.com/auth/cloud-platform"])
    auth_req = google.auth.transport.requests.Request()
    creds.refresh(auth_req)
    return creds.token

def get_jwt_token2():
    expiration = str(int(time.time()) + 600)
    bearer_token = generate_bearer_token ()
    # sign_jwt_request_body = {"payload": {"aud": f"vault/{VAULT_ROLE}","sub": SERVICE_ACCOUNT,"exp": expiration}}
    sign_jwt_request_body = { "payload": '{"aud": "vault/'+VAULT_ROLE+'","sub": "'+SERVICE_ACCOUNT+'","exp": '+expiration+' }'    }
    iam_server_url = f"https://iam.googleapis.com/v1/projects/{PROJECT_ID}/serviceAccounts/{SERVICE_ACCOUNT}:signJwt"
    
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer  {bearer_token}'
    }
    response = requests.post(url=iam_server_url, json=sign_jwt_request_body, headers=headers)
    response_json = response.json()
    print (response_json['signedJwt'])
    return response_json['signedJwt']

def get_vault_token():
    internal_jwt = get_jwt_token2()
    vault_token_request_body = {"role": VAULT_ROLE, "jwt": internal_jwt}
    response = requests.post(url=VAULT_URL + "v1/auth/gcp/login", data=vault_token_request_body,verify='cert.pem')
    return response.json()['auth']['client_token']

def read_vault_key(http_request):
    token = get_vault_token()
    key_path = "vf-d2tst-etl-nonlive/data/email_function"
    headers_body = {'X-Vault-Token': token, 'X-Vault-Request': "true" }
    response = requests.get(url=VAULT_URL + "v1/" + key_path, headers=headers_body, verify='cert.pem')
    pass_val = response.json()['data']['data']['password']
    username  = response.json()['data']['data']['username']
    try:
        out= parse_multipart(http_request,username,pass_val)
        return out
    except Exception as e:
        raise Exception(str(e))


def parse_multipart(http_request, smtp_username, smtp_password):
    cc_addr=[]
    json_object = http_request.get_json()
    msg = MIMEMultipart('alternative')
    print(json_object)
    if 'to' not in json_object.keys():
        raise Exception ('receiver is not set')
    if 'subject' not in json_object.keys():
        raise Exception ('subject is not set') 
    if 'msg' not in json_object.keys():
        raise Exception ('message is not set') 
    if 'cc' in json_object.keys():
        msg['Cc'] = json_object['cc']
        cc_addr = json_object['cc'].split(',')

    to_addr = json_object['to'].split(',')
    body_html = json_object['msg']
    part1 = MIMEText(body_html,'html')
    msg.attach(part1)
    msg['To'] = json_object['to']
    msg['Subject'] =json_object['subject']
    msg['From'] = SENDER_EMAIL

    send_mail(msg, smtp_username, smtp_password, to_addr+cc_addr)
    return { "is_success": True}


def send_mail(email, username, password, send_to):
    with smtplib.SMTP_SSL("email-smtp.eu-west-1.amazonaws.com", 465) as server:
        server.ehlo()
        server.login(username,password)
        server.sendmail(SENDER_EMAIL, send_to, email.as_string())

def http_request(request):
    try:
        out= read_vault_key(request)
        return out
    except Exception as e:
        return {"is_success": False, "Error": str(e) }


#  origina html code:
    # <html>
    # <head></head>
    # <body>
    #     <p>Hi!<br>
    #     How are you?<br>
    #     Here is the <a href="http://www.python.org">link</a> you wanted.
    #     </p>
    # </body>
    # </html>
# html passed on json
# <html>
# <head> <\/head>
# <body>
# <p>
# Hi!
# <br>How are you?
# <br>Here is the link for python <a href=\"http:\/\/www.pytho.org\"> link <\/a> you wanted.
# <\/p>
# <\/body>
# <\/html>


#  https://thorntech.com/4-things-you-must-do-when-putting-html-in-json/

# {"msg":"<html><head><\/head><body><p>Hi!<br>How are you?<br>Here is the link for python <a href=\"http:\/\/www.pytho.org\">link<\/a> you wanted.<\/p><\/body><\/html>","subject":"Alert from Dtwin","to" :"gehad.abdelalim@vodafone.com"}