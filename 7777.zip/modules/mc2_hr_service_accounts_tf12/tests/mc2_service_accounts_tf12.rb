def run_mc2_service_accounts_tf12(params)
    puts params
    config     = params['config']
    variables  = params['variables'] 
    service_account_list = []
    variables["additional_local_markets"].each do |local_market|
        variables["tenant_sub_stages"].each do |subnet|
            service_account_list.push("vf-#{local_market.downcase}-mc2-#{subnet}-dp-#{subnet == "dev" || subnet == "qa" ? "ds" : "ops"}-sa@#{config["project_id"]}.iam.gserviceaccount.com")
            service_account_list.push("vf-#{local_market.downcase}-mc2-#{subnet}-df-#{subnet == "dev" || subnet == "qa" ? "ds" : "ops"}-sa@#{config["project_id"]}.iam.gserviceaccount.com")
        end
    end

    control "MC2 Service acounts test" do
        service_account_list.each do |sa|
            describe google_service_account(project: config["project_id"], name: sa) do
                it { should exist }
            end
        end
    end

    control "MC2 Service acounts roles test" do
        variables["dataproc_roles"].each do |role| 
            describe google_project_iam_binding(project: config["project_id"], role: role) do
                it { should exist }
                dp_list = service_account_list.grep(/dp/).map { |string| "serviceAccount:"+string }
                dp_list.each do |sa|
                    its('members') { should include sa }
                end
            end
        end 
        variables["dataflow_roles"].each do |role| 
            describe google_project_iam_binding(project: config["project_id"], role: role) do
                it { should exist }
                dp_list = service_account_list.grep(/df/).map { |string| "serviceAccount:"+string }
                dp_list.each do |sa|
                    its('members') { should include sa }
                end
            end
        end 
    end

end