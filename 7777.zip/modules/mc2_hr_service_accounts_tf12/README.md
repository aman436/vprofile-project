MC2 service accounts module
===========

This module creates all the necessary Services Accounts for an MC2 project based on Ticket request ex. OPS or DS or both

Module Input Variables:
-----------------------

- `additional_local_markets` -optional- A list of local markets to deploy either a solo LM project or a grp project only the local markets are needed. defaults to an empty set [ro, es, etc...]
- `require_additional_sa_role:` -Optional-  defaults to `false`.

Usage:
------

```yaml
- name: mc2_service_accounts
  additional_local_markets: 
  - gr
  - cz
  - ro
```


Outputs
-------

 - `all_service_accounts` - Outputs the all service accounts as a map.

Example usage for GRP project:
------------------------------

```
general:
  ss_suffix: nonlive
  tf_version: 0.13.2
  neuron_gcp_platform_version: 1.6.18
  composer_image_version: composer-1.13.0-airflow-1.10.10
  pypi_packages:
    google-api-core:        ==1.16.0
    google-cloud-core:      ==1.3.0
    google-cloud-datastore: ==1.12.0
    mysql-connector-python: ==8.0.20
metadata:
 stage: nonlive
 tenant: grp
 program: mc2dev
modules:
  - name: terraform_provider_base
    google_beta_terraform_version: "3.36"
    google_terraform_version: "3.36"
  - name: tenant_cryptokey_tf12
    gcs_key: true
    bq_key: true
  - name: dev_environment_tf12
    require_composer: "0"
    composer_additional_sa_iam_roles:
      - "roles/datafusion.viewer"
      - "roles/pubsub.editor" 
  - name: tenant_core_tf12
    vpc_name: nonlive
    dataproc_policy_enabled: 1
  - name: mc2_service_accounts
    additional_local_markets: 
    - cz
    - gr
    - ro
```

service account ids that is created for the example:
-------

```
"projects/vf-mc2dev-ca-live/serviceAccounts/vf-cz-mc2-dev-dp-ds-sa@vf-mc2dev-ca-live.iam.gserviceaccount.com"
"projects/vf-mc2dev-ca-live/serviceAccounts/vf-gr-mc2-qa-dp-ds-sa@vf-mc2dev-ca-live.iam.gserviceaccount.com"
"projects/vf-mc2dev-ca-live/serviceAccounts/vf-ro-mc2-dev-dp-ds-sa@vf-mc2dev-ca-live.iam.gserviceaccount.com"
"projects/vf-mc2dev-ca-live/serviceAccounts/vf-ro-mc2-preprod-dp-ops-sa@vf-mc2dev-ca-live.iam.gserviceaccount.com"
"projects/vf-mc2dev-ca-live/serviceAccounts/vf-ro-mc2-qa-dp-ds-sa@vf-mc2dev-ca-live.iam.gserviceaccount.com"
"projects/vf-mc2dev-ca-live/serviceAccounts/vf-cz-mc2-preprod-dp-ops-sa@vf-mc2dev-ca-live.iam.gserviceaccount.com"
"projects/vf-mc2dev-ca-live/serviceAccounts/vf-cz-mc2-qa-dp-ds-sa@vf-mc2dev-ca-live.iam.gserviceaccount.com"
"projects/vf-mc2dev-ca-live/serviceAccounts/vf-gr-mc2-dev-dp-ds-sa@vf-mc2dev-ca-live.iam.gserviceaccount.com"
"projects/vf-mc2dev-ca-live/serviceAccounts/vf-gr-mc2-preprod-dp-ops-sa@vf-mc2dev-ca-live.iam.gserviceaccount.com"
```

and created roles for each service account