#!/usr/bin/python
import subprocess
import re 

prjectID = "vf-mc2dev-ca-live"

with open('project_id.txt', 'r') as file:
    prjectID = file.read().replace('\n', '')

def get_all_modules(module_name):
    moudules = subprocess.check_output(['terraform', 'state', 'list', module_name], stderr=subprocess.STDOUT)
    moudules_list = moudules.split("\n")
    moudules_list = filter(None, moudules_list)
    return moudules_list

def replace_module(old_module,new_module,id):
    subprocess.check_output(['terraform', 'state', 'rm', old_module], stderr=subprocess.STDOUT)
    subprocess.check_output(['terraform', 'import', new_module, id], stderr=subprocess.STDOUT)

def get_value_from_text(text,key):
    return re.search(r'\".+\"',re.search(r'' + key + '.+= \".+\"',text).group(0)).group(0).replace("\"","")

def state_file_backup():
    tfstate = subprocess.check_output(['terraform', 'state', 'pull'], stderr=subprocess.STDOUT)  # Pulling the current state file from remote storage.
    with open("tfstate_backup.txt", "w") as tfstate_backup:
        tfstate_backup.write(tfstate)
    print('\033[92m' + u"\u2714 " + " Tfstate backup successfull target/main/tfstate_backup.txt" + '\033[0m')


def state_file_fallback():
    try:
        subprocess.check_output(['terraform', 'state', 'push', 'tfstate_backup.txt'], stderr=subprocess.STDOUT)  # Push the old state file back to remote storage.
    except subprocess.CalledProcessError as e:
        print("state file didn't fallback to original so we panik")
        print(e.output)


# take buckup 
state_file_backup()

#get all service accounts 
service_accounts_list = get_all_modules('module.dev_environment.google_service_account.additional-roles')
idx = 0
for sa in service_accounts_list:

    # replace old module with new module 
    service_account_name = sa.split("[")
    module_name = service_account_name[0].replace("dev_environment","mc2_service_accounts")
    module_name = module_name.replace("additional-roles","service_accounts")
    
    # move the old moudle to the new module 
    try:
        subprocess.check_output(['terraform', 'state', 'mv', sa, module_name+"["+str(idx)+"]"], stderr=subprocess.STDOUT)    
        print('\033[92m' + "service account no " + str(idx) + " imported succesfuly" + '\033[0m')
    except subprocess.CalledProcessError as e:
        state_file_fallback()
        print('\033[91m' + " service account no " + str(idx) + " import failed" + '\033[0m')
        print('\033[91m' + e.output + '\033[0m')
    idx = idx + 1 

#get all composer custom service accounts 
composer_custom_sa_list = get_all_modules('module.dev_environment.google_service_account_iam_member.composer-custom-sa-serviceAccountUser')
idx = 0
for composer_sa in composer_custom_sa_list:

    # get data of the Service account
    composer_sa_data = subprocess.check_output(['terraform', 'state', 'show', composer_sa], stderr=subprocess.STDOUT)

    # get service_account_id, role and memmber from composer service acount data
    service_account_id = get_value_from_text(composer_sa_data,'service_account_id')
    role = get_value_from_text(composer_sa_data,'role') 
    member = get_value_from_text(composer_sa_data,'member')

    full_id = service_account_id + " " + role + " " + member

    # replace old module with new module 
    module_name = composer_sa.replace("dev_environment","mc2_service_accounts")

    # Removing the old module and importing the new one
    try:
        replace_module(composer_sa,module_name,full_id)
        print('\033[92m' + "custom service account no " + str(idx) + " imported succesfuly" + '\033[0m')
    except subprocess.CalledProcessError as e:
        state_file_fallback()
        print('\033[91m' + "custom service account no " + str(idx) + " import failed" + '\033[0m')
        print('\033[91m' + e.output + '\033[0m')
    idx = idx + 1 
        
# get all roles
roles_list = get_all_modules('module.dev_environment.google_project_iam_member.additional-roles-permissions')
idx = 0
for sa_role in roles_list:

    # get the data of the SA role
    role_data = subprocess.check_output(['terraform', 'state', 'show', sa_role], stderr=subprocess.STDOUT)

    # get role and member from the role data
    role = get_value_from_text(role_data,'role')
    member = get_value_from_text(role_data,'member')

    full_id = prjectID + " " + role + " " + member

    # replace old module with new module 
    module_name = sa_role.replace("dev_environment","mc2_service_accounts")
    module_name = module_name.replace("additional-roles-permissions","service_accounts_roles")
    
    # Removing the old module and importing the new one
    try:
        replace_module(sa_role,module_name,full_id)
        print('\033[92m' + "role no " + str(idx) + " imported succesfuly" + '\033[0m')
    except subprocess.CalledProcessError as e:
        state_file_fallback()
        print('\033[91m' + "role no " + str(idx) + " import failed" + '\033[0m')
        print('\033[91m' + e.output + '\033[0m')
    idx = idx + 1 

        