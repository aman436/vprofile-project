#!/bin/bash 

METADATA_URL=http://metadata.google.internal/computeMetadata/v1/instance/attributes

fetch_metadata () {
    curl -f "$METADATA_URL/$1" -H "Metadata-Flavor: Google" || exit 1
}

install-grb () {
    echo "Installing"
    mkdir -p /opt/gurobi || exit 1
    wget -v https://packages.gurobi.com/${GRB_SHORT_VERSION}/gurobi${GRB_VERSION}_linux64.tar.gz || exit 1
    tar -xvf gurobi${GRB_VERSION}_linux64.tar.gz || exit 1
    rm -f gurobi${GRB_VERSION}_linux64.tar.gz || exit 1
    rm -rf /opt/gurobi/linux64 || exit 1
    cp -r gurobi*/linux64 /opt/gurobi/linux64 || exit 1
    rm -rf gurobi* || exit 1
    echo "Installation Completed"
}

load_variables () {
    GRB_VERSION=$(fetch_metadata GRB_VERSION)
    GRB_SHORT_VERSION=$(fetch_metadata GRB_SHORT_VERSION)
    GRB_MAJOR_VERSION=$(echo $GRB_VERSION | cut -d. -f1)

    GRB_CURRENT_VERSION=$(/opt/gurobi/linux64/bin/grb_ts --version | grep -Po '(?<=Gurobi Token Server version )[^;]+' || exit 1)
    GRB_CURRENT_MAJOR_VERSION=$(echo $GRB_CURRENT_VERSION | cut -d. -f1)
    GRB_LICENSE_VERSION=$(grep -Po '(?<=VERSION\=)[^;]+' < /opt/gurobi/gurobi.lic || exit 1)
}

watch_for_version_changes() {
    cat >/tmp/reload_version.sh <<"EOF"
#!/bin/bash
while true; do
  sleep 10

  METADATA_URL=http://metadata.google.internal/computeMetadata/v1/instance/attributes
  fetch_metadata () {
      curl -f "$METADATA_URL/$1" -H "Metadata-Flavor: Google" || exit 1
  }
  
  GRB_VERSION=$(fetch_metadata GRB_VERSION)
  GRB_CURRENT_VERSION=$(/opt/gurobi/linux64/bin/grb_ts --version | grep -Po '(?<=Gurobi Token Server version )[^;]+' || exit 1)
  if [[ $GRB_CURRENT_VERSION != $GRB_VERSION ]]; then
    echo "Target Version Changed from $GRB_CURRENT_VERSION to $GRB_VERSION"
    reboot
  fi
done
EOF
    chmod +x /tmp/reload_version.sh
    nohup bash -c "/tmp/reload_version.sh" &
}

load_variables

if [[ $GRB_CURRENT_VERSION == $GRB_VERSION ]]; then
    echo "Target Version Installed"
else
    echo "Target Version not Installed"
    install-grb
fi

watch_for_version_changes

load_variables

if [[ $GRB_LICENSE_VERSION == $GRB_CURRENT_MAJOR_VERSION ]]; then
    echo "License Version matches the installed version"
    echo "Launching The Token Server"
    /opt/gurobi/linux64/bin/grb_ts -v
elif  [[ -z $GRB_LICENSE_VERSION ]]; then
    echo "No License Found"
    echo "Please install the license"
else
    echo "License Version doesn't match the installed version"
    echo "Please re-install the license"
fi
