# frozen_string_literal: true

def run_gce_deployment_vm_tf12(params)

  config     = params['config']
  variables  = params['variables']

  control "google_compute_instance::projects/#{config['project_id']}/zones/#{variables['zone']}/instances/#{variables['vm_name']}" do
    title "correctly configured"
    impact 1.0
    describe google_compute_instance({:project=>"#{config['project_id']}", :zone=>"#{variables['zone']}", :name=>"#{variables['vm_name']}"}) do
      it { should exist }
      its("name") { should cmp "#{variables['vm_name']}" }
      its("hostname") { should be_nil.or cmp "" }
      its("status") { should cmp "RUNNING" }
      its('disk_count') {should eq 1 }
      its("cpu_platform") { should include "Intel" }
      its('machine_type') { should match "#{variables['machine_type']}" }
      its("scheduling.automatic_restart") { should cmp true }
      its("scheduling.on_host_maintenance") { should cmp "MIGRATE" }
      its("scheduling.preemptible") { should cmp false }
      its('network_interfaces_count') {should eq 1 }
      its('can_ip_forward') { should be false }
      its('service_account_scopes') { should cmp ["https://www.googleapis.com/auth/cloud-platform"] }
      its('zone') { should include "#{variables['zone']}" }      
    end
    describe google_compute_instance({:project=>"#{config['project_id']}", :zone=>"#{variables['zone']}", :name=>"#{variables['vm_name']}"}).label_value_by_key('zone') do
      it { should cmp "management-zone" }
    end
    describe google_compute_instance({:project=>"#{config['project_id']}", :zone=>"#{variables['zone']}", :name=>"#{variables['vm_name']}"}).metadata_value_by_key('enable-oslogin') do
      it { should cmp "TRUE" }
    end
    describe google_compute_disk({:project=>"#{config['project_id']}", :zone=>"#{variables['zone']}", :name=>"#{variables['vm_name']}"}) do
      it { should exist }
      its('source_image') { should cmp "#{variables['image_id']}" }
    end
  end

  control "google_service_account::projects/#{config['project_id']}/serviceAccounts/#{variables['service_account']}@#{config['project_id']}.iam.gserviceaccount.com" do
    title "correctly configured"
    impact 1.0
    describe google_service_account({:project=>"#{config['project_id']}", :name=>"#{variables['service_account']}@#{config['project_id']}.iam.gserviceaccount.com"}) do
      it { should exist }
      its("name") { should cmp "projects/#{config['project_id']}/serviceAccounts/#{variables['service_account']}@#{config['project_id']}.iam.gserviceaccount.com" }
      its("email") { should cmp "#{variables['service_account']}@#{config['project_id']}.iam.gserviceaccount.com" }
    end
  end

  control "google_compute_firewall::projects/#{config['project_id']}/global/firewalls/allow-bif-ssh-from-management-zone" do
    title "correctly configured"
    impact 1.0
    describe google_compute_firewall({:project=>"#{config['project_id']}", :name=>"allow-bif-ssh-from-management-zone"}) do
      it { should exist }
      its("name") { should cmp "allow-bif-ssh-from-management-zone" }
      its("description") { should be_nil.or cmp "" }
      its("destination_ranges") { should be_nil }
      its("direction") { should cmp "INGRESS" }
      its('log_config.enable_logging') { should be true }
      its("priority") { should cmp 1000 }
      its("source_service_accounts") { should be_nil }
      its("source_tags") { should be_nil }
      its("target_service_accounts") { should cmp ["#{variables['service_account']}@#{config['project_id']}.iam.gserviceaccount.com"] }
      its("target_tags") { should be_nil }
    end
  end

  control "google_compute_firewall::projects/#{config['project_id']}/global/firewalls/allow-connection-to-cloud-sql" do
    title "correctly configured"
    impact 1.0
    describe google_compute_firewall({:project=>"#{config['project_id']}", :name=>"allow-connection-to-cloud-sql"}) do
      it { should exist }
      its("name") { should cmp "allow-connection-to-cloud-sql" }
      its("description") { should be_nil.or cmp "" }
      its("direction") { should cmp "EGRESS" }
      its('log_config.enable_logging') { should be true }
      its("priority") { should cmp 1000 }
      its("source_ranges") { should be_nil }
      its("source_service_accounts") { should be_nil }
      its("source_tags") { should be_nil }
      its("target_service_accounts") { should cmp ["#{variables['service_account']}@#{config['project_id']}.iam.gserviceaccount.com"] }
      its("target_tags") { should be_nil }
    end
  end  

  control "google_compute_firewall::projects/#{config['project_id']}/global/firewalls/deny-all-to-internet" do
    title "correctly configured"
    impact 1.0
    describe google_compute_firewall({:project=>"#{config['project_id']}", :name=>"deny-all-to-internet"}) do
      it { should exist }
      its("name") { should cmp "deny-all-to-internet" }      
      its("description") { should be_nil.or cmp "" }
      its("destination_ranges") { should cmp ["0.0.0.0/0"] }
      its("direction") { should cmp "EGRESS" }
      its('log_config.enable_logging') { should be true }
      its("priority") { should cmp 1100 }
      its("source_ranges") { should be_nil }
      its("source_service_accounts") { should be_nil }
      its("source_tags") { should be_nil }
      its("target_service_accounts") { should cmp ["#{variables['service_account']}@#{config['project_id']}.iam.gserviceaccount.com"] }
      its("target_tags") { should be_nil }
    end
  end  

  control "google_compute_firewall::projects/#{config['project_id']}/global/firewalls/allow-management-to-github-egress" do
    title "correctly configured"
    impact 1.0
    describe google_compute_firewall({:project=>"#{config['project_id']}", :name=>"allow-management-to-github-egress"}) do
      it { should exist }
      its("name") { should cmp "allow-management-to-github-egress" }
      its("description") { should be_nil.or cmp "" }
      #CHECK_GITHUB_IP
      #Module not used anywhere
      #Private IP below, will it be ever hit from GCP?
      its("destination_ranges") { should cmp ["195.233.144.145/32"] }
      its("direction") { should cmp "EGRESS" }
      its('log_config.enable_logging') { should be true }
      its("priority") { should cmp 1000 }
      its("source_ranges") { should be_nil }
      its("source_service_accounts") { should be_nil }
      its("source_tags") { should be_nil }
      its("target_service_accounts") { should be_nil }
      its("target_tags") { should cmp ["management"] }
    end
  end  

  control "google_compute_firewall::projects/#{config['project_id']}/global/firewalls/allow-management-to-gcpapi-egress" do
    title "correctly configured"
    impact 1.0
    describe google_compute_firewall({:project=>"#{config['project_id']}", :name=>"allow-management-to-gcpapi-egress"}) do
      it { should exist }
      its("name") { should cmp "allow-management-to-gcpapi-egress" }
      its("description") { should be_nil.or cmp "" }
      its("direction") { should cmp "EGRESS" }
      its('log_config.enable_logging') { should be true }
      its("priority") { should cmp 1000 }
      its("source_ranges") { should be_nil }
      its("source_service_accounts") { should be_nil }
      its("source_tags") { should be_nil }
      its("target_service_accounts") { should be_nil }
      its("target_tags") { should cmp ["management"] }
      variables['gcpapi_ips'].each do |api_ip|
        its("destination_ranges") { should include "#{api_ip}" }
      end
    end
  end
end
