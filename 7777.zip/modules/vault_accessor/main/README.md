# Neuron EDS vault accessor module
This is a duplicate of Neuron EDS vault accessor module
Duplicate is needed as the Neuron EDS vault accessor module uses this to create the composer service account permission in this module.

Required action to chase the EDS team to move the composer access out so that only one module is used

