from templater.main.JinjaTemplate import JinjaTemplate
from modules.datahub_v2_tf12.main.DatahubTemplater import DatahubTemplater
from modules.datahub_v2_tf12.main.datahub_types import ProjectDetails, StoragePermissions, GoogleMemberResourceId, \
    GoogleDataSetResource
import unittest
import logging
import os


class TestDatahubTemplaterV2(unittest.TestCase):
    def __init__(self, *args, **kwargs):
        super(TestDatahubTemplaterV2, self).__init__(*args, **kwargs)
        logging.basicConfig(level=logging.CRITICAL)
        self.maxDiff = None
        self.DT = DatahubTemplater(
            jinja_template_class=JinjaTemplate(
                template_path="resources/templates", template_file_ex=".tf.j2"
            )
        )

    def test_dataset_access(self):
        project_detail = ProjectDetails(project_id='foo', project_name='bar', tenant='baz', location='EU',
                                        project_suffix=None, disable_bucket_logging=None, uniform_bucket_level_access="bucket_policy_only")
        permissions = StoragePermissions(
            readers=[GoogleMemberResourceId(member_id='group:gcp-vf-it-puz-de-bq-lab@vodafone.com', role=None),
                     ],
            writers=[
                GoogleMemberResourceId(
                    member_id='serviceAccount:vf-it-puz-proda-df-ops-sa@vf-it-puz-live.iam.gserviceaccount.com',
                    role=None)
            ],
            owners=[
                GoogleMemberResourceId(member_id='group:gcp-vf-it-puz-ops-bq@vodafone.com')
            ]
        )
        dataset = GoogleDataSetResource(name="dataset_name", key_type=None, location="EU", domain=None, ds_type=None,
                                        expiration=None, partition_expiration=None, authorized_views=['vf-it-foo.bar.view'])

        accesses = self.DT.make_bigquery_accesses(project_details=project_detail, dataset=dataset, permissions=permissions)
        expected = [
            {'member': 'gcp-vf-it-puz-ops-bq@vodafone.com', 'role': 'OWNER', 'group': 'True'},
            {'member': 'vf-it-puz-proda-df-ops-sa@vf-it-puz-live.iam.gserviceaccount.com', 'role': 'WRITER'},
            {'member': 'gcp-vf-it-puz-de-bq-lab@vodafone.com', 'role': 'READER', 'group': 'True'},
            {'view': {
                "project_id": "vf-it-foo",
                "dataset_id": "bar",
                "table_id": "view"
            }
            },
        ]

        self.assertListEqual(accesses, expected)

    def test_biquery_access_template(self):
        project_detail = ProjectDetails(project_id='foo', project_name='bar', tenant='baz', location='EU',
                                        project_suffix=None, disable_bucket_logging=None, uniform_bucket_level_access="bucket_policy_only")
        permissions = StoragePermissions(
            readers=[GoogleMemberResourceId(member_id='group:gcp-vf-it-puz-de-bq-lab@vodafone.com', role=None),
                     ],
            writers=[
                GoogleMemberResourceId(
                    member_id='serviceAccount:vf-it-puz-proda-df-ops-sa@vf-it-puz-live.iam.gserviceaccount.com',
                    role=None)
            ],
            owners=[
                GoogleMemberResourceId(member_id='group:gcp-vf-it-puz-ops-bq@vodafone.com')
            ]
        )
        dataset = GoogleDataSetResource(name="dataset_name", key_type=None, location="EU", domain=None, ds_type=None,
                                        expiration=None, partition_expiration=None, authorized_views=['vf-it-foo.bar.view'])

        template = self.DT.add_bigquery_dataset(project_details=project_detail, dataset=dataset,
                                                permissions=permissions)

        expected = """# Create dataset "dataset_name"

resource "google_bigquery_dataset" "vfbaz_dh_lake_dataset_name_s" {
  dataset_id = "vfbaz_dh_lake_dataset_name_s"
  project = "foo"
  location = "EU"
  

  

  # Dataset needs owner privileges or can't create dataset
  access {
    role          = "OWNER"
    special_group = "projectOwners"
  }

  
  access {
    role          = "OWNER"
    group_by_email= "gcp-vf-it-puz-ops-bq@vodafone.com"
  }
  
  access {
    role          = "WRITER"
    user_by_email= "vf-it-puz-proda-df-ops-sa@vf-it-puz-live.iam.gserviceaccount.com"
  }
  
  access {
    role          = "READER"
    group_by_email= "gcp-vf-it-puz-de-bq-lab@vodafone.com"
  }
  
  access {
    view {
        project_id      = "vf-it-foo"
        dataset_id      = "bar"
        table_id        = "view"
    }
  }
  

  default_encryption_configuration {
      kms_key_name = data.terraform_remote_state.CMEK_key_data.outputs.None_key_name
  }
}


"""

        self.assertEqual(template, expected)
