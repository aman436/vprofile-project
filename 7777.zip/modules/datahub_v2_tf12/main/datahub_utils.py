import re
import copy
import yaml
import os
import json
import deepmerge

from modules.datahub_v2_tf12.main.datahub_types import ConfigurationFile


def normalize_resource_name(name: str):
    replaced = name.replace("-", "_").replace(" ", "").replace(".", "_").lower()
    out = re.sub("[^A-Za-z0-9_]+", "_", replaced)
    return out


def merge_service_configs(config: ConfigurationFile) -> ConfigurationFile:
    new_config = copy.deepcopy(config)
    for service_file in new_config["service_list"]:
        path = f"modules/datahub_v2_tf12/main/service_configuration/{service_file}.yml"
        file = open(path)
        service_config = yaml.load(file, Loader=yaml.FullLoader)

        # This hack fixes yaml's &anchor *references being edited by deepmerger.
        # Don't judge me. JS guys have been doing JSON.parse(JSON.stringify(x)) for ages.
        copied_service_config = json.loads(json.dumps(service_config))
        copied_new_config = json.loads(json.dumps(new_config))

        new_config = deepmerge.always_merger.merge(
            copied_new_config, copied_service_config
        )

    expand_yaml_merge_keys(new_config)

    target_path = os.environ["NEURON_TARGET_PATH"]
    with open(f"{target_path}/merged_datahub_config.yml", "w") as outfile:
        yaml.dump(new_config, outfile, default_flow_style=False)

    return new_config


def expand_yaml_merge_keys(config: dict):
    if not isinstance(config, dict):
        return

    keys = list(config.keys())
    for key in keys:
        val = config[key]
        if isinstance(val, list):
            for el in val:
                expand_yaml_merge_keys(el)

        if isinstance(val, dict):
            expand_yaml_merge_keys(val)
            if key.startswith("<<"):
                deepmerge.always_merger.merge(config, val)
                del config[key]


def merge_two_dicts(dict1: dict, dict2: dict):
    dict1 = {} if dict1 is None else dict1
    dict2 = {} if dict2 is None else dict2
    result = {**dict1, **dict2}
    return result
