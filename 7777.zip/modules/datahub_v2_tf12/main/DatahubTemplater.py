import itertools
import logging
from typing import Dict, List, Type, Tuple, Union
from dataclasses import dataclass, asdict, field
import re

from templater.main.ModulePythonTemplater import ModulePythonTemplater

from modules.datahub_v2_tf12.main.datahub_utils import (
    normalize_resource_name,
    merge_service_configs,
    merge_two_dicts
)

from modules.datahub_v2_tf12.main.datahub_types_mappings import (
    get_storage_type_details_map,
    get_service_accounts,
    get_project_details,
)

from modules.datahub_v2_tf12.main.datahub_types import (
    ConfigurationFile,
    GoogleBucketResource,
    GoogleDataSetResource,
    ProjectDetails,
    ServiceAccountResource,
    StoragePermissions,
)


class DatahubTemplater(ModulePythonTemplater):
    def run(self, config: ConfigurationFile) -> str:
        datahub_config = merge_service_configs(config)

        storage_type_details_map = get_storage_type_details_map(datahub_config)
        service_accounts = get_service_accounts(datahub_config)
        project_details = get_project_details(datahub_config)

        datahub_terraform_str = ""
        datahub_terraform_str += self.add_service_accounts(
            project_details, service_accounts
        )

        for storage_details in storage_type_details_map.values():
            if storage_details.permissions:
                # FIXME: terraform errors when we define the same bucket twice
                if storage_details.storage and storage_details.storage.buckets:
                    for bucket in storage_details.storage.buckets:
                        # merge (storage_details labels) with (bucket.labels), order is important 
                        bucket.labels = merge_two_dicts(storage_details.labels, bucket.labels)
                        datahub_terraform_str += self.add_bucket(
                            project_details, bucket, storage_details.permissions,
                        )

                if storage_details.bigquery and storage_details.bigquery.datasets:
                    for dataset in storage_details.bigquery.datasets:
                        # merge (storage_details labels) with (dataset.labels), order is important 
                        dataset.labels = merge_two_dicts(storage_details.labels, dataset.labels)
                        datahub_terraform_str += self.add_bigquery_dataset(
                            project_details, dataset, storage_details.permissions,
                        )

        return datahub_terraform_str

    def add_service_accounts(
        self,
        project_details: ProjectDetails,
        service_accounts: List[ServiceAccountResource],
    ) -> str:
        service_account_code_str: str = "# Adding Service Accounts \n"

        for service_account in service_accounts:
            service_account_code_str += self.Jinja.run_template(
                template_name="terraform_service_account_tf12",
                params={
                    "project_id": project_details.project_id,
                    "program": service_account.program,
                    "persona": service_account.sa_sub_str,
                    "project_tenant": project_details.tenant,
                    "service_account_desc": f"{service_account.sa_desc} Service Account",
                },
            )

        return f"{service_account_code_str}\n"

    def add_bucket(
        self,
        project_details: ProjectDetails,
        bucket: GoogleBucketResource,
        permissions: StoragePermissions,
    ) -> str:
        terraform_bucket_str = self.Jinja.run_template(
            template_name="terraform_bucket_tf12",
            params={
                "tenant": project_details.tenant,
                "project_id": project_details.project_id,
                "bucket_dict": asdict(bucket),
                "location": bucket.location,
                "storage_class": bucket.storage_class,
                "project_initials": "dh",
                "disable_bucket_logging": project_details.disable_bucket_logging,
                "uniform_bucket_level_access": project_details.uniform_bucket_level_access,
                "CMEK_key_type": bucket.key_type,
            },
        )

        terraform_bucket_str += self.add_bucket_permissions(
            project_details, bucket, permissions
        )

        return f"{terraform_bucket_str}\n"

    def add_bucket_permissions(
        self,
        project_details: ProjectDetails,
        bucket: GoogleBucketResource,
        permissions: StoragePermissions,
    ) -> str:
        bucket_permissions_str: str = ""

        bucket_permissions_str += f"# Creating IAM Roles for bucket: {bucket.name}\n"

        permission_role_mapping = {
            "iam": {
                "reader": ["storage.objectViewer", "storage.legacyBucketReader"],
                "writer": [
                    "storage.objectViewer",
                    "storage.legacyBucketReader",
                    "storage.objectCreator",
                    "storage.legacyBucketWriter",
                    "storage.legacyObjectOwner",
                ],
                "owner": ["storage.objectAdmin"],
            },
        }

        for member_id in permissions.get_all_members():
            member = member_id.render(project_details)
            for role in permission_role_mapping["iam"][member_id.get_role()]:
                resource_name: str = normalize_resource_name(
                    f"iam_member_{bucket.name}_{role}_{member}"
                )

                bucket_permissions_str += self.Jinja.run_template(
                    template_name="terraform_iam_member_bucket_tf12",
                    params={
                        "resource_name": resource_name,
                        "project_tenant": project_details.tenant,
                        "bucket_base_name": bucket.name,
                        "role": role,
                        "member": member,
                    },
                )

        bucket_permissions_str += "\n"
        return bucket_permissions_str

    def add_bigquery_dataset(
        self,
        project_details: ProjectDetails,
        dataset: GoogleDataSetResource,
        permissions: StoragePermissions,
    ) -> str:
        bigquery_datasets_str: str = ""

        dataset_name = normalize_resource_name(dataset.name)

        accesses = self.make_bigquery_accesses(project_details, dataset, permissions)

        bigquery_datasets_str += self.Jinja.run_template(
            template_name="terraform_bigquery_dataset_tf12",
            params={
                "name": dataset_name,
                "domain": dataset.domain,
                "type": dataset.ds_type,
                "labels": dataset.labels,
                "tenant": project_details.tenant,
                "project_id": project_details.project_id,
                "location": dataset.location,
                "CMEK_key_type": dataset.key_type,
                "accesses": accesses,
                "expiration": dataset.expiration,
                "partition_expiration": dataset.partition_expiration
            },
        )

        return f"{bigquery_datasets_str}\n"

    def make_bigquery_accesses(
        self,
        project_details: ProjectDetails,
        dataset: GoogleDataSetResource,
        permissions: StoragePermissions,
    ) -> list:
        permission_role_mapping = {
            "reader": "READER",
            "writer": "WRITER",
            "owner": "OWNER",
            "restrictedreader": "organizations/352790554748/roles/BigQueryViewerNoExport",
        }

        accesses = []
        for member_id in permissions.get_all_members():
            access = {
                "member": member_id.render(project_details),
                "role": permission_role_mapping[member_id.get_role()],
            }

            if "group:" in access["member"]:
                access["group"] = "True"

            access["member"] = re.sub(r"^\w+:", "", access["member"])
            accesses.append(access)

        for authorized_view in dataset.get_authorized_views():
            access = {
                "view": {
                    "project_id": authorized_view.project_id,
                    "dataset_id": authorized_view.dataset_id,
                    "table_id": authorized_view.table_id
                }
            }
            accesses.append(access)

        return accesses
