import re
import logging

from dataclasses import dataclass, asdict, field
from typing import Dict, List, Type, Tuple, Union, Optional


@dataclass
class ProjectDetails:
    project_id: str
    project_name: str
    tenant: str
    location: str
    project_suffix: Optional[str]
    disable_bucket_logging: Optional[str]
    uniform_bucket_level_access: Optional[str]


@dataclass
class GoogleBucketResourceLifecycleRule:
    action: str
    conditions: Dict[str, Union[str, int]]


@dataclass
class GoogleBucketResource:
    name: str
    key_type: Optional[str]
    location: Optional[str]
    versioning: Optional[str]
    disable_bucket_logging: Optional[str]
    uniform_bucket_level_access: Optional[str]
    storage_class: Optional[str]
    lifecycle_rules: Optional[List[GoogleBucketResourceLifecycleRule]]
    labels: Optional[dict]


@dataclass
class ServiceAccountResource:
    program: str
    sa_sub_str: str
    sa_desc: str


@dataclass
class GoogleMemberResourceId:
    member_id: str
    role: Optional[str] = ""

    def __post_init__(self):
        if "@" not in self.member_id:
            raise Exception("@ is expected in Google Member identifier")

        # TODO more checks

    def __eq__(self, other):
        return self.member_id == other.member_id

    def get_role(self) -> str:
        if not self.role:
            raise Exception("Google Member ID role not known")

        return self.role

    def render(self, project: ProjectDetails) -> str:
        dashed_suffix = ""
        if project.project_suffix:
            dashed_suffix = f"-{project.project_suffix}"

        rendred = self.member_id.format(tenant=project.tenant, suffix=dashed_suffix)
        return rendred


@dataclass
class AuthorizedView:
    project_id: str
    dataset_id: str
    table_id: str


@dataclass
class StoragePermissions:
    readers: Optional[List[GoogleMemberResourceId]] = None
    writers: Optional[List[GoogleMemberResourceId]] = None
    owners: Optional[List[GoogleMemberResourceId]] = None
    restrictedreaders: Optional[List[GoogleMemberResourceId]] = None

    def get_all_members(self) -> List[GoogleMemberResourceId]:
        members: List[GoogleMemberResourceId] = []
        if self.owners:
            for member in self.owners:
                if member not in members:
                    member.role = "owner"
                    members.append(member)
        if self.writers:
            for member in self.writers:
                if member not in members:
                    member.role = "writer"
                    members.append(member)
        if self.readers:
            for member in self.readers:
                if member not in members:
                    member.role = "reader"
                    members.append(member)
        if self.restrictedreaders:
            for member in self.restrictedreaders:
                if member not in members:
                    member.role = "restrictedreader"
                    members.append(member)
        return members


@dataclass
class GoogleStorageResource:
    buckets: Optional[List[GoogleBucketResource]] = None
    key_type: str = "base"

    def __post_init__(self):
        if not self.buckets:
            self.buckets = []


@dataclass
class GoogleDataSetResource:
    name: str
    key_type: Optional[str]
    location: Optional[str]
    labels: Optional[dict]
    domain: Optional[str]
    ds_type: Optional[str]
    expiration: Optional[int]
    partition_expiration: Optional[int]
    authorized_views: Optional[List[str]] = None

    def __post_init__(self):
        allowed_domains = ["lake", "edw", "model", "explore", "mart"]
        allowed_types = ["s", "v"]

        normalized_name = self.name.replace("-", "_")

        expected_template = r"^([a-zA-Z0-9]+)_([\w-]+)_(\w)$"
        matches = re.match(expected_template, normalized_name)

        if not matches:
            logging.error(
                f"Dataset name should start with one of {allowed_domains} and end with one of {allowed_types}. Please change '{self.name}' to: 'lake_{normalized_name}_s'. For more context visit: https://confluence.sp.vodafone.com/pages/viewpage.action?spaceKey=BDPL&title=Big+Query+Design"
            )
            self.domain = "lake"
            self.ds_type = "s"
            return

        domain = matches.group(1)
        name = matches.group(2)
        ds_type = matches.group(3)

        if domain not in allowed_domains:
            msg = f"{domain} is not an allowed domain for a dataset: {self.name}. Should be one of: {allowed_domains}"
            raise Exception(msg)

        if ds_type not in allowed_types:
            msg = f"{ds_type} is not an allowed type for a dataset: {self.name}. Should be one of: {allowed_types}"
            raise Exception(msg)

        if self.authorized_views:
            list(self.parse_authorized_view(view) for view in self.authorized_views)

        self.name = name
        self.ds_type = ds_type
        self.domain = domain

    def parse_authorized_view(self, view_name: str) -> AuthorizedView:
        view = view_name.split('.')
        if len(view) != 3:
            msg = f"{view_name} is not an allowed fully qualified view name. Should be like PROJECT_ID.DATASET_ID.VIEW_NAME"
            raise Exception(msg)
        return AuthorizedView(view[0], view[1], view[2])

    def get_authorized_views(self) -> List[AuthorizedView]:
        if self.authorized_views:
            return [self.parse_authorized_view(view) for view in self.authorized_views]
        else:
            return []


@dataclass
class GoogleBigQueryResource:
    datasets: Optional[List[GoogleDataSetResource]] = None
    key_type: str = "bq"

    def __post_init__(self):
        if not self.datasets:
            self.datasets = []


@dataclass
class StorageTypeDetails:
    labels: Optional[dict]
    permissions: Optional[StoragePermissions] = None
    bigquery: Optional[GoogleBigQueryResource] = None
    storage: Optional[GoogleStorageResource] = None


ConfigurationFile = dict

StorageTypesMap = Dict[str, StorageTypeDetails]
