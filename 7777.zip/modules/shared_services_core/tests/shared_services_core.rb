# frozen_string_literal: true

def run_shared_services_core(params)
  project_id = params['config']['project_id']
  control "#{project_id} : shared_services_core : " do
    title 'shared_services_core setup correctly'
    impact 0.4
  end
end
