#!/bin/bash -xe

enable_trend() {
  echo "Resetting trend.."
  /opt/ds_agent/dsa_control -r
  echo "Activating trend.."
  echo "TREND_ACTIVIATION_URL="$TREND_ACTIVIATION_URL
  echo "TREND_TENANT_ID="$TREND_TENANT_ID
  echo "TREND_POLICY_ID="$TREND_POLICY_ID
  /opt/ds_agent/dsa_control -a $TREND_ACTIVIATION_URL $TREND_TENANT_ID $TREND_POLICY_ID
  echo "Trend Activation complete."
}

###################################
# Main body of script starts here #
###################################
echo "Start of script..."
echo "Enable trend ?"$ENABLE_TREND

if [ "$ENABLE_TREND" = true ]; then
  enable_trend
fi

echo "Complete."
