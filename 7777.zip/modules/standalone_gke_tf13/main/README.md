This module creates a GKE cluster in:
- a new dedicated VPC 
- single subnet with a NAT gateway.

The outbound connectivity is locked by firewall rule with DENY 0.0.0.0/0.
All custom outbound connectivity needs to be whitelisted with new firewall rules.

For GKE access you should use a public endpoint from authorized networks. 
Use the `authorized_networks` parameter to configure them. 
It's best used with `vodafone_security_policy_tf12` module's output variable: `authorized_networks`