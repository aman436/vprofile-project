# Tenant vault networking module

This module creates all the necessary dns records and firewall rules required for projects to communicate with vault. it will also whitelist the beta or zeta vault based automatically.

https://confluence.sp.vodafone.com/pages/viewpage.action?pageId=202648914

## Resources created by this module
1. google_dns_managed_zone 
1. google_dns_record_set: an A record for vault ip
1. google_compute_firewall: allows egrees on port 443

## How to use this module:

<br>

```yaml
modules:
  - name: tenant_vault_networking_tf12
```

## How to use this module:
 this module is a replacment for the module called private_dns_zone_tf12 in which we can create a dns record in general
 but this module is different in the sense that it creates the records to allow the vault only and the firewall rules needed as well.

 ## PR 
 https://github.vodafone.com/VFGroup-CloudAnalytics/neuron-gcp-platform/pull/1335