#!/usr/bin/python
import subprocess

try:
    result = subprocess.check_output(['terraform', 'state', 'list', 'module.tenant_compute_bucket_tf12'], stderr=subprocess.STDOUT)  # Selecting all resources in state file with the old buckets module
    old_modules = result.split("\n")  # Making a list of the output string
    old_modules = filter(None, old_modules)  # Removing empty entries in the list
except subprocess.CalledProcessError as e:
    print('\033[91m' + u"\u2718" + " Module has no resources in state file." + '\033[0m')
    print('\033[91m' + e.output + '\033[0m')

for module in old_modules:
    bucket_module_name = module.split("[")
    new_bucket_module_name = bucket_module_name[1].replace("\'","")
    final_bucket_module_name = new_bucket_module_name.replace("]","")
    final_bucket_module_name = final_bucket_module_name.replace("\"","")
    splitted_module_name = final_bucket_module_name.split("-")
    lm = splitted_module_name[2]
    bucket_name = splitted_module_name[4]+"_"+splitted_module_name[5]
    new_module_id = "module.mc2_buckets_tf12.google_storage_bucket." + bucket_name + "[\"" + lm + "\"]"
    try:
        subprocess.check_output(['terraform', 'state', 'mv', module, new_module_id], stderr=subprocess.STDOUT)
        print('\033[92m' + u"\u2714 " + new_module_id + " changed succesfuly." + '\033[0m')
    except subprocess.CalledProcessError as e:
        print('\033[91m' + u"\u2718 " + new_module_id + " change failed." + '\033[0m')
        print('\033[91m' + e.output + '\033[0m')
