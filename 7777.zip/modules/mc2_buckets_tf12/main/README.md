# MC2 Buckets Module

This module creates all the necessary buckets for an MC2 project based on this confulence page

https://confluence.sp.vodafone.com/display/NM/MC2+Storage+Overview

### Module Input Variables:

- `additional_local_markets`: -Optional- A list of additional local markets (used in a project with multiple local markets). Defaults to an empty list.
- `location`: -Optional- A GCP location for the buckets. Defaults to `europe-west1`.
- `key_id`: -Optional- The key id required for encryption. It defaults to 'module.tenant_cryptokey_tf12.tenant_cmek-gcs'.
- `force_destroy`: -Optional- When deleting a bucket, this boolean option will delete all contained objects. If you try to delete a bucket that contains objects, Terraform will fail that run. Default is `true`.
- `versioning`: -Optional- While set to the default `true`, versioning is fully enabled for the bucket.

### What the Module does:

The module will create all required buckets for the tenant only if tenant is not `grp`. Otherwise it will create all buckets required for the `additional_local_markets` list.
The following section shows how to use this module in a `grp` project or a tenant project (`es`).

In nonlive projects all four buckets below will be created. In live projects only the `temp-aa` and `temp-etl` buckets are created. 

- `name` = "vf-{program}-{lm}-{stage}-temp-etl" & `lifecycle_rule` = delete at age 7
- `name` = "vf-{program}-{lm}-{stage}-temp-aa" & `lifecycle_rule` = delete at age 7
- `name` = "vf-{program}-{lm}-{stage}-aa-processed" 
- `name` = "vf-{program}-{lm}-{stage}-test-data" 

    
### Testing on alpha and beta projects: 
While testing on the alpha and beta projects and since the project names follows a different standard to the zeta ones, you need to override the following variables in the module configuration.

```yaml
tenant: grp
program: mc2dev
```

Also override the stage in metadata if you are testing a nonlive configuration in a live alpha or beta project

```yaml
metadata:
  stage: nonlive 
```
<br>

---
**Note:** In a ZETA project, no overriding is required as the `tenant` & `program` & `stage` will be -as usual- obtained from project metadata which is normally constructed from the file name as follows: 

```
[ORGANIZATION]-[TENANT]-[PROGRAM]-[STAGE].yml
```
---

<br>

### Example usage for `GRP` project tested in vf-mc2dev-ca-nonlive project:

<br>

```yaml
general:
  ss_suffix: nonlive
  tf_version: 0.13.2
  neuron_gcp_platform_version: 1.6.18
  composer_image_version: composer-1.13.0-airflow-1.10.10
  pypi_packages:
    google-api-core:        ==1.16.0
    google-cloud-core:      ==1.3.0
    google-cloud-datastore: ==1.12.0
    mysql-connector-python: ==8.0.20
modules:
  - name: terraform_provider_base
    google_beta_terraform_version: "3.36"
    google_terraform_version: "3.36"
  - name: tenant_core_tf12
  - name: tenant_cryptokey_tf12
    gcs_key: true
    bq_key: true
  - name: mc2_buckets_tf12
    tenant: grp #over-ride
    program: mc2dev #over-ride
    additional_local_markets:
      - ro
      - gr
      - cz
```
### Outcomes for `GRP` example:

<br>

The following buckets will be created

```
  "vf-mc2dev-cz-nonlive-aa-processed",
  "vf-mc2dev-gr-nonlive-aa-processed",
  "vf-mc2dev-ro-nonlive-aa-processed",
  "vf-mc2dev-cz-nonlive-temp-aa",
  "vf-mc2dev-gr-nonlive-temp-aa",
  "vf-mc2dev-ro-nonlive-temp-aa",
  "vf-mc2dev-cz-nonlive-temp-etl",
  "vf-mc2dev-gr-nonlive-temp-etl",
  "vf-mc2dev-ro-nonlive-temp-etl",
  "vf-mc2dev-cz-nonlive-test-data",
  "vf-mc2dev-gr-nonlive-test-data",
  "vf-mc2dev-ro-nonlive-test-data",
  
```

### Example usage for a local market project (`ES`):

<br>

```yaml
general:
  ss_suffix: nonlive
  tf_version: 0.13.2
  neuron_gcp_platform_version: 1.6.18
  composer_image_version: composer-1.13.0-airflow-1.10.10
  pypi_packages:
    google-api-core:        ==1.16.0
    google-cloud-core:      ==1.3.0
    google-cloud-datastore: ==1.12.0
    mysql-connector-python: ==8.0.20
modules:
  - name: terraform_provider_base
    google_beta_terraform_version: "3.36"
    google_terraform_version: "3.36"
  - name: tenant_core_tf12
  - name: tenant_cryptokey_tf12
    gcs_key: true
    bq_key: true
  - name: mc2_buckets_tf12
    tenant: es
    program: mc2dev
```

### Outcomes for `ES` example:

<br>

The following buckets will be created

```
  "vf-mc2dev-es-nonlive-aa-processed",
  "vf-mc2dev-es-nonlive-temp-aa",
  "vf-mc2dev-es-nonlive-temp-etl",
  "vf-mc2dev-es-nonlive-test-data",
```