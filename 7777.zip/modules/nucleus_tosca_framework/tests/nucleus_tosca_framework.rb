# frozen_string_literal: true

def run_nucleus_tosca_frameworks(params)
  project_id = params['config']['project_id']
  control "#{project_id} : nucleus_tosca_framework : " do
    title 'nucleus_tosca_framework setup correctly'
    impact 0.4
  end
end
