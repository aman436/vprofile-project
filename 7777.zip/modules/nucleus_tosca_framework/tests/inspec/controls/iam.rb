control "google_project_iam_binding:: Tosca commander roles" do
  title "google_project_iam_binding::Tosca commander roles"
  desc "Test tosca commmander roles"
    impact 1.0
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/compute.viewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('commander_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/logging.logWriter") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('commander_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/monitoring.metricWriter") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('commander_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "organizations/352790554748/roles/vfgcpBucketViewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('commander_sa')}
    end
end

control "google_project_iam_binding:: Tosca agent roles" do
  title "google_project_iam_binding::Tosca agent roles"
  desc "Test tosca agent roles"
    impact 1.0
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/compute.viewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('agent_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/logging.logWriter") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('agent_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/monitoring.metricWriter") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('agent_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "organizations/352790554748/roles/vfgcpBucketViewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('agent_sa')}
    end
end

control "google_project_iam_binding::Squid Service account  roles" do
  title "google_project_iam_binding::Squid Service account "
  desc "Squid Service account roles"
    impact 1.0
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/logging.logWriter") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('squid_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/monitoring.metricWriter") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('squid_sa')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/storage.objectViewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('squid_sa')}
    end
end

control "google_project_iam_binding:: Tosca commander datahub SA roles" do
  title "google_project_iam_binding::Tosca commander datahub SA roles"
  desc "Test Tosca commander datahub SA roles"
    impact 1.0
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/bigquery.dataViewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('commander_sas')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/bigquery.jobUser") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('commander_sas')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/bigquery.user") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('commander_sas')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/datafusion.viewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('commander_sas')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "organizations/352790554748/roles/vfgcpBucketViewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('commander_sas')}
    end
end


control "google_project_iam_binding:: Tosca agent datahub SA roles" do
  title "google_project_iam_binding::Tosca agent datahub SA roles"
  desc "Test Tosca agent datahub SA roles"
    impact 1.0
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/bigquery.dataViewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('agent_sas')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/bigquery.jobUser") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('agent_sas')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/bigquery.user") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('agent_sas')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "organizations/352790554748/roles/vfgcpBucketViewer") do
      it { should exist }
      its('members') { should include 'serviceAccount:'+input('agent_sas')}
    end
end

control "google_project_iam_binding:: Tosca  Admin users group roles" do
  title "google_project_iam_binding:: Tosca  Admin users group roles"
  desc "Test tosca Admin users group"
    impact 1.0
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/compute.viewer") do
      it { should exist }
      its('members') { should include 'group:'+input('admin_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/iap.tunnelResourceAccessor") do
      it { should exist }
      its('members') { should include 'group:'+input('admin_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/compute.osLogin") do
      it { should exist }
      its('members') { should include 'group:'+input('admin_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/storage.objectAdmin") do
      it { should exist }
      its('members') { should include 'group:'+input('admin_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "organizations/352790554748/roles/vfgcpBucketViewer") do
      it { should exist }
      its('members') { should include 'group:'+input('admin_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/logging.viewer") do
      it { should exist }
      its('members') { should include 'group:'+input('admin_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/monitoring.viewer") do
      it { should exist }
      its('members') { should include 'group:'+input('admin_group')}
    end
end

control "google_project_iam_binding:: Tosca test users group roles" do
  title "google_project_iam_binding:: Tosca test users group roles"
  desc "tosca test users group"
    impact 1.0
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/compute.viewer") do
      it { should exist }
      its('members') { should include 'group:'+input('testers_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/iap.tunnelResourceAccessor") do
      it { should exist }
      its('members') { should include 'group:'+input('testers_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/compute.osLogin") do
      it { should exist }
      its('members') { should include 'group:'+input('testers_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/storage.objectAdmin") do
      it { should exist }
      its('members') { should include 'group:'+input('testers_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "organizations/352790554748/roles/vfgcpBucketViewer") do
      it { should exist }
      its('members') { should include 'group:'+input('testers_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/logging.viewer") do
      it { should exist }
      its('members') { should include 'group:'+input('testers_group')}
    end
    describe google_project_iam_binding(:project=>input('project_name'), role: "roles/monitoring.viewer") do
      it { should exist }
      its('members') { should include 'group:'+input('testers_group')}
    end
end


