control "google_compute_project_info:: Enabled services " do
  title "Enabled services"
  desc  "Validate services"
  impact 1.0
  describe google_project_service ({:project=>input('project_name'),name: 'bigquery.googleapis.com' }) do
    it { should exist }
    its('state') { should cmp "ENABLED" }
  end
  describe google_project_service ({:project=>input('project_name'),name: 'iap.googleapis.com' }) do
    it { should exist }
    its('state') { should cmp "ENABLED" }
  end
  describe google_project_service ({:project=>input('project_name'),name: 'logging.googleapis.com' }) do
    it { should exist }
    its('state') { should cmp "ENABLED" }
  end
  describe google_project_service ({:project=>input('project_name'),name: 'monitoring.googleapis.com' }) do
    it { should exist }
    its('state') { should cmp "ENABLED" }
  end
  describe google_project_service ({:project=>input('project_name'),name: 'stackdriver.googleapis.com' }) do
    it { should exist }
    its('state') { should cmp "ENABLED" }
  end
  describe google_project_service ({:project=>input('project_name'),name: 'oslogin.googleapis.com' }) do
    it { should exist }
    its('state') { should cmp "ENABLED" }
  end
  describe google_project_service ({:project=>input('project_name'),name: 'sqladmin.googleapis.com' }) do
    it { should exist }
    its('state') { should cmp "ENABLED" }
  end
  describe google_project_service ({:project=>input('project_name'),name: 'cloudkms.googleapis.com' }) do
    it { should exist }
    its('state') { should cmp "ENABLED" }
  end
  describe google_project_service ({:project=>input('project_name'),name: 'containerregistry.googleapis.com' }) do
    it { should exist }
    its('state') { should cmp "ENABLED" }
  end
  describe google_project_service ({:project=>input('project_name'),name: 'compute.googleapis.com' }) do
    it { should exist }
    its('state') { should cmp "ENABLED" }
  end
  describe google_project_service ({:project=>input('project_name'),name: 'dns.googleapis.com' }) do
    it { should exist }
    its('state') { should cmp "ENABLED" }
  end
  describe google_project_service ({:project=>input('project_name'),name: 'servicenetworking.googleapis.com' }) do
    it { should exist }
    its('state') { should cmp "ENABLED" }
  end
end

