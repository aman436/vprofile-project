control "google_service_account:: Service accounts " do
  title "Service accounts check"
  desc  "Validate Tosca commander service accounts"
  impact 1.0
  describe google_service_account(:project=>input('project_name'), :name=>input('commander_sa')) do
    it { should exist }
    its('email') { should cmp input('commander_sa') }
  end
  describe google_service_account(:project=>input('project_name'), :name=>input('agent_sa')) do
    it { should exist }
    its('email') { should cmp input('agent_sa') }
  end
  describe google_service_account(:project=>input('project_name'), :name=>input('squid_sa')) do
    it { should exist }
    its('email') { should cmp input('squid_sa')}
  end
  describe google_service_account(:project=>input('project_name'), :name=>input('commander_sas')) do
    it { should exist }
    its('email') { should cmp input('commander_sas')}
  end
  describe google_service_account(:project=>input('project_name'), :name=>input('agent_sas')) do
    it { should exist }
    its('email') { should cmp input('agent_sas')}
  end
end