control "google_compute_network::global/networks/vpc" do
  title "google_compute_network::global/networks/vpc"
  desc " Control to check VPC"
    impact 1.0
    describe google_compute_network({:project=>input('project_name'), :name=>(input('network_name') )}) do
      it { should exist }
      its("name") { should cmp (input('network_name'))}
    end
end
  
control "google_compute_route::restricted-route" do
  title "google_compute_route::restricted-route"
  desc "google_compute_route:: restricted-route"
    impact 1.0
    describe google_compute_route({:project=>input('project_name'), :name=>(input('common_resource_id') + "-restricted-route")}) do
      it { should exist }
      its("name") { should cmp (input('common_resource_id') + "-restricted-route") }
      its("priority") { should cmp 100 }
    end
end
  

control "google_compute_route::private-route" do
  title "google_compute_route::private-route"
  desc "google_compute_route:: Route to Private Zone"
    impact 1.0
    describe google_compute_route({:project=>input('project_name'), :name=>(input('common_resource_id') + "-private-route")}) do
      it { should exist }
      its("dest_range") { should cmp "199.36.153.8/30" }
      its("name") { should cmp (input('common_resource_id') + "-private-route") }
      its("priority") { should cmp 100 }
    end
end
  
control "google_compute_route::Windows-license-route" do
  title "google_compute_route::Windows-license-route"
  desc "google_compute_route::global/routes/vf-pt-ngbi-dev-windowslicense-route"
    impact 1.0
    describe google_compute_route({:project=>input('project_name'), :name=>(input('common_resource_id') + "-windowslicense-route")}) do
      it { should exist }
      its("name") { should cmp (input('common_resource_id') + "-windowslicense-route") }
      its("priority") { should cmp 100 }
    end
end

control "google_compute_router:: Router and NAT " do
  title "google_compute_router:: NAT for trusted zone"
  desc "google_compute_router:: Testing router and NAT for trusted zone"
    impact 1.0
    describe google_compute_router({:project=>input('project_name'), :region=>input('region'), :name=>(input('router_name'))}) do
      it { should exist }
      its("name") { should cmp (input('router_name'))}
    end
    describe google_compute_router_nat({:project=>input('project_name'), :region=>input('region'), :router=>input('router_name'), :name=>input('nat_name')}) do
      it { should exist }
      its('nat_ip_allocate_option') { should cmp 'MANUAL_ONLY' }
      its("name") { should cmp input('nat_name')}
      its("source_subnetwork_ip_ranges_to_nat") { should cmp 'LIST_OF_SUBNETWORKS' }
    end
end

control "google_dns_managed_zone::managedZones/gcr-io-local" do
  title "google_dns_managed_zone::managedZones/gcr-io-local"
  desc "DNS ZOne for Google Cloud Resource"
    impact 1.0
    describe google_dns_managed_zone({:project=>input('project_name'), :zone=>"gcr-io-local"}) do
      it { should exist }
      its("dns_name") { should cmp "gcr.io." }
      its("name") { should cmp "gcr-io-local" }
      its("name_servers") { should cmp ["ns-gcp-private.googledomains.com."] }
    end
  end
  
control "google_dns_managed_zone::managedZones/private-googleapis-com-local" do
  title "google_dns_managed_zone::managedZones/private-googleapis-com-local"
  desc "DNS Zone for private-googleapis-com-local"
    impact 1.0
    describe google_dns_managed_zone({:project=>input('project_name'), :zone=>"private-googleapis-com-local"}) do
      it { should exist }
      its("dns_name") { should cmp "googleapis.com." }
      its("name") { should cmp "private-googleapis-com-local" }
      its("name_servers") { should cmp ["ns-gcp-private.googledomains.com."] }
    end
  end

control "google_dns_managed_zone::managedZones/internal-vodafone-dns." do
    title "google_dns_managed_zone::managedZones/internal-vodafone-dns"
    desc "DNS Zone for internal-vodafone-dns"
      impact 1.0
      describe google_dns_managed_zone({:project=>input('project_name'), :zone=>"internal-vodafone-dns"}) do
        it { should exist }
        its("dns_name") { should cmp "internal.vodafone.com." }
        its("name") { should cmp "internal-vodafone-dns" }
        its("name_servers") { should cmp ["ns-gcp-private.googledomains.com."] }
      end
    end