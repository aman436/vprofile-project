control "google_compute_firewall::Ingress" do
  title "google_compute_firewall::Allow IAP ingress traffic"
  desc "google_compute_firewall:: Firewall Rule to allow IAP ingress traffic"
    impact 1.0
    describe google_compute_firewall({:project=>input('project_name'), name: 'ssh-iap-tunnel'}) do
      it { should exist }
      its("direction") { should cmp "INGRESS" }
      its("source_ranges") { should cmp ["35.235.240.0/20"] }
      its("network") { should include input('network_name') }
    end
    describe google_compute_firewall({:project=>input('project_name'), name: 'rdp-iap-tunnel'}) do
      it { should exist }
      its("direction") { should cmp "INGRESS" }
      its("source_ranges") { should cmp ["35.235.240.0/20"] }
      its("network") { should include input('network_name') }
    end
end


control "google_compute_firewall::vf-grp-tosca-internal-squid-tcp-3128-ingress-allow-fwrule" do
  title "google_compute_firewall::vf-grp-tosca-internal-squid-tcp-3128-ingress-allow-fwrule"
  desc "google_compute_firewall:: Allow ingress to Squid from internal subnets on tcp-3128"
    impact 1.0
    describe google_compute_firewall({:project=>input('project_name'), :name=>(input('common_resource_id') + "-internal-squid-tcp-3128-ingress-allow-fwrule")}) do
      it { should exist }
      its("direction") { should cmp "INGRESS" }
      its("name") { should cmp (input('common_resource_id') + "-internal-squid-tcp-3128-ingress-allow-fwrule")}
      its("priority") { should cmp 1000 }
      its("source_ranges") { should include input('restricted_zone_cidr_range') }
      its("target_tags") { should cmp ["squid-proxy"] }
    end
end

control "google_compute_firewall::vf-grp-tosca-internal-tosca-agent-internal-ingress-allow-fwrule" do
  title "google_compute_firewall::vf-grp-tosca-internal-tosca-agent-internal-ingress-allow-fwrule"
  desc "google_compute_firewall:: Allow ingress between internal subnets on tcp 443-453 , 80-90, 31010, 31110"
    impact 1.0
    describe google_compute_firewall({:project=>input('project_name'), :name=>(input('common_resource_id') + "-internal-tosca-agent-internal-ingress-allow-fwrule")}) do
      it { should exist }
      its("direction") { should cmp "INGRESS" }
      its("name") { should cmp (input('common_resource_id') + "-internal-tosca-agent-internal-ingress-allow-fwrule")}
      its("priority") { should cmp 1000 }
      its("source_ranges") { should include input('restricted_zone_cidr_range') }
      its("target_tags") { should cmp ["iap-tunnel"] }
    end
end

control "google_compute_firewall::vf-grp-tosca-all-ingress-deny" do
  title "google_compute_firewall::vf-grp-tosca-all-ingress-deny"
  desc "google_compute_firewall:: Firewall Rule to Deny All Ingress"
    impact 1.0
    describe google_compute_firewall({:project=>input('project_name'), :name=>(input('common_resource_id') + "-all-ingress-deny")}) do
      it { should exist }
      its("direction") { should cmp "INGRESS" }
      its("name") { should cmp (input('common_resource_id') + "-all-ingress-deny")}
      its("priority") { should cmp 65535 }
      its("source_ranges") { should cmp ["0.0.0.0/0"] }
    end
end

control "google_compute_firewall::vf-grp-tosca-windows-license-activation-tcp-egress-allow" do
  title "google_compute_firewall::vf-grp-tosca-windows-license-activation-tcp-egress-allow"
  desc "google_compute_firewall :: windows-license-activation-tcp-1688-egress-allow"
  impact 1.0
  describe google_compute_firewall({:project=>input('project_name'), :name=>(input('common_resource_id') + "-windows-license-activation-tcp-egress-allow")}) do
    it { should exist }
    its("destination_ranges") { should cmp ["35.190.247.13/32"] }
    its("destination_ranges") { should_not include input('public_cidr') }
    its("direction") { should cmp "EGRESS" }
    its("name") { should cmp (input('common_resource_id') + "-windows-license-activation-tcp-egress-allow") }
    its("priority") { should cmp 0 }
  end
end

control "google_compute_firewall::vf-grp-tosca-private-googleapis-allow" do
  title "google_compute_firewall::vf-grp-tosca-private-googleapis-allow"
  desc "google_compute_firewall :: Allow private access to googleapis-allow"
  impact 1.0
  describe google_compute_firewall({:project=>input('project_name'), :name=>(input('common_resource_id') + "-private-googleapis-allow")}) do
    it { should exist }
    its("destination_ranges") { should cmp ["199.36.153.8/30"] }
    its("destination_ranges") { should_not include input('public_cidr') }
    its("direction") { should cmp "EGRESS" }
    its("name") { should cmp (input('common_resource_id') + "-private-googleapis-allow") }
    its("priority") { should cmp 1000 }
  end
end

control "google_compute_firewall:: vf-grp-tosca-restricted-googleapis-allow" do
  title "google_compute_firewall:: vf-grp-tosca-restricted-googleapis-allow"
  desc  "google_compute_firewall:: Firewall to allow Google API"
  impact 1.0
  describe google_compute_firewall({:project=>input('project_name'), :name=>(input('common_resource_id') + "-restricted-googleapis-allow")}) do
    it { should exist }
    its("destination_ranges") { should cmp ["199.36.153.4/30"] }
    its("destination_ranges") { should_not include input('public_cidr') }
    its("direction") { should cmp "EGRESS" }
    its("name") { should cmp (input('common_resource_id') + "-restricted-googleapis-allow") }
    its("priority") { should cmp 1000 }
  end
end

control "google_compute_firewall::vf-grp-tosca-nodes--cloud-sql-tcp-1433-egress-allow" do
  title "google_compute_firewall::vf-grp-tosca-nodes--cloud-sql-tcp-1433-egress-allow"
  desc "google_compute_firewall :: Allow egress from all instances on vpc to cloud sql server on tcp-1433"
  impact 1.0
  describe google_compute_firewall({:project=>input('project_name'), :name=>(input('common_resource_id') + "--cloud-sql-tcp-1433-egress-allow")}) do
    it { should exist }
    its("destination_ranges") { should cmp input ('cloud_sql_server_cidr') }
    its("destination_ranges") { should_not include input('public_cidr') }
    its("direction") { should cmp "EGRESS" }
    its("name") { should cmp (input('common_resource_id') + "--cloud-sql-tcp-1433-egress-allow") }
    its("priority") { should cmp 1000 }
  end
end

control "google_compute_firewall::vf-grp-tosca-nodes--cloud-sql-tcp-1433-egress-allow" do
  title "google_compute_firewall::vf-grp-tosca-nodes--cloud-sql-tcp-1433-egress-allow"
  desc "google_compute_firewall :: Allow egress from all instances on vpc to cloud sql server on tcp-1433"
  impact 1.0
  describe google_compute_firewall({:project=>input('project_name'), :name=>(input('common_resource_id') + "-nodes--cloud-sql-tcp-1433-egress-allow")}) do
    it { should exist }
    its("destination_ranges") { should cmp input('cloud_sql_server_cidr') }
    its("destination_ranges") { should_not include input('public_cidr') }
    its("direction") { should cmp "EGRESS" }
    its("name") { should cmp (input('common_resource_id') + "-nodes--cloud-sql-tcp-1433-egress-allow") }
    its("priority") { should cmp 100 }
  end
end

control "google_compute_firewall:: vf-grp-tosca-internet-egress-allow" do
  title "google_compute_firewall:: vf-grp-tosca-internet-egress-allow"
    desc  "google_compute_firewall::vf-grp-tosca-internet-egress-allow"
    impact 1.0
    describe google_compute_firewall({:project=>input('project_name'), :name=>(input('common_resource_id') + "-internet-egress-allow")}) do
      it { should exist }
      its("destination_ranges") { should cmp ["0.0.0.0/0"] }
      its("direction") { should cmp "EGRESS" }
      its("name") { should cmp (input('common_resource_id') + "-internet-egress-allow")}
      its("priority") { should cmp 1000 }
      its("target_tags") { should cmp ["squid-proxy"] }
    end
end

control "google_compute_firewall:: vf-grp-tosca-nodes-squid-tcp--egress-allow" do
  title "google_compute_firewall:: vf-grp-tosca-nodes-squid-tcp-3128-egress-allow"
  desc  "google_compute_firewall:: Allow Egress from Node to Squid on TCP 3128"
  impact 1.0
  describe google_compute_firewall({:project=>input('project_name'), :name=>(input('common_resource_id') + "-nodes-squid-tcp-3128-egress-allow")}) do
    it { should exist }
    its("destination_ranges") { should cmp input('squid_proxy_ip') }
    its("destination_ranges") { should_not include input('public_cidr') }
    its("direction") { should cmp "EGRESS" }
    its("name") { should cmp (input('common_resource_id') + "-nodes-squid-tcp-3128-egress-allow") }
    its("priority") { should cmp 1000 }
  end
end

control "google_compute_firewall:: vf-grp-tosca-tosca-servers-egress-allow" do
  title "google_compute_firewall:: vf-grp-tosca-tosca-servers-egress-allow"
  desc  "google_compute_firewall:: Allow egress between internal subnets on tcp 443-453 and 80-90"
  impact 1.0
  describe google_compute_firewall({:project=>input('project_name'), :name=>(input('common_resource_id') + "-nodes-squid-tcp-3128-egress-allow")}) do
    it { should exist }
    its("destination_ranges") { should cmp input('squid_proxy_ip') }
    its("destination_ranges") { should_not include input('public_cidr') }
    its("direction") { should cmp "EGRESS" }
    its("name") { should cmp (input('common_resource_id') + "-nodes-squid-tcp-3128-egress-allow") }
    its("priority") { should cmp 1000 }
  end
end

control "google_compute_firewall::vf-grp-tosca-all-egress-deny" do
  title "google_compute_firewall::vf-grp-tosca-all-egress-deny"
  desc "google_compute_firewall:: Firewall Rule to Deny All engress"
    impact 1.0
    describe google_compute_firewall({:project=>input('project_name'), :name=>(input('common_resource_id') + "-all-egress-deny")}) do
      it { should exist }
      its("direction") { should cmp "EGRESS" }
      its("name") { should cmp (input('common_resource_id') + "-all-egress-deny")}
      its("priority") { should cmp 65535 }
      its("destination_ranges") { should cmp ["0.0.0.0/0"] }
    end
end




