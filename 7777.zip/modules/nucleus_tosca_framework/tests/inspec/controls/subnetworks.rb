control "google_compute_subnetwork:: Tosca subnetworks" do
  title "Tosca subnetworks"
  desc  "Validate Tosca subnetworks setup"
  impact 1.0
  describe google_compute_subnetwork(:project=>input('project_name'), :region=>input('region'), :name=>input('management_zone_name')) do
    it { should exist }
    its('ip_cidr_range') { should eq input('management_zone_cidr_range') }
  end
  describe google_compute_subnetwork(:project=>input('project_name'), :region=>input('region'), :name=>input('trusted_zone_name')) do
    it { should exist }
    its('ip_cidr_range') { should eq input('trusted_zone_cidr_range') }
  end
  describe google_compute_subnetwork(:project=>input('project_name'), :region=>input('region'), :name=>input('dmz_zone_name')) do
    it { should exist }
    its('ip_cidr_range') { should eq input('dmz_zone_cidr_range') }
  end
  describe google_compute_subnetwork(:project=>input('project_name'), :region=>input('region'), :name=>input('restricted_zone_name')) do
    it { should exist }
    its('ip_cidr_range') { should eq input('restricted_zone_cidr_range') }
  end
end