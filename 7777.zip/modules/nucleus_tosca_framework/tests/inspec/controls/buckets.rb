control "google_storage_bucket::tosca-staging-bucket" do
    title "google_storage_bucket::tosca-staging-bucket"
    desc "google_storage_bucket::tosca staging bucket"
      impact 1.0
      describe google_storage_bucket({:name=>(input('project_name')+"-staging")}) do
        it { should exist }
        its("location") { should cmp input('region')}
        its("name") { should cmp (input('project_name')+"-staging")}
        its("storage_class") { should cmp "REGIONAL" }
      end
end