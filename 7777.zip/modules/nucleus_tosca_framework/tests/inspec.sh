#!/bin/bash
########### Inspect for Test Gen01 ###############################
#inspec exec /var/lib/go-agent/pipelines/$PIPELINE_NAME/$CONFIG_REPO/$MODULE/inspec -t gcp:// --input-file /var/lib/go-agent/pipelines/$PIPELINE_NAME/$CONFIG_REPO/$MODULE/inspec/variable.yaml --chef-license=accept-silent
bundle exec inspec exec ./inspec -t gcp:// --input-file ./inspec/variable.yaml --chef-license=accept-silent
