# frozen_string_literal: true

def run_datacatalogue(params)
  project_id = params['config']['project_id']
  control "#{project_id} : datacatalogue : " do
    title 'Infrastructure for datacatalogue setup correctly'
    impact 0.4
  end
end
