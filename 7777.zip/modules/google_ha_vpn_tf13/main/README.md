HA VPN based on a google vpn module
this module allow you to:

1-create a VPN gateway with 2 tunnels by using google module
2-create a secret to secure the connection in the VPN
3-create a customized router for the HA VPN

why this module created and what is the diffrenece between this module and google moduel?
1-create a secret with (secrets_tf12) module which uses a platform-engineering key stored at neuronenabler-nonlive project this is not provided by google module
2-also the customized router provided by google is not working properly so provided in this module a customized router 