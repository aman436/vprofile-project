
# Getting started

## Introduction

This deployment sets up a nginx reverse proxy with an internet-facing load-balancer for ingress. This  deploy references the following GCP resources:
- An external IP address to attatch to the external LB, e.g. 'beta-apps-neuron-bigdata-vodafone-com-ip'
- An existing SSL certificate, e.g. 'nginx-ingress'
- Any incoming connections to be to the domain 'beta-apps.neuron.bdp.vodafone.com'

Google Identity Aware Proxy, (IAP) is attached to this deployment, preventing external access by unauthorized users.

Additionally, Cloud Armour has been tested with this deployment, but is not present as yet. For setup and configuration of both of these, please see the respective IAP and Cloud Armour sections below.

## Identity Aware Proxy, (IAP)

IAP need to be configured once per project. Please see detailed instructions here: 
- https://cloud.google.com/iap/docs/enabling-kubernetes-howto
  

For a condensed version, see below:
1. Configure OAUTH consent screen
2. Create OAUTH credentials:
2.1. Add https://<domain>/_gcp_gatekeeper/authenticate URLs
2.2. Get JSON credentials file
2.3. Add https://iap.googleapis.com/v1/oauth/clientIds/<CLIENT_ID>:handleRedirect URL, (<CLIENT_ID> is referenced in JSON)
3. Create secret from JSON:
3.1. ``kubectl create secret generic trusted-zone-nginx-oauth \
--from-literal=client_id=<CLIENT_ID> \
--from-literal=client_secret=<SECRET> \
--namespace trusted-zone-nginx
``

## Cloud Armour
Cloud Armour configurations in K8s take the name of a rule and apply it to an external ingress load-balancer.  To create a policy, see the example below:
```
# Creates a rule called 'allow-vf-london-office-http' that will deny all traffic by default, (returning 403) except for requests coming from the London Vodafone office, (194.62.232.102,194.62.232.103).

gcloud compute --project=vf-grp-shared-services-nonlive security-policies create allow-vf-london-office-http
gcloud compute --project=vf-grp-shared-services-nonlive security-policies rules create 1000 --action=allow --security-policy=allow-vf-london-office-http --src-ip-ranges=194.62.232.102,194.62.232.103
gcloud compute --project=vf-grp-shared-services-nonlive security-policies rules create 2147483647 --action=deny\(403\) --security-policy=allow-vf-london-office-http --description="Default rule, higher priority overrides it" --src-ip-ranges=\*
```
This can then be applied by referencing the name in  `nginx-backend-config.yaml`:
```
spec:
  securityPolicy:
   name: "allow-vf-london-office-http"
```

## Connecting to internal services
Each internal service, (Jenkins, Nexus, etc.) will present an internal load-balancer with an internal DNS entry, e.g. (Jenkins - jenkins.neuron.bdc.vf.local.).
1. Create private zone:
1.1. gcloud beta dns --project=vf-grp-shared-services-nonlive managed-zones create neuron-bdc-vf-local --description= --dns-name=neuron.bdc.vf.local. --visibility=private --networks vf-group-ss-vpc

2. Create DNS record for internal LB
2.1.`gcloud dns --project=vf-grp-shared-services-nonlive record-sets transaction start --zone=neuron-bdc-vf-local`
`gcloud dns --project=vf-grp-shared-services-nonlive record-sets transaction add <internal_lb_ip> --name=landing.neuron.bdc.vf.local. --ttl=5 --type=A --zone=neuron-bdc-vf-local`
`gcloud dns --project=vf-grp-shared-services-nonlive record-sets transaction execute --zone=neuron-bdc-vf-local`
  

## Deploying
```
kubectl apply -f nginx-namespace.yaml 
kubectl apply -f nginx-configmap.yaml
kubectl apply -f nginx-backend-config.yaml
kubectl apply -f nginx-service.yaml 
kubectl apply -f nginx-deploy.yaml
kubectl apply -f nginx-ingress-public.yaml 	
```
