# frozen_string_literal: true

def run_inbound_proxy(params)
  project_id = params['config']['project_id']
  control "#{project_id} : inbound_proxy : " do
    title 'Infrastructure for inbound proxy setup correctly'
    impact 0.8
  end
end
