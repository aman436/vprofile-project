# frozen_string_literal: true

%w[vm nat].each do |lib|
    require_relative "#{Dir.pwd}/target/tests/libraries/#{lib}.rb"
  end


def run_remote_dev_vm_core(params)
    project_id = params['config']['project_id']
    name = "#{project_id} : #{params['config']['module_name']}"
    control name do
      title 'Project core infrastructure setup correctly'
      impact 0.4
  
      # VPC
      vpc_name = "#{params['variables']['vpc_prefix']}-#{params['variables']['vpc_name']}-#{params['variables']['vpc_suffix']}"
      is_autocreate = false
      routing_mode = params['tests']['routing_mode']
      validate_vpc(project_id, vpc_name, is_autocreate, routing_mode)

      # Subnet
      %w[trusted management].each do |subnet_prefix|
        subnet_name = "#{subnet_prefix}-zone"
        subnet_exists_in_project(
          project_id,
          params['variables']['region'],
          subnet_name
        )
        subnet_cidr_range(
          project_id,
          params['variables']['region'],
          subnet_name,
          params['variables']["#{subnet_prefix}_zone_cidr_range"]
        )
        subnet_in_vpc_network(
          project_id,
          params['variables']['region'],
          subnet_name,
          vpc_name
        )
        subnet_vm_private_ip_access(
          project_id,
          params['variables']['region'],
          subnet_name,
          params['tests']['subnet_private_ip_access']
        )
        subnet_flowlog_on(
          project_id,
          subnet_name,
          params['variables']['region'],
          params['tests']['subnet_flowlog_on']
        )
      end

      # NAT
      nat_router_exists(project_id, params['variables']['region'], "management-nat-router")

      nat_router_in_vpc(project_id, params['variables']['region'], "management-nat-router", vpc_name)
    end
  end