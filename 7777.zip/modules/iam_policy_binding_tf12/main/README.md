# IAM POLICY BINDING module

This module binds specific role to the members to Google Service Account. Members can be Service Account.

### Module Input Variables:

- `google_service_account`: - Google service account in which we need to bind member with a particular role.
- `role`: - Specific role to bind to member.
- `members`: - It can be a member or list of members. It can be service account or a group.

### Module Outputs:

 - `members` - List of members that are binded to the specific role.
 - `role` - The role that is binded with member.
 - `service_account_id` - Google service account in which we binded members to the particular role.