# frozen_string_literal: true

def run_iam_policy_binding(params)
  project_id = params['config']['project_id']
  control "#{project_id} : #{params['module_name']} " do
    puts 'Need to add tests for IAM policy binding'
  end
end