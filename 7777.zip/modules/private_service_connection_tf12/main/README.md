# Module to create Private Service Connection

Google Docs: https://cloud.google.com/vpc/docs/configure-private-services-access?_ga=2.241195521.-2098953827.1643886720

Inspired from: https://github.vodafone.com/VFGroup-CloudAnalytics/terraform-modules/tree/master/core_network

[Configuration](../../../resources/neuron_module_configuration/private_service_connection_tf12.yml)

Works with tenant_core_tf12 module.

## Prerequisites

- A VPC network must exist

- tenant_core_tf12 must run

## Examples:

```
  - name: private_service_connection_tf12
```

```
  - name: private_service_connection_tf12
    psc_ip_range: "172.25.240.0/24"
    psc_ip_range_name: "non-default"
    vpc_network_name: "Not the network generated from tenant_core_tf12 module"
```

## Motivation / Usage

This module will create a Private Service Connection in the VPC Network. It is a requirement to use multiple GCP services from your VPC, including CloudSQL and Cloud Build.

The Private Service Connection consists of an IP range and a Connection config. You can define your own IP-range, to see the default values, look into the [Configuration](../../../resources/neuron_module_configuration/private_service_connection_tf12.yml).

:warning: This module needs to run before the module creating your service, e.g. CloudSQL
