export GCP_PROJECT=$1
export GCP_SA=$2
export K8S_SA=$3
export K8S_NS=$4

kubectl annotate --overwrite serviceaccount ${K8S_SA} \
  iam.gke.io/gcp-service-account="${GCP_SA}@${GCP_PROJECT}.iam.gserviceaccount.com" \
  -n ${K8S_NS}