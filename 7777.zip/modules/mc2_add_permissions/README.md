# MC2 add permission module

This module gives access to service accounts created by central compute project to buckets and dataets in live/nonlive porjects.

in mc2 you don't need to call this module, it called inside mc2_bigquery_datasets_tf12 and mc2_buckets_tf12 modules.

CDF Consolidation Migration Plan: https://confluence.sp.vodafone.com/pages/viewpage.action?spaceKey=NM&title=CDF+Consolidation+Migration+Plan

### Module Input Variables:

- `buckets`: list of local markets you want to provide access to their buckets
- `datasets`: list of local markets you want to provide access to their datasets
- `compute_project`: the name of central compute project
- `compute_project_program`: the program used in metadata in compute project configs



