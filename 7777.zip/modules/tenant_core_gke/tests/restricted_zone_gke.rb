# frozen_string_literal: true

def run_tenant_core_gke(params)
  project_id = params['config']['project_id']
  control "#{project_id} : tenant_core_gke : " do
    title 'tenant_core_gke setup correctly'
    impact 0.4
  end
end
