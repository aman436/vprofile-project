# frozen_string_literal: true

def run_outbound_proxy(params)
  project_id = params['config']['project_id']
  control "#{project_id} : outbound_proxy : " do
    title 'outbound_proxy setup correctly'
    impact 0.6
  end
end
