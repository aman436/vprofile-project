# frozen_string_literal: true
require_relative "#{Dir.pwd}/target/tests/libraries/test_utils.rb"

def run_oslogin(params)
  project_id = params['config']['project_id']

  control "#{project_id} : #{params['config']['module_name']}" do
    title 'OS Login enabled in project metadata'
    impact 0.3

    ret_value = MetaOSLogin.new(false)

    project_info = GcpState.google_compute_project_info(self, project: project_id)
    project_info.common_instance_metadata.items.each do |element|
      if element.key=='enable-oslogin' and element.value.casecmp('true').zero?
        ret_value.enabled = true
      end
    end

    describe ret_value do
      its('enabled') {should eq true}
    end
  end
end

class MetaOSLogin
  def to_s
    "OSLogin metadata setting"
  end
  def to_str
    "OSLogin metadata setting"
  end

  def initialize(v)
    @enabled = v
  end

  def enabled
    @enabled
  end
  def enabled=(v)
    @enabled = v
  end
end
