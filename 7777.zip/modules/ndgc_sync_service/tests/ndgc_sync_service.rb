# frozen_string_literal: true

def run_ndgc_sync_service(params)
  project_id = params['config']['project_id']
  control "#{project_id} : #{params['config']['module_name']}" do
    title 'NDGC Sync Service module setup correctly'
    impact 0.4
  end
end
