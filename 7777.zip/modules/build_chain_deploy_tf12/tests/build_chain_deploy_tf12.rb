# frozen_string_literal: true

def run_build_chain_deploy_tf12(params)
  project_id = params['config']['project_id']
  control "#{project_id} : #{params['module_name']} " do
    title 'Build chain deploy infrastructure tests'
    impact 0.2

    sa_email = "#{params['tests']['service_account_id']}" \
         "@#{params['variables']['project_name']}.iam.gserviceaccount.com"

    sa_exists(sa_email, project_id)

    params['tests']['roles'].each do |role|
      sa_iam_role_exists(sa_email, project_id, role)
    end
  end
end
