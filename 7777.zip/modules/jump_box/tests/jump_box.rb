# frozen_string_literal: true

['vm'].each do |lib|
  require_relative "#{Dir.pwd}/target/tests/libraries/#{lib}.rb"
end

def run_jump_box(params)
  project_id = params['config']['project_id']
  control "#{project_id} : #{params['config']['module_name']} " do
    title 'Jump box vm setup correctly'
    impact 0.4

    vm_instance_exists(
      params['variables']['vm_name'],
      project_id,
      params['variables']['zone']
    )

    vm_instance_zone(
      params['variables']['vm_name'],
      project_id,
      params['variables']['zone']
    )

    vm_instance_status(
      params['variables']['vm_name'],
      project_id,
      params['variables']['zone']
    )

    vm_instance_machine_type(
      params['variables']['vm_name'],
      project_id,
      params['variables']['zone'],
      params['variables']['machine_type']
    )

    vm_no_public_ip(
      params['variables']['vm_name'],
      project_id,
      params['variables']['zone'],
      params['tests']['public_ip']
    )

    vm_image_is_correct(
      params['variables']['vm_name'],
      project_id,
      params['variables']['zone'],
      params['variables']['image_id']
    )
  end
end
