# frozen_string_literal: true

['vm'].each do |lib|
  require_relative "#{Dir.pwd}/target/tests/libraries/#{lib}.rb"
end

def run_bastion(params)
  project_id = params['config']['project_id']
  control "#{project_id} : #{params['config']['module_name']}" do
    title 'Bastion instance exist and configured correctly'
    impact 0.3

    vm_instance_exists(
      params['tests']['vm_name'],
      project_id,
      params['variables']['zone']
    )
    vm_instance_zone(
      params['tests']['vm_name'],
      project_id,
      params['variables']['zone']
    )
    vm_instance_status(
      params['tests']['vm_name'],
      project_id,
      params['variables']['zone']
    )
    vm_instance_machine_type(
      params['tests']['vm_name'],
      project_id,
      params['variables']['zone'],
      params['tests']['machine_type']
    )
    vm_no_public_ip(
      params['tests']['vm_name'],
      project_id,
      params['variables']['zone'],
      params['tests']['public_ip']
    )
    vm_in_subnet(
      params['tests']['vm_name'],
      project_id,
      params['variables']['zone'],
      'management-zone'
    )
    vm_image_is_correct(
      params['tests']['vm_name'],
      project_id,
      params['variables']['zone'],
      params['variables']['bastion_image_id']
    )
  end
end
