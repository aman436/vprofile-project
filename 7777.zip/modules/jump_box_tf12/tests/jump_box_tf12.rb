# frozen_string_literal: true

def run_jump_box_tf12(params)
  
  config     = params['config']
  variables  = params['variables']

  control "google_compute_instance::projects/#{config['project_id']}/zones/#{variables['zone']}/instances/#{variables['vm_name']}" do
    title "correctly configured"
    impact 1.0
    describe google_compute_instance({:project=>"#{config['project_id']}", :zone=>"#{variables['zone']}", :name=>"#{variables['vm_name']}"}) do
      it { should exist }
      its("name") { should cmp "#{variables['vm_name']}" }
      its("hostname") { should be_nil.or cmp "" }
      its("status") { should cmp "RUNNING" }
      its('disk_count') {should eq 1 }
      its("cpu_platform") { should include "Intel" }  
      its('machine_type') { should match "#{variables['machine_type']}" }
      its("scheduling.automatic_restart") { should cmp true }
      its("scheduling.on_host_maintenance") { should cmp "MIGRATE" }
      its("scheduling.preemptible") { should cmp false }
      its('network_interfaces_count') {should eq 1 }
      its('can_ip_forward') { should be false }
      its('service_account_scopes') { should cmp ["https://www.googleapis.com/auth/cloud-platform"] }
      its('zone') { should include "#{variables['zone']}" }      
    end
    describe google_compute_instance({:project=>"#{config['project_id']}", :zone=>"#{variables['zone']}", :name=>"#{variables['vm_name']}"}).label_value_by_key('zone') do
      it { should cmp "#{variables['label_zone']}" }
    end
    describe google_compute_instance({:project=>"#{config['project_id']}", :zone=>"#{variables['zone']}", :name=>"#{variables['vm_name']}"}).metadata_value_by_key('enable-oslogin') do
      it { should cmp "TRUE" }
    end
    describe google_compute_disk({:project=>"#{config['project_id']}", :zone=>"#{variables['zone']}", :name=>"#{variables['vm_name']}"}) do
      it { should exist }
      its('source_image') { should cmp "#{variables['image_id']}" }
    end
  end
end
