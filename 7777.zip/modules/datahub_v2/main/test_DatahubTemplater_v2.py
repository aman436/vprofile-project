from templater.main.JinjaTemplate import JinjaTemplate
from modules.datahub_v2.main.DatahubTemplater import DatahubTemplater
import unittest
import logging
import os


class TestDatahubTemplaterV2(unittest.TestCase):
    def __init__(self, *args, **kwargs):
        super(TestDatahubTemplaterV2, self).__init__(*args, **kwargs)
        logging.basicConfig(level=logging.CRITICAL)
        self.maxDiff = None
        self.DT = DatahubTemplater(
            jinja_template_class=JinjaTemplate(
                template_path="resources/templates", template_file_ex=".tf.j2"
            )
        )
