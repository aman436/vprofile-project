from typing import Dict, List, Type, Tuple, Union

from dacite import from_dict, Config

from modules.datahub_v2.main.datahub_types import (
    ConfigurationFile,
    GoogleMemberResourceId,
    ProjectDetails,
    ServiceAccountResource,
    StorageTypeDetails,
    StorageTypesMap,
)


def get_storage_type_details_map(datahub_config: ConfigurationFile) -> StorageTypesMap:

    storage_types_map: StorageTypesMap = {}
    for storage_type, definition in datahub_config["storage_types"].items():
        new_storage_type: StorageTypeDetails = from_dict(
            data_class=StorageTypeDetails,
            data=definition,
            config=Config(cast=[GoogleMemberResourceId]),
        )

        if new_storage_type.storage and new_storage_type.storage.buckets:
            for bucket in new_storage_type.storage.buckets:
                if not bucket.key_type:
                    bucket.key_type = new_storage_type.storage.key_type
                if not bucket.storage_class:
                    bucket.storage_class = datahub_config["storage_class"]

        if new_storage_type.bigquery and new_storage_type.bigquery.datasets:
            for dataset in new_storage_type.bigquery.datasets:
                if not dataset.key_type:
                    if "key_type" in datahub_config:
                        dataset.key_type = datahub_config["key_type"]
                    else:
                        dataset.key_type = new_storage_type.bigquery.key_type
                if not dataset.location:
                    project_location = datahub_config.get("location", "europe-west1")
                    if project_location.lower() == "europe-west1":
                        dataset.location = "EU"
                    else:
                        dataset.location = project_location

        storage_types_map[storage_type] = new_storage_type

    return storage_types_map


def get_service_accounts(
    datahub_config: ConfigurationFile,
) -> List[ServiceAccountResource]:

    if "service_account_list" not in datahub_config:
        return []

    service_accounts: List[ServiceAccountResource] = []

    for service_account in datahub_config["service_account_list"]:
        mapped_service_account = from_dict(
            data_class=ServiceAccountResource, data=service_account,
        )
        service_accounts.append(mapped_service_account)

    return service_accounts


def get_project_details(datahub_config: ConfigurationFile) -> ProjectDetails:

    project_details: ProjectDetails = from_dict(
        data_class=ProjectDetails, data=datahub_config
    )

    return project_details
