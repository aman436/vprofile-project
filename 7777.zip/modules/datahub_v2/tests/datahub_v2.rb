# frozen_string_literal: true

%w[service_account bucket].each do |lib|
  require_relative "#{Dir.pwd}/target/tests/libraries/#{lib}.rb"
end

def run_datahub_v2(params)
  # Right now adding only bucket and service account tests without IAM
  # TODO: add IAM on buckets
  project_id = params['config']['project_id']
  control "#{project_id} : #{params['config']['module_name']}" do
    title 'Datahub infrastructure configured correctly'
    impact 1

    # TODO: doesn't work, fix it or drop it
    # # Test service accounts
    # params['variables']['service_account_list'].each do |sa_list|
    #   service_account_name = "vf-#{params['variables']['tenant']}-" \
    #     "#{sa_list['program']}-dh-#{sa_list['sa_sub_str']}-sa@#{project_id}" \
    #     '.iam.gserviceaccount.com'

    #   sa_exists(service_account_name, project_id)
    # end

    # Test buckets names
    params['variables'].keys.each do |var_key|
      next unless var_key.include? '_bucket_list'

      params['variables'][var_key].each do |bucket_suffix|
        bucket_name = "vf#{params['variables']['tenant']}-dh-#{bucket_suffix['name']}"

        bucket_exists(bucket_name)
        bucket_restricted_label(bucket_name)
        bucket_storage_class(bucket_name, params['variables']['storage_class'])
        bucket_location(bucket_name, params['variables']['location'])
        bucket_private(bucket_name)

        key_name = "cmek-#{params['tests']['kms_protection_level']}-vf-" \
          "#{params['variables']['tenant']}-gcs-" \
          "#{params['variables']['location'].downcase}"
        if %w[export-clear rawingested vault-secrets].include? bucket_suffix['name']
          bucket_kms(bucket_name, "#{key_name}-agf")
        else
          bucket_kms(bucket_name, key_name.to_s)
        end
      end
    end
  end
end
