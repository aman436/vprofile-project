def run_tenant_core_tf12(params)

  config     = params['config']
  variables  = params['variables']

  name = "#{config['project_id']}::#{config['module_name']} correctly configured"

  control "google_compute_network::vpc-#{variables['tenant']}-#{variables['vpc_name']}-vpc" do
    title "correctly configured"
    impact 1.0
    describe google_compute_network({:project=>"#{config['project_id']}", :name=>"vpc-#{variables['tenant']}-#{variables['vpc_name']}-vpc"}) do
      it { should exist }
      its("description") { should be_nil.or cmp "" }
      its("gateway_ipv4") { should be_nil.or cmp "" }
      its("name") { should cmp "vpc-#{variables['tenant']}-#{variables['vpc_name']}-vpc" }
      its("auto_create_subnetworks") { should cmp false }
      its("routing_config.routing_mode") { should cmp "REGIONAL" }
    end
  end
  
  control "google_compute_router::#{variables['region']}/composer-nat-router" do
    title "correctly configured"
    impact 1.0
    describe google_compute_router({:project=>"#{config['project_id']}", :region=>"#{variables['region']}", :name=>"composer-nat-router"}) do
      it { should exist }
      its("bgp.advertise_mode") { should cmp "DEFAULT" }
      its("bgp.advertised_groups") { should be_nil }
      its("bgp.advertised_ip_ranges") { should be_nil }
      its("bgp.asn") { should cmp 64514 }
      its("description") { should be_nil.or cmp "" }
      its("name") { should cmp "composer-nat-router" }
      its("network") { should cmp "https://www.googleapis.com/compute/v1/projects/#{config['project_id']}/global/networks/vpc-#{variables['tenant']}-#{variables['vpc_name']}-vpc" }
      its("region") { should include "#{variables['region']}" }
    end
  end
  
  control "google_compute_router::projects/#{config['project_id']}/regions/#{variables['region']}/routers/management-router" do
    title "correctly configured"
    impact 1.0
    describe google_compute_router({:project=>"#{config['project_id']}", :region=>"#{variables['region']}", :name=>"management-router"}) do
      it { should exist }
      its("bgp.advertise_mode") { should cmp "DEFAULT" }
      its("bgp.advertised_groups") { should be_nil }
      its("bgp.advertised_ip_ranges") { should be_nil }
      its("description") { should be_nil.or cmp "" }
      its("name") { should cmp "management-router" }
      its("network") { should cmp "https://www.googleapis.com/compute/v1/projects/#{config['project_id']}/global/networks/vpc-#{variables['tenant']}-#{variables['vpc_name']}-vpc" }
      its("region") { should include "#{variables['region']}" }
    end
  end
  
  control "google_compute_router_nat::#{config['project_id']}/#{variables['region']}/composer-nat-router/composer-nat" do
    title "correctly configured"
    impact 1.0
    describe google_compute_router_nat({:project=>"#{config['project_id']}", :region=>"#{variables['region']}", :router=>"composer-nat-router", :name=>"composer-nat"}) do
      it { should exist }
      its("drain_nat_ips") { should be_nil }
      its("icmp_idle_timeout_sec") { should cmp 30 }
      its('log_config.enable') { should be true }
      its('log_config.filter') { should cmp "ERRORS_ONLY" }
      its("min_ports_per_vm") { should be_nil }
      its("name") { should cmp "composer-nat" }
      its("nat_ip_allocate_option") { should cmp "AUTO_ONLY" }
      its("nat_ips") { should be_nil }
      its("source_subnetwork_ip_ranges_to_nat") { should cmp "LIST_OF_SUBNETWORKS" }
      its("tcp_established_idle_timeout_sec") { should cmp 1200 }
      its("tcp_transitory_idle_timeout_sec") { should cmp 30 }
      its("udp_idle_timeout_sec") { should cmp 30 }
    end
  end
  
  control "google_compute_router_nat::#{config['project_id']}/#{variables['region']}/management-router/management-nat" do
    title "correctly configured"
    impact 1.0
    describe google_compute_router_nat({:project=>"#{config['project_id']}", :region=>"#{variables['region']}", :router=>"management-router", :name=>"management-nat"}) do
      it { should exist }
      its("drain_nat_ips") { should be_nil }
      its("icmp_idle_timeout_sec") { should cmp 30 }
      its('log_config.enable') { should be true }
      its('log_config.filter') { should cmp "ERRORS_ONLY" }
      its("min_ports_per_vm") { should cmp 64 }
      its("name") { should cmp "management-nat" }
      its("nat_ip_allocate_option") { should cmp "AUTO_ONLY" }
      its("nat_ips") { should be_nil }
      its("source_subnetwork_ip_ranges_to_nat") { should cmp "LIST_OF_SUBNETWORKS" }
      its("tcp_established_idle_timeout_sec") { should cmp 1200 }
      its("tcp_transitory_idle_timeout_sec") { should cmp 30 }
      its("udp_idle_timeout_sec") { should cmp 30 }
    end
  end
  
  control "google_compute_subnetwork::#{variables['region']}/#{variables['management_zone_name']}" do
    title "correctly configured"
    impact 1.0
    only_if { variables['create_management_zone'] === 1 }
    describe google_compute_subnetwork({:project=>"#{config['project_id']}", :region=>"#{variables['region']}", :name=>"#{variables['management_zone_name']}"}) do
      it { should exist }
      its("description") { should be_nil.or cmp "" }
      its("ip_cidr_range") { should cmp "#{variables['management_zone_cidr_range']}" }
      its("name") { should cmp "#{variables['management_zone_name']}" }
      its("network") { should cmp "https://www.googleapis.com/compute/v1/projects/#{config['project_id']}/global/networks/vpc-#{variables['tenant']}-#{variables['vpc_name']}-vpc" }
      its("private_ip_google_access") { should cmp true }
      its("region") { should include "#{variables['region']}" }
      its('log_config.enable') { should be true }
      its('log_config.aggregation_interval') { should cmp "INTERVAL_5_SEC" }
      its('log_config.flow_sampling') { should cmp 0.5 }
      its('log_config.metadata') { should cmp "INCLUDE_ALL_METADATA" }
    end
  end
  
  control "google_compute_subnetwork::#{variables['region']}/#{variables['trusted_zone_name']}" do
    title "correctly configured"
    impact 1.0
    only_if { variables['create_trusted_zone'] === 1 }
    describe google_compute_subnetwork({:project=>"#{config['project_id']}", :region=>"#{variables['region']}", :name=>"#{variables['trusted_zone_name']}"}) do
      it { should exist }
      its("description") { should be_nil.or cmp "" }
      its("ip_cidr_range") { should cmp "#{variables['trusted_zone_cidr_range']}" }
      its("name") { should cmp "#{variables['trusted_zone_name']}" }
      its("network") { should cmp "https://www.googleapis.com/compute/v1/projects/#{config['project_id']}/global/networks/vpc-#{variables['tenant']}-#{variables['vpc_name']}-vpc" }
      its("private_ip_google_access") { should cmp true }
      its("region") { should include "#{variables['region']}" }
      its('log_config.enable') { should be true }
      its('log_config.aggregation_interval') { should cmp "INTERVAL_5_SEC" }
      its('log_config.flow_sampling') { should cmp 0.5 }
      its('log_config.metadata') { should cmp "INCLUDE_ALL_METADATA" }
    end
  end
end
