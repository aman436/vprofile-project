


# project level versions
```
  tf_version: 0.14.10
  google_beta_terraform_version: 4.8.0
  google_terraform_version: 4.8.0
```

changes:
* all buckets and datasets are created as default
* all consumer and enterprise is created as default
* all _s and _v datasets created as default
* Orbitor enterprise dataset names have been changes due to their previous large difference, mapping:
  - vfuk_dh_lake_mc2_e2et_presentation_s -> vfuk_mc2_nonlive_uk_lake_mc2et_orbiter_presentation_s
  - vfuk_dh_lake_mc2_e2et_processed_s -> vfuk_mc2_nonlive_uk_lake_mc2et_orbiter_processed_s
