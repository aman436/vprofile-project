# frozen_string_literal: true

def run_bigquery_data_errors_tf12(params)

  config     = params['config']
  variables  = params['variables']

  control "google_bigquery_dataset::projects/#{config['project_id']}/datasets/errors" do
    title "correctly configured"
    impact 1.0
    describe google_bigquery_dataset({:project=>"#{config['project_id']}", :name=>"errors"}) do
      it { should exist }
      its("id") { should cmp "#{config['project_id']}:errors" }
      its("description") { should be_nil.or cmp "" }
      its("friendly_name") { should be_nil.or cmp "" }
      its("location") { should cmp "EU" }
      its("access.first.role") { should cmp "OWNER" }
      its("access.first.special_group") { should cmp "projectOwners" }
      its("default_partition_expiration_ms") { should be_nil }
      its("default_table_expiration_ms") { should be_nil }
    end
  end
  
  control "google_bigquery_table::projects/#{config['project_id']}/datasets/errors/tables/processing_errors" do
    title "correctly configured"
    impact 1.0
    describe google_bigquery_table({:project=>"#{config['project_id']}", :dataset=>"errors", :name=>"processing_errors"}) do
      it { should exist }
      its("id") { should cmp "#{config['project_id']}:errors.processing_errors" }
      its("description") { should be_nil.or cmp "" }
      its("type") { should cmp "TABLE" }
      its("location") { should cmp "#{variables['location']}" }
      its("expiration_time") { should be_nil }
      its("time_partitioning.type") { should cmp "DAY" }
      its("time_partitioning.field") { should cmp "error_time" }
      its("time_partitioning.expiration_ms") { should cmp 604800000 }
    end
  end
end
