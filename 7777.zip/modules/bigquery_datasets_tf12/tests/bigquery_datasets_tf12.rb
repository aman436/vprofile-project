# frozen_string_literal: true

def run_bigquery_datasets_tf12(params)
  puts params
  project_id = params['config']['project_id']
  control "#{project_id} : #{params['module_name']} " do
    puts 'Need to add tests for cloud sql'
  end
end
