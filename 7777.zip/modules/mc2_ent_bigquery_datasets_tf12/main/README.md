# MC2 BigQuery datasets module

This module creates all the necessary datasets for an MC2 project based on this confulence page

https://confluence.sp.vodafone.com/display/NM/MC2+Storage+Overview#MC2StorageOverview-Datasets

### Module Input Variables:

- `additional_local_markets`: -Optional- A list of additional local markets to deploy either to a grp project. defaults to an empty list.
- `location`: -Optional- A GCP location for the dataset. defaults to `EU`.
- `key_id`: -Optional- The key id required for encryption. it defaults to 'module.tenant_cryptokey_tf12.tenant_cmek-bq'.
- `disable_qlik_accounts`: -Optional- list of local markets that will not have qlik DEV accounts ([HERE](https://confluence.sp.vodafone.com/pages/viewpage.action?spaceKey=NM&title=Qlik+functional+accounts+on-boarding+guide)) access or not for the datasets. defaults to `empty list` which mean all LMs will have access for qlik accounts.

### Module Outputs:

 - `datasets_details` - Full details of the datasets. 
 - `all_datasets` - Dataset names list for each local market

### What the module do:

The module will create all required datasets for the tenant only if tenant is not `grp`. Otherwise it will create all datasets required for the `additional_local_markets` list.
The following section shows how to use this module in a `grp` project or a tenant project (`es`).

And it will by default create access for Qlik accounts unless you added 
```
disable_qlik_accounts: 
  - LM # see examples bellow
```      
### Testing on alpha and beta projects: 
While testing on the alpha and beta projects and since the project names follows a different standard than the zeta ones, you need to override the following vars in the module config.

```yaml
tenant: grp
program: mc2
```

Also override the stage in metadata

```yaml
metadata:
  stage: nonlive 
```
<br>

---
**Note:** In a ZETA project, no overriding is required as the `tenant` & `program` & `stage` will be -as usual- obtained from project metadata which is normally constructed from the file name as follows: 

```
[ORGANIZATION]-[TENANT]-[PROGRAM]-[STAGE].yml
```
---

<br>

### Example usage for `GRP` project:

<br>

```yaml
general:
  ss_suffix: nonlive
  tf_version: 0.13.2
  neuron_gcp_platform_version: 1.6.18
  composer_image_version: composer-1.13.0-airflow-1.10.10
  pypi_packages:
    google-api-core:        ==1.16.0
    google-cloud-core:      ==1.3.0
    google-cloud-datastore: ==1.12.0
    mysql-connector-python: ==8.0.20
metadata:
  stage: nonlive 
modules:
  - name: terraform_provider_base
    google_beta_terraform_version: "3.36"
    google_terraform_version: "3.36"
  - name: tenant_cryptokey_tf12
    gcs_key: true
    bq_key: true
  - name: mc2_bigquery_datasets_tf12
    disable_qlik_accounts: 
      - gr
      - cz
    tenant: grp # to match zeta env in a dev project
    program: mc2 # to match zeta env in a dev project
    additional_local_markets:
      - ro
      - gr
      - cz
```
### Outcomes for `GRP` example:

<br>

The following datasets will be created

```
  "vfgrp_mc2_nonlive_cz_lake_mc2_presentation_processed_s",
  "vfgrp_mc2_nonlive_cz_lake_mc2_presentation_processed_v",
  "vfgrp_mc2_nonlive_cz_lake_mc2_processed_s",
  "vfgrp_mc2_nonlive_cz_lake_mc2_processed_v",
  "vfgrp_mc2_nonlive_cz_lake_mc2_rawprepared_s",
  "vfgrp_mc2_nonlive_cz_lake_mc2_rawprepared_v",
  "vfgrp_mc2_nonlive_cz_model_mc2_aa_processed_s",
  "vfgrp_mc2_nonlive_cz_model_mc2_aa_processed_v",

  "vfgrp_mc2_nonlive_gr_lake_mc2_presentation_processed_s",
  "vfgrp_mc2_nonlive_gr_lake_mc2_presentation_processed_v",
  "vfgrp_mc2_nonlive_gr_lake_mc2_processed_s",
  "vfgrp_mc2_nonlive_gr_lake_mc2_processed_v",
  "vfgrp_mc2_nonlive_gr_lake_mc2_rawprepared_s",
  "vfgrp_mc2_nonlive_gr_lake_mc2_rawprepared_v",
  "vfgrp_mc2_nonlive_gr_model_mc2_aa_processed_s",
  "vfgrp_mc2_nonlive_gr_model_mc2_aa_processed_v",

  "vfgrp_mc2_nonlive_ro_lake_mc2_presentation_processed_s",
  "vfgrp_mc2_nonlive_ro_lake_mc2_presentation_processed_v",
  "vfgrp_mc2_nonlive_ro_lake_mc2_processed_s",
  "vfgrp_mc2_nonlive_ro_lake_mc2_processed_v",
  "vfgrp_mc2_nonlive_ro_lake_mc2_rawprepared_s",
  "vfgrp_mc2_nonlive_ro_lake_mc2_rawprepared_v",
  "vfgrp_mc2_nonlive_ro_model_mc2_aa_processed_s",
  "vfgrp_mc2_nonlive_ro_model_mc2_aa_processed_v",
```

### Example usage for a local market project (`ES`):

<br>

```yaml
general:
  ss_suffix: nonlive
  tf_version: 0.13.2
  neuron_gcp_platform_version: 1.6.18
metadata:
  stage: nonlive
  tenant: es
  program: mc2dev
modules:
  - name: terraform_provider_base
    google_beta_terraform_version: "3.36"
    google_terraform_version: "3.36"
  - name: tenant_cryptokey_tf12
    gcs_key: true
    bq_key: true
  - name: mc2_bigquery_datasets_tf12
    disable_qlik_accounts: [es] # if you want to enable qlik then remove disable_qlik_accounts or make it an empty list
    tenant: es # to match zeta env in a dev project
    program: mc2 # to match zeta env in a dev project
```

### Outcomes for `ES` example:

<br>

The following datasets will be created

```
  "vfes_mc2_nonlive_es_lake_mc2_presentation_processed_s",
  "vfes_mc2_nonlive_es_lake_mc2_presentation_processed_v",
  "vfes_mc2_nonlive_es_lake_mc2_processed_s",
  "vfes_mc2_nonlive_es_lake_mc2_processed_v",
  "vfes_mc2_nonlive_es_lake_mc2_rawprepared_s",
  "vfes_mc2_nonlive_es_lake_mc2_rawprepared_v",
  "vfes_mc2_nonlive_es_model_mc2_aa_processed_s",
  "vfes_mc2_nonlive_es_model_mc2_aa_processed_v",
```