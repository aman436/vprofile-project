#!/usr/bin/python
import subprocess


# old_module_name: bigquery_datasets_tf12  module to be replaced
# new_module_name: mc2_bigquery_datasets_tf12  module to replace
def state_transfer(old_module_name, new_module_name):
    try:
        result = subprocess.check_output(['terraform', 'state', 'list', 'module.'+old_module_name], stderr=subprocess.STDOUT)  # Selecting all resources in state file with the old bq datasets module
        old_modules = result.split("\n")  # Making a list of the output string
        old_modules = filter(None, old_modules)  # Removing empty entries in the list
    except subprocess.CalledProcessError as e:
        print('\033[91m' + u"\u2718" + " Module " + old_module_name + " has no resources in state file." + '\033[0m')
        print('\033[91m' + e.output + '\033[0m')

    # Replacing the old module name with the new module.
    # Using terraform mv to map the old resources to the new ones
    for module in old_modules:
        new_module_id = module.replace(old_module_name, new_module_name)
        try:
            subprocess.check_output(['terraform', 'state', 'mv', module, new_module_id], stderr=subprocess.STDOUT)
            print('\033[92m' + u"\u2714 " + new_module_id + " changed succesfuly." + '\033[0m')
        except subprocess.CalledProcessError as e:
            print('\033[91m' + u"\u2718 " + new_module_id + " change failed." + '\033[0m')
            print('\033[91m' + e.output + '\033[0m')


state_transfer("bigquery_datasets_tf12", "mc2_bigquery_datasets_tf12")
