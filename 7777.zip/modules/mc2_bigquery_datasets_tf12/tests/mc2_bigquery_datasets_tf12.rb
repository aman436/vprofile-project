# frozen_string_literal: true

def run_mc2_bigquery_datasets_tf12(params)
    config     = params['config']
    variables  = params['variables']
    tenant = variables["tenant"]
    program = variables["program"]
    project_id = config["project_id"]
    stage = variables["stage"]
    location = variables['location']



    _lake_datasets = []
    _model_datasets = []
    if tenant == "grp"
        variables["additional_local_markets"].each do |local_market|
            _lake_datasets.push("vf#{tenant}_#{program}_#{stage}_#{local_market.downcase}_lake_mc2_rawprepared_s")
            _lake_datasets.push("vf#{tenant}_#{program}_#{stage}_#{local_market.downcase}_lake_mc2_rawprepared_v")
            _lake_datasets.push("vf#{tenant}_#{program}_#{stage}_#{local_market.downcase}_lake_mc2_processed_s")
            _lake_datasets.push("vf#{tenant}_#{program}_#{stage}_#{local_market.downcase}_lake_mc2_processed_v")
            _lake_datasets.push("vf#{tenant}_#{program}_#{stage}_#{local_market.downcase}_lake_mc2_presentation_processed_s")
            _lake_datasets.push("vf#{tenant}_#{program}_#{stage}_#{local_market.downcase}_lake_mc2_presentation_processed_v")
            _model_datasets.push("vf#{tenant}_#{program}_#{stage}_#{local_market.downcase}_model_mc2_aa_processed_s")
            _model_datasets.push("vf#{tenant}_#{program}_#{stage}_#{local_market.downcase}_model_mc2_aa_features_s")
            _model_datasets.push("vf#{tenant}_#{program}_#{stage}_#{local_market.downcase}_model_mc2_aa_processed_v")
        end   
    else
        _lake_datasets.push("vf#{tenant}_#{program}_#{stage}_#{tenant}_lake_mc2_rawprepared_s")
        _lake_datasets.push("vf#{tenant}_#{program}_#{stage}_#{tenant}_lake_mc2_rawprepared_v")
        _lake_datasets.push("vf#{tenant}_#{program}_#{stage}_#{tenant}_lake_mc2_processed_s")
        _lake_datasets.push("vf#{tenant}_#{program}_#{stage}_#{tenant}_lake_mc2_processed_v")
        _lake_datasets.push("vf#{tenant}_#{program}_#{stage}_#{tenant}_lake_mc2_presentation_processed_s")
        _lake_datasets.push("vf#{tenant}_#{program}_#{stage}_#{tenant}_lake_mc2_presentation_processed_v")
        _model_datasets.push("vf#{tenant}_#{program}_#{stage}_#{tenant}_model_mc2_aa_processed_s")
        _model_datasets.push("vf#{tenant}_#{program}_#{stage}_#{tenant}_model_mc2_features_s")
        _model_datasets.push("vf#{tenant}_#{program}_#{stage}_#{tenant}_model_mc2_aa_processed_v")  
    end

    

    _lake_datasets.each do |dataset_name|
        control "#{dataset_name} test" do
            describe google_bigquery_dataset(project: project_id, name: dataset_name) do
                it { should exist } 
                its('location') { should eq location }
                its('id') { should eq "#{project_id}:#{dataset_name}" }
            end
            local_market = dataset_name.split("_")[3]
            google_bigquery_dataset(project: project_id, name: dataset_name).access.each do |dataset_access|
                if dataset_access.group_by_email == "gcp-vf-#{tenant}-mc2-de-user@vodafone.com"
                    describe dataset_access do
                        its('role') { should eq 'WRITER' }
                        its('group_by_email') { should eq "gcp-vf-#{tenant}-mc2-de-user@vodafone.com" }
                    end
                end

                if dataset_access.special_group == "projectOwners"
                    describe dataset_access do
                        its('role') { should eq 'OWNER' }
                        its('special_group') { should eq 'projectOwners' }
                    end
                end

                if dataset_access.special_group == "projectReaders"
                    describe dataset_access do
                        its('role') { should eq 'READER' }
                        its('special_group') { should eq 'projectReaders' }
                    end
                end

                if dataset_access.special_group == "projectWriters"
                    describe dataset_access do
                        its('role') { should eq 'WRITER' }
                        its('special_group') { should eq 'projectWriters' }
                    end
                end

                if (local_market == "ro" || local_market == "al") && dataset_access.user_by_email == "vfgroupsvc-#{local_market}bqd@vodafone.com"
                    if dataset_name.include? "lake_mc2_presentation_processed_v"
                        describe dataset_access do
                            its('role') { should eq 'READER' }
                            its('user_by_email') { should eq "vfgroupsvc-#{local_market}bqd@vodafone.com" }
                        end
                    end
                elsif dataset_access.user_by_email == "vfgroupsvc_#{local_market}bqd@vodafone.com"
                    if dataset_name.include? "lake_mc2_presentation_processed_v"
                        describe dataset_access do
                            its('role') { should eq 'READER' }
                            its('user_by_email') { should eq "vfgroupsvc-#{local_market}bqd@vodafone.com" }
                        end
                    end
                end
            end
        end
    end

    _model_datasets.each do |dataset_name|
        control "#{dataset_name} test" do
            describe google_bigquery_dataset(project: project_id, name: dataset_name) do
                it { should exist } 
                its('location') { should eq location }
                its('id') { should eq "#{project_id}:#{dataset_name}" }
            end
            local_market = dataset_name.split("_")[3]
            google_bigquery_dataset(project: project_id, name: dataset_name).access.each do |dataset_access|
                if dataset_access.group_by_email == "gcp-vf-#{tenant}-mc2-ds-user@vodafone.com"
                    describe dataset_access do
                        its('role') { should eq 'WRITER' }
                        its('group_by_email') { should eq "gcp-vf-#{tenant}-mc2-ds-user@vodafone.com" }
                    end
                end

                if dataset_access.special_group == "projectOwners"
                    describe dataset_access do
                        its('role') { should eq 'OWNER' }
                        its('special_group') { should eq 'projectOwners' }
                    end
                end

                if dataset_access.special_group == "projectReaders"
                    describe dataset_access do
                        its('role') { should eq 'READER' }
                        its('special_group') { should eq 'projectReaders' }
                    end
                end

                if dataset_access.special_group == "projectWriters"
                    describe dataset_access do
                        its('role') { should eq 'WRITER' }
                        its('special_group') { should eq 'projectWriters' }
                    end
                end

                if (local_market == "ro" || local_market == "al") && dataset_access.user_by_email == "vfgroupsvc-#{local_market}bqd@vodafone.com"
                    if dataset_name.include? "model_mc2_aa_processed_v"
                        describe dataset_access do
                            its('role') { should eq 'READER' }
                            its('user_by_email') { should eq "vfgroupsvc-#{local_market}bqd@vodafone.com" }
                        end
                    end
                elsif dataset_access.user_by_email == "vfgroupsvc_#{local_market}bqd@vodafone.com"
                    if dataset_name.include? "model_mc2_aa_processed_v"
                        describe dataset_access do
                            its('role') { should eq 'READER' }
                            its('user_by_email') { should eq "vfgroupsvc-#{local_market}bqd@vodafone.com" }
                        end
                    end
                end
            end
        end   
    end
end
