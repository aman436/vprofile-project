# frozen_string_literal: true

%w[vpc subnet].each do |lib|
  require "#{Dir.pwd}/target/tests/libraries/#{lib}.rb"
end

def run_tenant_core(params)
  project_id = params['config']['project_id']
  name = "#{project_id} : #{params['config']['module_name']}"
  control name do
    title 'tenant_core setup correctly'
    impact 0.4

    vpc_name = "vpc-#{params['variables']['tenant']}-" \
      "#{params['variables']['vpc_name']}-vpc"
    is_autocreate = false
    routing_mode = params['tests']['routing_mode']

    validate_vpc(project_id, vpc_name, is_autocreate, routing_mode)
    # Subnet
    %w[trusted management].each do |subnet_prefix|
      subnet_name = "#{subnet_prefix}-zone"
      subnet_exists_in_project(
        project_id,
        params['variables']['region'],
        subnet_name
      )
      subnet_cidr_range(
        project_id,
        params['variables']['region'],
        subnet_name,
        params['variables']["#{subnet_prefix}_zone_cidr_range"]
      )
      subnet_in_vpc_network(
        project_id,
        params['variables']['region'],
        subnet_name,
        vpc_name
      )
      subnet_vm_private_ip_access(
        project_id,
        params['variables']['region'],
        subnet_name,
        params['tests']['subnet_private_ip_access']
      )
      subnet_flowlog_on(
        project_id,
        subnet_name,
        params['variables']['region'],
        params['tests']['subnet_flowlog_on']
      )
    end
  end
end