# mc2_generic_iam

This module is used to provide appropriate accesses to our 10 generic MC2 IAM groups. This module is only for Project level IAM, and does not cover and specific dataset IAM.

The permission matrix that this module used is defined here: https://confluence.sp.vodafone.com/display/NM/MC2+IAM+Groups+Consolidation+and+Revamping

## How to use this module

This module is simple to use, it takes two arguments of `environment` and `project`. The permissions of the 10 groups are determined by the environment being used.

`environment` must match one of the four following options:

- compute_nonlive
- compute_live
- storage_nonlive
- storage_live

`project` is the project id.

```yaml
  - name: mc2_generic_iam
    environment: compute_nonlive
    project: vf-infdev-datahub-96af
```
