# frozen_string_literal: true

['vm'].each do |lib|
  require_relative "#{Dir.pwd}/target/tests/libraries/#{lib}.rb"
end

def run_service_account_tf12(params)
  project_id = params['config']['project_id']
  control "#{project_id} : #{params['config']['module_name']} " do
    title 'Service account created correctly'
    impact 0.4
  end
end